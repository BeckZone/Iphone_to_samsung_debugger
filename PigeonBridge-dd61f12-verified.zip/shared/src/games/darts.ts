import { PlayerSlot } from "../models";

// Standard "501, double-out" darts. Each turn is 3 throws; each throw is a
// segment (1-20, or "bull") plus a multiplier.
export type DartSegment = number; // 1-20, or 25 for bull
export type DartMultiplier = 1 | 2 | 3;

export interface DartThrow {
  segment: DartSegment; // 1-20 or 25 (bullseye ring)
  multiplier: DartMultiplier; // triple only valid for 1-20, not bull
}

export interface DartsMove {
  throws: DartThrow[]; // 1-3 throws submitted for this turn
}

export interface DartsBoard {
  scores: Record<PlayerSlot, number>; // remaining score, starts at 501
  legHistory: Record<PlayerSlot, DartThrow[][]>; // completed turns, for a running log
  turnThrowsSoFar: DartThrow[]; // throws thrown in the current in-progress turn
}

export const DARTS_STARTING_SCORE = 501;

export function createInitialDartsBoard(): DartsBoard {
  return {
    scores: { player1: DARTS_STARTING_SCORE, player2: DARTS_STARTING_SCORE },
    legHistory: { player1: [], player2: [] },
    turnThrowsSoFar: [],
  };
}

function throwValue(t: DartThrow): number {
  if (t.segment === 25) return t.multiplier === 2 ? 50 : 25; // 25 (outer) or 50 (bull), no triple bull
  return t.segment * t.multiplier;
}

function isValidThrow(t: DartThrow): boolean {
  if (t.segment === 25) return t.multiplier === 1 || t.multiplier === 2;
  if (t.segment < 1 || t.segment > 20) return false;
  return t.multiplier === 1 || t.multiplier === 2 || t.multiplier === 3;
}

/**
 * Applies one full turn (up to 3 throws) for `slot`. Enforces:
 * - 1-3 throws per call
 * - "double out": the checkout dart (the one that brings score to exactly 0)
 *   must be a double (or bullseye 50), otherwise it's a "bust" and the whole
 *   turn's score change is discarded (classic darts bust rule). Going below
 *   0 or to exactly 1 is also a bust.
 */
export function applyDartsMove(board: DartsBoard, slot: PlayerSlot, move: DartsMove): DartsBoard {
  if (move.throws.length < 1 || move.throws.length > 3) throw new Error("A turn must have 1-3 throws");
  for (const t of move.throws) {
    if (!isValidThrow(t)) throw new Error("Invalid dart throw");
  }
  const startScore = board.scores[slot];
  let running = startScore;
  let bust = false;
  let checkedOut = false;

  for (const t of move.throws) {
    const val = throwValue(t);
    const isDouble = t.multiplier === 2;
    const remaining = running - val;
    if (remaining < 0 || remaining === 1) {
      bust = true;
      break;
    }
    if (remaining === 0) {
      if (!isDouble) {
        bust = true;
        break;
      }
      running = 0;
      checkedOut = true;
      break; // leg over, ignore any further throws in this submission
    }
    running = remaining;
  }

  const nextScores = { ...board.scores };
  nextScores[slot] = bust ? startScore : running;

  const nextHistory = {
    ...board.legHistory,
    [slot]: [...board.legHistory[slot], move.throws],
  };

  return {
    scores: nextScores,
    legHistory: nextHistory,
    turnThrowsSoFar: [],
  };
}

export function dartsWinner(board: DartsBoard): PlayerSlot | null {
  if (board.scores.player1 === 0) return "player1";
  if (board.scores.player2 === 0) return "player2";
  return null;
}
