package app.pigeonbridge.android.attachment

import org.junit.Assert.assertTrue
import org.junit.Test

class DiagnosticReportFormatterTest {

    private fun sampleReport(
        mimeReported: String? = "image/png",
        mimeDetected: String? = "image/png",
        reportedSizeBytes: Long = 82_431,
        widthPx: Int = 512,
        heightPx: Int = 512,
        hasAlpha: Boolean? = true,
        classification: AttachmentClassification = AttachmentClassification.LIKELY_STICKER,
        readPermission: Boolean? = true,
        alternateSummary: String = "No alternate/full-quality representation exposed by provider.",
        quality: QualityClass = QualityClass.SMALL,
    ) = DiagnosticReport(
        uriString = "content://example.provider/attachment/42",
        uriScheme = "content",
        uriAuthority = "example.provider",
        uriPath = "/attachment/42",
        mimeReported = mimeReported,
        mimeDetectedFromBytes = mimeDetected,
        fileExtension = "png",
        displayName = "image.png",
        reportedSizeBytes = reportedSizeBytes,
        lastModifiedMillis = null,
        widthPx = widthPx,
        heightPx = heightPx,
        hasAlpha = hasAlpha,
        exifOrientationRaw = 1,
        bitDepthDescription = "ARGB_8888 (32-bit)",
        isAnimated = false,
        frameCount = 1,
        previewSuspected = true,
        previewReasons = listOf("dimensions are small"),
        classification = classification,
        classificationSignals = listOf(
            SignalScore("alpha", 1, 0, "has alpha channel (+1 sticker)"),
            SignalScore("mime", 1, 0, "sticker-typical MIME image/png (+1 sticker)"),
        ),
        stickerScore = 7,
        photoScore = 0,
        uriReadable = true,
        streamReadable = true,
        bitmapDecodeSucceeded = true,
        decodedWidthPx = widthPx,
        decodedHeightPx = heightPx,
        readPermissionGranted = readPermission,
        persistablePermissionGranted = false,
        grantedVia = "ACTION_SEND share intent",
        alternateRepresentationSummary = alternateSummary,
        quality = quality,
        qualityReason = "$widthPx × $heightPx",
    )

    @Test
    fun `report includes the URI parts`() {
        val text = DiagnosticReportFormatter.format(sampleReport())
        assertTrue(text.contains("URI scheme: content"))
        assertTrue(text.contains("URI authority: example.provider"))
    }

    @Test
    fun `report flags a MIME disagreement`() {
        val text = DiagnosticReportFormatter.format(sampleReport(mimeReported = "image/png", mimeDetected = "image/webp"))
        assertTrue(text.contains("Reported and detected MIME disagree"))
    }

    @Test
    fun `report does not flag agreement as a disagreement`() {
        val text = DiagnosticReportFormatter.format(sampleReport(mimeReported = "image/png", mimeDetected = "image/png"))
        assertTrue(!text.contains("disagree"))
    }

    @Test
    fun `unavailable file size is stated explicitly, not assumed`() {
        val text = DiagnosticReportFormatter.format(sampleReport(reportedSizeBytes = -1))
        assertTrue(text.contains("Size unavailable"))
    }

    @Test
    fun `known file size is formatted with byte count`() {
        val text = DiagnosticReportFormatter.format(sampleReport(reportedSizeBytes = 82_431))
        assertTrue(text.contains("82,431 bytes"))
    }

    @Test
    fun `sticker classification and score are present`() {
        val text = DiagnosticReportFormatter.format(sampleReport(classification = AttachmentClassification.LIKELY_STICKER))
        assertTrue(text.contains("Sticker classification: LIKELY_STICKER"))
        assertTrue(text.contains("Sticker score: 7"))
    }

    @Test
    fun `quality classification never claims original`() {
        val text = DiagnosticReportFormatter.format(sampleReport(quality = QualityClass.SMALL))
        assertTrue(text.contains("Attachment quality: SMALL"))
        assertTrue(!text.contains("Original quality"))
    }

    @Test
    fun `unknown read permission is reported as Unknown, not a guessed YES or NO`() {
        val text = DiagnosticReportFormatter.format(sampleReport(readPermission = null))
        assertTrue(text.contains("Read permission: Unknown"))
    }

    @Test
    fun `no alternate representation is stated explicitly`() {
        val text = DiagnosticReportFormatter.format(sampleReport())
        assertTrue(text.contains("No alternate/full-quality representation exposed by provider."))
    }

    @Test
    fun `report includes the scoring signals section`() {
        val text = DiagnosticReportFormatter.format(sampleReport())
        assertTrue(text.contains("Scoring signals:"))
        assertTrue(text.contains("alpha: has alpha channel"))
    }
}
