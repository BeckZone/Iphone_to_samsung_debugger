import { PlayerSlot } from "../models";

// ---------------------------------------------------------------------------
// Table geometry & physics constants (arbitrary units, consistent throughout).
// Simplification note: this is a real 2D physics simulation (friction,
// elastic collisions, cushion reflection, pocket capture) — not scripted
// outcomes — but it is 2D only (no spin/english, no jump/masse shots, no
// ball-height/skidding effects), which is the honest tradeoff for a
// browser/mobile-synced implementation vs. a full 3D physics engine.
// ---------------------------------------------------------------------------
export const TABLE_W = 200;
export const TABLE_H = 100;
export const BALL_R = 2.85;
export const POCKET_R = 5.2;
const FRICTION = 170; // speed units/s^2 lost to table friction — calibrated so a
// full-power shot (MAX_SHOT_SPEED) travels roughly one table length before stopping:
// stopping distance = v^2 / (2*FRICTION) ≈ 260^2/(2*170) ≈ 199 ≈ TABLE_W.
const BALL_RESTITUTION = 0.98;
const CUSHION_RESTITUTION = 0.8;
const MIN_SPEED = 1.5; // below this, a ball is considered stopped
const MAX_SHOT_SPEED = 260; // power=100 maps to this initial speed
const DT = 1 / 240; // simulation timestep (seconds)
const MAX_SIM_SECONDS = 12;

export type BallId = number; // 0 = cue, 1-7 solids, 8 = eight ball, 9-15 stripes

export interface Ball {
  id: BallId;
  x: number;
  y: number;
  vx: number;
  vy: number;
  pocketed: boolean;
}

export type Suit = "solids" | "stripes";

export interface EightBallBoard {
  balls: Ball[];
  assignedSuit: Partial<Record<PlayerSlot, Suit>>; // set once a player legally pockets their first group ball
  ballInHandFor: PlayerSlot | null; // true right after an opponent's foul/scratch — next shooter may place the cue ball
  lastShot: {
    pocketedThisShot: BallId[];
    firstContactBallId: BallId | null;
    scratched: boolean;
    foul: boolean;
    foulReason: string | null;
  } | null;
}

export interface EightBallMove {
  angleDeg: number; // 0 = toward +x, measured counterclockwise
  power: number; // 0-100
  // Only valid/used when board.ballInHandFor === the shooting slot:
  placeCueAt?: { x: number; y: number };
}

function pocketCenters(): { x: number; y: number }[] {
  return [
    { x: 0, y: 0 },
    { x: TABLE_W / 2, y: -1.5 }, // top-middle pockets sit slightly proud of the cushion line
    { x: TABLE_W, y: 0 },
    { x: 0, y: TABLE_H },
    { x: TABLE_W / 2, y: TABLE_H + 1.5 },
    { x: TABLE_W, y: TABLE_H },
  ];
}

export function createInitialEightBallBoard(): EightBallBoard {
  const balls: Ball[] = [];
  balls.push({ id: 0, x: TABLE_W * 0.25, y: TABLE_H / 2, vx: 0, vy: 0, pocketed: false });

  // Standard 10-row triangular rack (5 rows), apex pointing at the cue ball.
  // Order within the rack is a legal-but-simplified arrangement (8-ball
  // centered in the 3rd row as required; solids/stripes otherwise just
  // alternate rather than following full tournament corner rules).
  const order = [1, 9, 2, 10, 8, 3, 11, 4, 12, 5, 13, 6, 14, 7, 15];
  const apexX = TABLE_W * 0.72;
  const apexY = TABLE_H / 2;
  const rowSpacingX = BALL_R * 1.74;
  const rowSpacingY = BALL_R * 2.02;
  let idx = 0;
  for (let row = 0; row < 5; row++) {
    for (let col = 0; col <= row; col++) {
      const id = order[idx++];
      const x = apexX + row * rowSpacingX;
      const y = apexY - (row * rowSpacingY) / 2 + col * rowSpacingY;
      balls.push({ id, x, y, vx: 0, vy: 0, pocketed: false });
    }
  }

  return { balls, assignedSuit: {}, ballInHandFor: null, lastShot: null };
}

function clampCuePlacement(x: number, y: number): { x: number; y: number } {
  return {
    x: Math.min(Math.max(x, BALL_R * 2), TABLE_W - BALL_R * 2),
    y: Math.min(Math.max(y, BALL_R * 2), TABLE_H - BALL_R * 2),
  };
}

/** Runs the physics simulation to rest and returns the resulting board + shot events. Pure function of (board, move). */
export function applyEightBallMove(board: EightBallBoard, slot: PlayerSlot, move: EightBallMove): EightBallBoard {
  if (move.power < 0 || move.power > 100) throw new Error("Power must be 0-100");

  let balls = board.balls.map((b) => ({ ...b }));
  const cue = balls.find((b) => b.id === 0);
  if (!cue) throw new Error("Cue ball is missing from the table");

  if (board.ballInHandFor === slot) {
    const placement = move.placeCueAt
      ? clampCuePlacement(move.placeCueAt.x, move.placeCueAt.y)
      : { x: TABLE_W * 0.25, y: TABLE_H / 2 };
    for (const b of balls) {
      if (b.id === 0 || b.pocketed) continue;
      const dx = b.x - placement.x;
      const dy = b.y - placement.y;
      if (Math.sqrt(dx * dx + dy * dy) < BALL_R * 2) throw new Error("Can't place the cue ball on top of another ball");
    }
    cue.x = placement.x;
    cue.y = placement.y;
    cue.pocketed = false;
  } else if (cue.pocketed) {
    throw new Error("Cue ball is pocketed — this shouldn't happen outside ball-in-hand");
  }

  const rad = (move.angleDeg * Math.PI) / 180;
  const speed = (move.power / 100) * MAX_SHOT_SPEED;
  cue.vx = Math.cos(rad) * speed;
  cue.vy = Math.sin(rad) * speed;

  const { finalBalls, pocketedThisShot, firstContactBallId } = simulate(balls);

  return {
    balls: finalBalls,
    assignedSuit: board.assignedSuit,
    ballInHandFor: null, // ballInHandFor / suit / turn logic is finished in server/src/game/engine.ts, which has session-level context (whose turn, win/loss)
    lastShot: {
      pocketedThisShot,
      firstContactBallId,
      scratched: pocketedThisShot.includes(0),
      foul: false,
      foulReason: null,
    },
  };
}

interface SimResult {
  finalBalls: Ball[];
  pocketedThisShot: BallId[];
  firstContactBallId: BallId | null;
}

function simulate(initialBalls: Ball[]): SimResult {
  const balls = initialBalls.map((b) => ({ ...b }));
  const pockets = pocketCenters();
  const pocketedThisShot: BallId[] = [];
  let firstContactBallId: BallId | null = null;
  let elapsed = 0;

  while (elapsed < MAX_SIM_SECONDS) {
    elapsed += DT;
    let anyMoving = false;

    for (const b of balls) {
      if (b.pocketed) continue;
      const speed = Math.hypot(b.vx, b.vy);
      if (speed < MIN_SPEED) {
        b.vx = 0;
        b.vy = 0;
        continue;
      }
      anyMoving = true;
      b.x += b.vx * DT;
      b.y += b.vy * DT;
      const decel = FRICTION * DT;
      const newSpeed = Math.max(0, speed - decel);
      const scale = newSpeed / speed;
      b.vx *= scale;
      b.vy *= scale;

      if (b.x - BALL_R < 0) {
        b.x = BALL_R;
        b.vx = -b.vx * CUSHION_RESTITUTION;
      } else if (b.x + BALL_R > TABLE_W) {
        b.x = TABLE_W - BALL_R;
        b.vx = -b.vx * CUSHION_RESTITUTION;
      }
      if (b.y - BALL_R < 0) {
        b.y = BALL_R;
        b.vy = -b.vy * CUSHION_RESTITUTION;
      } else if (b.y + BALL_R > TABLE_H) {
        b.y = TABLE_H - BALL_R;
        b.vy = -b.vy * CUSHION_RESTITUTION;
      }
    }

    for (let i = 0; i < balls.length; i++) {
      if (balls[i].pocketed) continue;
      for (let j = i + 1; j < balls.length; j++) {
        if (balls[j].pocketed) continue;
        const a = balls[i];
        const c = balls[j];
        const dx = c.x - a.x;
        const dy = c.y - a.y;
        const dist = Math.hypot(dx, dy);
        if (dist === 0 || dist >= BALL_R * 2) continue;

        if (firstContactBallId === null && (a.id === 0 || c.id === 0)) {
          firstContactBallId = a.id === 0 ? c.id : a.id;
        }

        const overlap = BALL_R * 2 - dist;
        const nx = dx / dist;
        const ny = dy / dist;
        a.x -= (nx * overlap) / 2;
        a.y -= (ny * overlap) / 2;
        c.x += (nx * overlap) / 2;
        c.y += (ny * overlap) / 2;

        const relVx = c.vx - a.vx;
        const relVy = c.vy - a.vy;
        const velAlongNormal = relVx * nx + relVy * ny;
        if (velAlongNormal > 0) continue;
        const impulse = -(1 + BALL_RESTITUTION) * velAlongNormal * 0.5;
        a.vx -= impulse * nx;
        a.vy -= impulse * ny;
        c.vx += impulse * nx;
        c.vy += impulse * ny;
      }
    }

    for (const b of balls) {
      if (b.pocketed) continue;
      for (const p of pockets) {
        const d = Math.hypot(b.x - p.x, b.y - p.y);
        if (d < POCKET_R) {
          b.pocketed = true;
          b.vx = 0;
          b.vy = 0;
          pocketedThisShot.push(b.id);
          break;
        }
      }
    }

    if (!anyMoving) break;
  }

  return { finalBalls: balls, pocketedThisShot, firstContactBallId };
}
