import { customAlphabet } from "nanoid";
import {
  GAME_ABANDON_TIMEOUT_MS,
  GAME_ID_ALPHABET,
  GAME_ID_LENGTH,
  GameSession,
  GameType,
} from "@pigeonbridge/shared";
import { createInitialBoard } from "./engine";

const genId = customAlphabet(GAME_ID_ALPHABET, GAME_ID_LENGTH);

/**
 * Simple in-memory session store. Good enough for an MVP / single-instance
 * deployment; swap for Redis (or Postgres + pub/sub) before running more than
 * one server process, since sessions currently live only in this process's memory.
 */
class SessionStore {
  private sessions = new Map<string, GameSession<any>>();

  create(gameType: GameType, nickname: string, platform: "android" | "web"): GameSession<any> {
    let gameId = genId();
    // extremely unlikely collision guard
    while (this.sessions.has(gameId)) gameId = genId();

    const now = Date.now();
    const session: GameSession<any> = {
      gameId,
      gameType,
      player1: {
        slot: "player1",
        nickname,
        connected: false, // becomes true once they actually open the websocket
        platform,
        lastSeenAt: now,
      },
      player2: null,
      currentTurn: "player1",
      board: createInitialBoard(gameType),
      status: "waiting_for_opponent",
      createdAt: now,
      lastActivity: now,
      rematchRequestedBy: [],
    };
    this.sessions.set(gameId, session);
    return session;
  }

  get(gameId: string): GameSession<any> | undefined {
    return this.sessions.get(gameId.toUpperCase());
  }

  set(gameId: string, session: GameSession<any>) {
    this.sessions.set(gameId.toUpperCase(), session);
  }

  delete(gameId: string) {
    this.sessions.delete(gameId.toUpperCase());
  }

  /** Removes sessions that have had no activity for GAME_ABANDON_TIMEOUT_MS. Call on an interval. */
  sweepAbandoned(): number {
    const now = Date.now();
    let removed = 0;
    for (const [id, session] of this.sessions) {
      if (now - session.lastActivity > GAME_ABANDON_TIMEOUT_MS) {
        this.sessions.delete(id);
        removed++;
      }
    }
    return removed;
  }

  size(): number {
    return this.sessions.size;
  }
}

export const sessionStore = new SessionStore();
