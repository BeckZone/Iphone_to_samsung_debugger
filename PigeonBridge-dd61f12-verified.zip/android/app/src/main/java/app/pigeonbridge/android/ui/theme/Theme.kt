package app.pigeonbridge.android.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val PBPrimary = Color(0xFF7C3AED)
val PBPrimary2 = Color(0xFF4F46E5)
val PBBackground = Color(0xFF0F0B1E)
val PBSurface = Color(0xFF1A1530)
val PBSurfaceVariant = Color(0xFF241D42)
val PBOnSurface = Color(0xFFF5F3FF)
val PBMuted = Color(0xFFA8A3C7)
val PBAccent = Color(0xFF22C55E)

private val PigeonBridgeColorScheme = darkColorScheme(
    primary = PBPrimary,
    secondary = PBPrimary2,
    background = PBBackground,
    surface = PBSurface,
    surfaceVariant = PBSurfaceVariant,
    onBackground = PBOnSurface,
    onSurface = PBOnSurface,
)

@Composable
fun PigeonBridgeTheme(content: @Composable () -> Unit) {
    // Always dark — matches the web client's fixed dark theme (see web/src/*.html
    // :root { color-scheme: dark }) so the two feel like the same product.
    MaterialTheme(
        colorScheme = PigeonBridgeColorScheme,
        content = content,
    )
}
