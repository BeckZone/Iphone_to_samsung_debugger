package app.pigeonbridge.android.monitoring

import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * Thin wrapper around the real Android RoleManager API. See
 * ARCHITECTURE.md section 3 for the full investigation -- short version:
 * this genuinely calls the system's default-SMS-app request flow, but
 * PigeonBridge does not implement a full SMS/MMS client (SMS_DELIVER
 * receiver, compose activity, etc.), which Android requires for a candidate
 * app to even be eligible for the role. If the system reports we're not
 * eligible, isRoleAvailable()/the request Intent will reflect that -- the
 * UI surfaces this honestly rather than pretending the button solved
 * anything. Even if held, this role affects standard SMS/MMS only, NOT
 * RCS -- see ARCHITECTURE.md.
 */
object DefaultSmsRoleHelper {

    fun isSupported(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        val roleManager = context.getSystemService(RoleManager::class.java) ?: return false
        return roleManager.isRoleAvailable(RoleManager.ROLE_SMS)
    }

    fun isRoleHeld(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
        val roleManager = context.getSystemService(RoleManager::class.java) ?: return false
        return try {
            roleManager.isRoleHeld(RoleManager.ROLE_SMS)
        } catch (_: Exception) {
            false
        }
    }

    /** Returns the real system Intent to launch for the role request, or null if unsupported on this API level. Launch with startActivityForResult/registerForActivityResult -- the system handles eligibility and shows its own UI, including telling the user directly if PigeonBridge can't be offered the role. */
    fun createRequestIntent(context: Context): Intent? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        val roleManager = context.getSystemService(RoleManager::class.java) ?: return null
        return roleManager.createRequestRoleIntent(RoleManager.ROLE_SMS)
    }
}
