package app.pigeonbridge.android.background

import android.content.Context
import app.pigeonbridge.android.PigeonBridgeApp
import app.pigeonbridge.android.monitoring.MonitoringState

/**
 * Android-backed store for the "Background Message Processing" switches. The pure decision
 * logic reads a [BackgroundSettingsSnapshot]; this class only fills it in.
 *
 * The master switch is the SAME value as the existing "Enable/Disable Monitoring" toggle
 * ([MonitoringState.monitoringEnabled]), so the two screens can never disagree.
 */
object BackgroundSettings {
    private const val PREFS = "pigeonbridge_background"
    private const val KEY_STICKERS = "process_stickers"
    private const val KEY_PROCESSED_NOTIFICATIONS = "processed_notifications"
    private const val KEY_EMOJI_ARTWORK = "alternate_emoji_artwork"

    private val prefs get() = PigeonBridgeApp.instance.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    var backgroundProcessing: Boolean
        get() = MonitoringState.monitoringEnabled
        set(value) { MonitoringState.monitoringEnabled = value }

    var processStickers: Boolean
        get() = prefs.getBoolean(KEY_STICKERS, true)
        set(value) = prefs.edit().putBoolean(KEY_STICKERS, value).apply()

    /** Off by default: nobody gets extra notifications they did not ask for. */
    var processedNotifications: Boolean
        get() = prefs.getBoolean(KEY_PROCESSED_NOTIFICATIONS, false)
        set(value) = prefs.edit().putBoolean(KEY_PROCESSED_NOTIFICATIONS, value).apply()

    var alternateEmojiArtwork: Boolean
        get() = prefs.getBoolean(KEY_EMOJI_ARTWORK, true)
        set(value) = prefs.edit().putBoolean(KEY_EMOJI_ARTWORK, value).apply()

    fun snapshot() = BackgroundSettingsSnapshot(
        backgroundProcessing = backgroundProcessing,
        processStickers = processStickers,
        processedNotifications = processedNotifications,
        alternateEmojiArtwork = alternateEmojiArtwork,
    )
}
