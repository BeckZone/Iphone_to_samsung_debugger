package app.pigeonbridge.android.ui.screens

import app.pigeonbridge.android.emoji.EmojiText
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.pigeonbridge.android.monitoring.MonitoringState
import app.pigeonbridge.android.ui.PigeonCard

/**
 * Debug-only (gated at the nav-host level, same pattern as DiagnosticScreen)
 * view for confirming the listener is actually alive and seeing what
 * Samsung/Google Messages' notifications really carry -- without having to
 * guess from documentation. Metadata only, per spec -- no full message text
 * is ever stored (see MonitoringState.LastNotificationSnapshot).
 */
@Composable
fun NotificationTestScreen(onBack: () -> Unit) {
    if (!app.pigeonbridge.android.BuildConfig.DEBUG) {
        Scaffold(topBar = { TopAppBar(title = { Text("Notification Test") }) }) { padding ->
            Text("Debug builds only.", modifier = Modifier.padding(padding).padding(20.dp))
        }
        return
    }

    val context = LocalContext.current
    val notificationAccess = MonitoringState.notificationAccessGranted(context)
    val listenerActive = MonitoringState.listenerServiceActive()
    val snapshot = MonitoringState.lastNotificationSnapshot()
    val event = MonitoringState.lastAttachmentEvent()

    Scaffold(topBar = { TopAppBar(title = { Text("Notification Test") }) }) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
            PigeonCard {
                Text(
                    "Send a message/image to this device from another phone. PigeonBridge will inspect the resulting notification if Samsung Messages exposes usable attachment data.",
                    fontSize = 13.sp,
                )
            }

            PigeonCard(modifier = Modifier.padding(top = 12.dp)) {
                Column {
                    Text("Live state", fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp))
                    Row("Notification access", if (notificationAccess) "Enabled" else "Disabled")
                    Row("Listener activity", if (listenerActive) "Active" else "Not observed")
                    Row("Last observed notification", snapshot?.let { "${it.packageName} @ ${it.postedAtMillis}" } ?: "None yet")
                    Row("Last extraction attempt", event?.attachmentSource ?: "None yet")
                    Row("Last result", event?.processingResult ?: "None yet")
                }
            }

            if (snapshot == null) {
                PigeonCard(modifier = Modifier.padding(top = 12.dp)) {
                    Text("No relevant notification received yet.", fontSize = 13.sp, color = Color(0xFFA8A3C7))
                }
            } else {
                PigeonCard(modifier = Modifier.padding(top = 12.dp)) {
                    Column {
                        Text("Last notification details", fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp))
                        Row("Package", snapshot.packageName)
                        Row("Posted at", snapshot.postedAtMillis.toString())
                        Row("EXTRA_PICTURE present", snapshot.hasExtraPicture.toString())
                        Row("EXTRA_PICTURE_ICON present", snapshot.hasExtraPictureIcon.toString())
                        Row("MessagingStyle message count", snapshot.messagingStyleMessageCount.toString())
                        Row("MessagingStyle dataUri count", snapshot.messagingStyleDataUriCount.toString())
                        Row("Discovered Uri authority", snapshot.discoveredUriAuthority ?: "None")
                        Text("Extra keys (name:type):", fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                        snapshot.extraKeyTypes.forEach {
                            Text("  $it", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = Color(0xFFA8A3C7))
                        }
                        if (snapshot.textPreviewTruncated != null) {
                            EmojiText(
                                "Text preview (truncated): ${snapshot.textPreviewTruncated}",
                                fontSize = 11.sp,
                                color = Color(0xFFA8A3C7),
                                modifier = Modifier.padding(top = 10.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}

// ---------------- small two-column row ----------------

@Composable
private fun Row(label: String, value: String) {
    androidx.compose.foundation.layout.Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween,
    ) {
        Text(label, fontSize = 12.sp, color = Color(0xFFA8A3C7))
        Text(value, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
    }
}
