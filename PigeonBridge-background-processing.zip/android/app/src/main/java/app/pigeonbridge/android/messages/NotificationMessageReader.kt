package app.pigeonbridge.android.messages

import android.app.Notification
import androidx.core.app.NotificationCompat

/**
 * Turns one messaging-app notification into message lines for the message-style view.
 *
 * It only reads text the messaging app itself put in the notification (sender and message
 * text). It does not read anything else, and the result goes only to the in-memory
 * [MessageFeed]. Callers are expected to have already checked that the notification comes
 * from an allow-listed messaging app.
 */
object NotificationMessageReader {

    fun read(
        packageName: String,
        notificationKey: String,
        postTime: Long,
        notification: Notification,
        styleMessages: List<NotificationCompat.MessagingStyle.Message>,
    ): List<FeedMessage> {
        // A group "summary" notification only repeats text from the individual ones.
        if ((notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return emptyList()

        val out = ArrayList<FeedMessage>()
        for (m in styleMessages) {
            val text = m.text?.toString()?.trim().orEmpty()
            if (text.isEmpty()) continue
            val sender = m.person?.name?.toString()?.trim()?.takeIf { it.isNotEmpty() } ?: UNKNOWN_SENDER
            out.add(
                FeedMessage(
                    key = "$packageName|$sender|${m.timestamp}|$text",
                    packageName = packageName,
                    sender = sender,
                    text = text,
                    timeMillis = if (m.timestamp > 0) m.timestamp else postTime,
                ),
            )
        }
        if (out.isNotEmpty()) return out

        // Not a MessagingStyle notification: fall back to the plain title/text fields.
        val extras = notification.extras
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: extras.getCharSequence(Notification.EXTRA_TEXT))
            ?.toString()?.trim().orEmpty()
        if (text.isEmpty()) return emptyList()
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim()?.takeIf { it.isNotEmpty() }
            ?: UNKNOWN_SENDER
        return listOf(
            FeedMessage(
                key = "$notificationKey|$postTime|$text",
                packageName = packageName,
                sender = title,
                text = text,
                timeMillis = postTime,
            ),
        )
    }

    private const val UNKNOWN_SENDER = "Unknown"
}
