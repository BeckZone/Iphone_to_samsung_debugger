import { detectMimeFromBytes, parsePngIhdr, countGifFrames, hasWebpAnimChunk } from "./byteparsers.ts";
import { classifyDetailed, classifyQuality } from "./classifier.ts";
import type { DiagnosticReport } from "./formatter.ts";

export interface AnalyzeResult {
  report: DiagnosticReport;
  previewObjectUrl: string | null;
}

const ALPHA_PROBE_MAX_DIMENSION = 256; // cap the canvas sample size purely for the transparency check -- never used for the on-screen preview

/**
 * Runs the full client-side diagnostic pipeline on a File the user
 * uploaded/dropped/shared. Everything here happens locally in the
 * browser -- nothing is uploaded anywhere. Mirrors the structure of
 * Android's DiagnosticRunner.run(), adapted to what a browser can
 * legitimately observe about a local File (no ContentResolver, no URI
 * permissions, no provider-exposed alternate representations -- those
 * concepts don't exist for a local file the user picked themselves).
 */
export async function analyzeFile(file: File): Promise<AnalyzeResult> {
  const arrayBuffer = await file.arrayBuffer();
  const bytes = new Uint8Array(arrayBuffer);

  const mimeDetected = detectMimeFromBytes(bytes);
  const mimeReported = file.type || null;
  const extension = file.name.includes(".") ? file.name.split(".").pop() ?? null : null;

  // Dimensions + decode test, via the browser's own image decoder (this IS
  // "the existing decoder" in the browser sense -- there's no separate
  // manual bitmap decode path to reuse the way Android has BitmapFactory;
  // createImageBitmap / <img> IS the platform decoder here).
  let decodeSucceeded = false;
  let widthPx = -1;
  let heightPx = -1;
  let previewObjectUrl: string | null = null;
  let hasAlpha: boolean | null = null;

  try {
    const objectUrl = URL.createObjectURL(file);
    previewObjectUrl = objectUrl;
    const bitmap = await loadImage(objectUrl);
    widthPx = bitmap.width;
    heightPx = bitmap.height;
    decodeSucceeded = true;
    hasAlpha = await probeAlpha(bitmap);
  } catch {
    decodeSucceeded = false;
  }

  let bitDepthDescription: string | null = null;
  const pngInfo = mimeDetected === "image/png" ? parsePngIhdr(bytes) : null;
  if (pngInfo) bitDepthDescription = pngInfo.description;

  let isAnimated: boolean | null = null;
  let frameCount: number | null = null;
  if (mimeDetected === "image/gif") {
    const frames = countGifFrames(bytes);
    frameCount = frames;
    isAnimated = frames != null ? frames > 1 : null;
  } else if (mimeDetected === "image/webp") {
    const animated = hasWebpAnimChunk(bytes);
    isAnimated = animated;
    frameCount = null; // WebP frame count needs a real decode we don't have access to client-side without a heavier library -- honestly "Unknown" rather than guessing
  } else if (mimeDetected === "image/png" || mimeDetected === "image/jpeg" || mimeDetected === "image/heic") {
    isAnimated = false; // these formats don't support animation at all -- an honest certainty, not a guess
    frameCount = 1;
  }

  const previewReasons: string[] = [];
  if (decodeSucceeded && (widthPx <= 64 || heightPx <= 64)) {
    previewReasons.push(`image dimensions are unusually small (${widthPx}x${heightPx})`);
  }
  if (mimeReported === "image/jpeg" && file.size > 0 && file.size <= 3_000 && (widthPx > 128 || heightPx > 128)) {
    previewReasons.push(`suspiciously small JPEG (${file.size} bytes for ${widthPx}x${heightPx})`);
  }
  const previewSuspected = previewReasons.length > 0;

  const detailed = classifyDetailed({
    mimeType: mimeDetected ?? mimeReported,
    displayName: file.name || null,
    widthPx,
    heightPx,
    hasAlpha,
    decodeFailed: !decodeSucceeded,
  });

  const quality = classifyQuality(widthPx, heightPx);

  const report: DiagnosticReport = {
    fileName: file.name || null,
    mimeReported,
    mimeDetectedFromBytes: mimeDetected,
    fileExtension: extension,
    sizeBytes: file.size,
    lastModifiedMillis: Number.isFinite(file.lastModified) ? file.lastModified : null,
    widthPx,
    heightPx,
    hasAlpha,
    bitDepthDescription,
    isAnimated,
    frameCount,
    previewSuspected,
    previewReasons,
    classification: detailed.classification,
    classificationSignals: detailed.signals,
    stickerScore: detailed.stickerScore,
    photoScore: detailed.photoScore,
    decodeSucceeded,
    decodedWidthPx: decodeSucceeded ? widthPx : null,
    decodedHeightPx: decodeSucceeded ? heightPx : null,
    quality: quality.quality,
    qualityReason: quality.reason,
  };

  return { report, previewObjectUrl };
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Image failed to decode"));
    img.src = src;
  });
}

/**
 * Samples a downscaled canvas render for any non-opaque alpha value.
 * Capped at ALPHA_PROBE_MAX_DIMENSION purely to keep this fast and
 * memory-light -- this never touches the full-resolution pixel data and
 * never affects what's shown in the preview `<img>` (that renders the
 * original file directly via its object URL, at full quality).
 */
async function probeAlpha(img: HTMLImageElement): Promise<boolean | null> {
  try {
    const scale = Math.min(1, ALPHA_PROBE_MAX_DIMENSION / Math.max(img.width, img.height));
    const w = Math.max(1, Math.round(img.width * scale));
    const h = Math.max(1, Math.round(img.height * scale));
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    if (!ctx) return null;
    ctx.drawImage(img, 0, 0, w, h);
    const data = ctx.getImageData(0, 0, w, h).data;
    for (let i = 3; i < data.length; i += 4) {
      if (data[i] < 255) return true;
    }
    return false;
  } catch {
    return null;
  }
}
