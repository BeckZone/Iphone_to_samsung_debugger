import pino from "pino";

export const logger = pino({
  level: process.env.LOG_LEVEL || "info",
  // Pretty-printing needs pino-pretty and is meant for local dev only; in
  // production (or if pino-pretty isn't installed) this falls back to plain
  // structured JSON lines, which is what you want piped into a log
  // aggregator anyway.
  transport:
    process.env.NODE_ENV !== "production"
      ? { target: "pino-pretty", options: { colorize: true, translateTime: "HH:MM:ss", ignore: "pid,hostname" } }
      : undefined,
});
