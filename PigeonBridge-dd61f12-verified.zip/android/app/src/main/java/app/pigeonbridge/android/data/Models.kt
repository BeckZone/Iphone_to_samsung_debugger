package app.pigeonbridge.android.data

import kotlinx.serialization.Serializable

// Mirrors shared/src/constants.ts GAME_TYPES. Keep in sync by hand since the
// Android app can't import the TS package directly.
enum class GameType(val wireValue: String) {
    CHECKERS("checkers"),
    DARTS("darts"),
    CHESS("chess"),
    CUP_PONG("cup_pong"),
    BASKETBALL("basketball"),
    EIGHT_BALL_POOL("eight_ball_pool");

    companion object {
        fun fromWire(value: String): GameType = entries.first { it.wireValue == value }
    }
}

// Mirrors shared/src/constants.ts IMPLEMENTED_GAMES — now all six. Checkers
// and Darts render as native Compose (CheckersBoard/DartsBoard in
// GameScreen.kt); the other four render via an embedded WebView pointed at
// the same /play page the browser client uses (see GameScreen.kt) rather
// than duplicating the canvas drag-physics UI a second time in Kotlin.
val IMPLEMENTED_GAMES = setOf(
    GameType.CHECKERS,
    GameType.DARTS,
    GameType.CHESS,
    GameType.CUP_PONG,
    GameType.BASKETBALL,
    GameType.EIGHT_BALL_POOL,
)

// Which implemented games get native Compose boards vs. the WebView fallback.
val NATIVE_COMPOSE_GAMES = setOf(GameType.CHECKERS, GameType.DARTS)

val GAME_DISPLAY_NAMES = mapOf(
    GameType.CHECKERS to "Checkers",
    GameType.DARTS to "Darts",
    GameType.CHESS to "Chess",
    GameType.CUP_PONG to "Cup Pong",
    GameType.BASKETBALL to "Basketball",
    GameType.EIGHT_BALL_POOL to "8-Ball Pool",
)

val GAME_EMOJI = mapOf(
    GameType.CHECKERS to "⚫",
    GameType.DARTS to "🎯",
    GameType.CHESS to "♟️",
    GameType.CUP_PONG to "🍺",
    GameType.BASKETBALL to "🏀",
    GameType.EIGHT_BALL_POOL to "🎱",
)

enum class PlayerSlot(val wireValue: String) {
    PLAYER1("player1"), PLAYER2("player2");

    companion object {
        fun fromWire(v: String) = entries.first { it.wireValue == v }
    }
}

@Serializable
data class PlayerInfoDto(
    val slot: String,
    val nickname: String,
    val connected: Boolean,
    val platform: String,
)

@Serializable
data class PublicGameSessionDto(
    val gameId: String,
    val gameType: String,
    val player1: PlayerInfoDto? = null,
    val player2: PlayerInfoDto? = null,
    val currentTurn: String,
    // Board is game-specific (checkers 2D array, darts score object, etc).
    // Kept as raw JsonElement in the ws client and decoded per-game — see
    // network/GameStateDecoders.kt — rather than a single fixed shape.
    val status: String,
    val yourSlot: String,
)

@Serializable
data class CreateGameResponseDto(
    val gameId: String,
    val joinUrl: String,
    val shareText: String,
)

@Serializable
data class GamePeekDto(
    val gameId: String,
    val gameType: String,
    val displayName: String,
    val status: String,
    val hostNickname: String? = null,
    val hasSecondPlayer: Boolean,
)

data class RecentGame(
    val gameId: String,
    val gameType: GameType,
    val opponentNickname: String?,
    val lastPlayedAt: Long,
)
