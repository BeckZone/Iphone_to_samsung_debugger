import * as esbuild from "esbuild";
import { mkdirSync, copyFileSync } from "fs";

mkdirSync("dist", { recursive: true });

await esbuild.build({
  entryPoints: ["src/home.ts", "src/play.ts"],
  bundle: true,
  outdir: "dist",
  format: "iife",
  target: "es2020",
  minify: true,
  sourcemap: true,
});

copyFileSync("src/home.html", "dist/index.html");
copyFileSync("src/play.html", "dist/play.html");

console.log("web build complete -> dist/");
