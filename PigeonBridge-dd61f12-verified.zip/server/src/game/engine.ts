import {
  GameType,
  IMPLEMENTED_GAMES,
  PlayerSlot,
  checkers,
  darts,
  chess,
  basketball,
  cuppong,
  eightball,
} from "@pigeonbridge/shared";

export function createInitialBoard(gameType: GameType): unknown {
  switch (gameType) {
    case "checkers":
      return checkers.createInitialCheckersBoard();
    case "darts":
      return darts.createInitialDartsBoard();
    case "chess":
      return chess.createInitialChessBoard();
    case "basketball":
      return basketball.createInitialBasketballBoard();
    case "cup_pong":
      return cuppong.createInitialCupPongBoard();
    case "eight_ball_pool":
      return eightball.createInitialEightBallBoard();
    default:
      return { notImplemented: true };
  }
}

export function isGameImplemented(gameType: GameType): boolean {
  return (IMPLEMENTED_GAMES as readonly GameType[]).includes(gameType);
}

export interface MoveResult {
  board: unknown;
  nextTurn: PlayerSlot;
  winner: PlayerSlot | "draw" | null;
}

function otherSlot(slot: PlayerSlot): PlayerSlot {
  return slot === "player1" ? "player2" : "player1";
}

/** 0 = cue, 1-7 solids, 8 = eight ball, 9-15 stripes. */
function ballSuit(id: number): "cue" | "solids" | "eight" | "stripes" {
  if (id === 0) return "cue";
  if (id === 8) return "eight";
  return id <= 7 ? "solids" : "stripes";
}

function suitFullyCleared(board: eightball.EightBallBoard, suit: eightball.Suit): boolean {
  const range = suit === "solids" ? [1, 2, 3, 4, 5, 6, 7] : [9, 10, 11, 12, 13, 14, 15];
  return range.every((id) => board.balls.find((b) => b.id === id)?.pocketed);
}

/**
 * Validates and applies `move` (submitted by `slot`) to `board` for the given
 * `gameType`. Throws a plain Error with a user-safe message on any illegal
 * move — the caller (ws handler) turns that into an `error` message and never
 * mutates session state on failure. This is the single point of truth for
 * "is this move legal", so a malicious or buggy client can't force bad state.
 */
export function applyMove(gameType: GameType, board: unknown, slot: PlayerSlot, move: unknown): MoveResult {
  switch (gameType) {
    case "checkers": {
      const b = board as checkers.CheckersBoard;
      const m = move as checkers.CheckersMove;
      if (
        typeof m?.fromRow !== "number" ||
        typeof m?.fromCol !== "number" ||
        typeof m?.toRow !== "number" ||
        typeof m?.toCol !== "number"
      ) {
        throw new Error("Malformed move");
      }
      const result = checkers.applyCheckersMove(b, slot, m);
      const nextTurn: PlayerSlot = result.mustContinueFrom ? slot : otherSlot(slot);
      const winner = checkers.checkersWinner(result.board, nextTurn);
      return { board: result.board, nextTurn, winner };
    }

    case "darts": {
      const b = board as darts.DartsBoard;
      const m = move as darts.DartsMove;
      if (!Array.isArray(m?.throws)) throw new Error("Malformed move");
      const nextBoard = darts.applyDartsMove(b, slot, m);
      const winner = darts.dartsWinner(nextBoard);
      const nextTurn: PlayerSlot = winner ? slot : otherSlot(slot);
      return { board: nextBoard, nextTurn, winner };
    }

    case "chess": {
      const b = board as chess.ChessBoard;
      const m = move as chess.ChessMove;
      if (typeof m?.from !== "string" || typeof m?.to !== "string") throw new Error("Malformed move");
      const nextBoard = chess.applyChessMove(b, slot, m);
      const outcome = chess.chessOutcome(nextBoard);
      const nextTurn = otherSlot(slot);
      const winner = outcome.over ? outcome.winner : null;
      return { board: nextBoard, nextTurn, winner };
    }

    case "basketball": {
      const b = board as basketball.BasketballBoard;
      const m = move as basketball.BasketballMove;
      if (typeof m?.angleDeg !== "number" || typeof m?.power !== "number") throw new Error("Malformed move");
      const nextBoard = basketball.applyBasketballMove(b, slot, m);
      const outcome = basketball.basketballOutcome(nextBoard);
      // Both players alternate single shots until each has taken all rounds.
      const nextTurn = otherSlot(slot);
      return { board: nextBoard, nextTurn, winner: outcome };
    }

    case "cup_pong": {
      const b = board as cuppong.CupPongBoard;
      const m = move as cuppong.CupPongMove;
      if (typeof m?.aimOffset !== "number" || typeof m?.angleDeg !== "number" || typeof m?.power !== "number") {
        throw new Error("Malformed move");
      }
      const nextBoard = cuppong.applyCupPongMove(b, slot, m);
      const winner = cuppong.cupPongWinner(nextBoard);
      const nextTurn: PlayerSlot = winner ? slot : otherSlot(slot);
      return { board: nextBoard, nextTurn, winner };
    }

    case "eight_ball_pool": {
      const b = board as eightball.EightBallBoard;
      const m = move as eightball.EightBallMove;
      if (typeof m?.angleDeg !== "number" || typeof m?.power !== "number") throw new Error("Malformed move");
      if (b.ballInHandFor && b.ballInHandFor !== slot) {
        throw new Error("Waiting for opponent to place the cue ball");
      }

      // mySuit BEFORE this shot decides legality; it may become assigned as a
      // result of this same shot on an open table.
      const mySuitBefore = b.assignedSuit[slot];
      const oppSuitBefore = b.assignedSuit[otherSlot(slot)];

      const raw = eightball.applyEightBallMove(b, slot, m);
      const shot = raw.lastShot!;
      const pocketedNonSpecial = shot.pocketedThisShot.filter((id) => id !== 0 && id !== 8);
      const eightPocketed = shot.pocketedThisShot.includes(8);

      // --- Determine foul ---
      let foul = false;
      let foulReason: string | null = null;
      if (shot.scratched) {
        foul = true;
        foulReason = "Scratch — cue ball pocketed";
      } else if (shot.firstContactBallId === null) {
        foul = true;
        foulReason = "No ball contacted";
      } else if (mySuitBefore) {
        const contactSuit = ballSuit(shot.firstContactBallId);
        const mustHitEight = suitFullyCleared(b, mySuitBefore);
        if (mustHitEight ? contactSuit !== "eight" : contactSuit !== mySuitBefore) {
          foul = true;
          foulReason = mustHitEight ? "Must hit the 8-ball first" : "Hit the wrong suit first";
        }
      }
      // else: open table (no suit assigned yet) — any first contact except an
      // immediate 8-ball hit is legal; we don't special-case the rare "only
      // the 8 remains on an open table" scenario here.
      else if (ballSuit(shot.firstContactBallId) === "eight") {
        foul = true;
        foulReason = "Can't hit the 8-ball first on an open table";
      }

      // --- Suit assignment on an open table ---
      const nextAssignedSuit = { ...b.assignedSuit };
      if (!mySuitBefore && !foul && pocketedNonSpecial.length > 0) {
        const firstPocketedSuit = ballSuit(pocketedNonSpecial[0]) as eightball.Suit;
        nextAssignedSuit[slot] = firstPocketedSuit;
        nextAssignedSuit[otherSlot(slot)] = firstPocketedSuit === "solids" ? "stripes" : "solids";
      }
      const mySuitAfter = nextAssignedSuit[slot];

      const pocketedOwnCount = mySuitAfter
        ? pocketedNonSpecial.filter((id) => ballSuit(id) === mySuitAfter).length
        : pocketedNonSpecial.length; // open table: any pocketed ball this shot counts as productive

      // --- 8-ball outcome ---
      let winner: PlayerSlot | "draw" | null = null;
      if (eightPocketed) {
        const clearedBeforeShot = mySuitBefore ? suitFullyCleared(b, mySuitBefore) : false;
        const legalEightPot = !foul && clearedBeforeShot && shot.firstContactBallId === 8;
        winner = legalEightPot ? slot : otherSlot(slot); // early/foul 8-ball pot = instant loss
      }

      const nextBoard: eightball.EightBallBoard = {
        balls: raw.balls,
        assignedSuit: nextAssignedSuit,
        ballInHandFor: foul ? otherSlot(slot) : null,
        lastShot: { ...shot, foul, foulReason },
      };

      const nextTurn: PlayerSlot = winner ? slot : foul || pocketedOwnCount === 0 ? otherSlot(slot) : slot;

      return { board: nextBoard, nextTurn, winner };
    }

    default:
      throw new Error(`${gameType} is not implemented yet`);
  }
}
