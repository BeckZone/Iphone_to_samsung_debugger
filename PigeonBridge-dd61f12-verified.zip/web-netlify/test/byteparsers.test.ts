import { test } from "node:test";
import assert from "node:assert/strict";
import { detectMimeFromBytes, parsePngIhdr, countGifFrames, hasWebpAnimChunk } from "../src/byteparsers.ts";

function bytesOf(...vals: (number | string)[]): Uint8Array {
  const out: number[] = [];
  for (const v of vals) {
    if (typeof v === "string") for (const ch of v) out.push(ch.charCodeAt(0));
    else out.push(v);
  }
  return new Uint8Array(out);
}

// ---- MIME sniffing, real magic bytes ----

test("detects PNG from real signature bytes", () => {
  const bytes = bytesOf(0x89, "PNG", 0x0d, 0x0a, 0x1a, 0x0a);
  assert.equal(detectMimeFromBytes(bytes), "image/png");
});

test("detects JPEG from real SOI marker", () => {
  const bytes = bytesOf(0xff, 0xd8, 0xff, 0xe0);
  assert.equal(detectMimeFromBytes(bytes), "image/jpeg");
});

test("detects WebP from real RIFF/WEBP header", () => {
  const bytes = bytesOf("RIFF", 0, 0, 0, 0, "WEBP");
  assert.equal(detectMimeFromBytes(bytes), "image/webp");
});

test("detects GIF89a", () => {
  const bytes = bytesOf("GIF89a");
  assert.equal(detectMimeFromBytes(bytes), "image/gif");
});

test("unrecognized bytes return null, never a guess", () => {
  const bytes = bytesOf(0x00, 0x01, 0x02, 0x03, 0x04, 0x05);
  assert.equal(detectMimeFromBytes(bytes), null);
});

// ---- Real, minimal, well-formed PNG IHDR ----

function buildMinimalPng(width: number, height: number, bitDepth: number, colorType: number): Uint8Array {
  const sig = [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a];
  const lengthBytes = [0, 0, 0, 13]; // IHDR data length is always 13
  const type = [...("IHDR" as string)].map((c) => c.charCodeAt(0));
  const w = [(width >>> 24) & 0xff, (width >>> 16) & 0xff, (width >>> 8) & 0xff, width & 0xff];
  const h = [(height >>> 24) & 0xff, (height >>> 16) & 0xff, (height >>> 8) & 0xff, height & 0xff];
  const rest = [bitDepth, colorType, 0, 0, 0]; // compression, filter, interlace (unused by our parser)
  return new Uint8Array([...sig, ...lengthBytes, ...type, ...w, ...h, ...rest]);
}

test("parses real PNG IHDR bit depth and color type (RGBA, 8-bit)", () => {
  const png = buildMinimalPng(512, 512, 8, 6);
  const ihdr = parsePngIhdr(png);
  assert.equal(ihdr?.bitDepth, 8);
  assert.equal(ihdr?.colorType, 6);
  assert.equal(ihdr?.description, "RGBA, 8-bit/channel");
});

test("parses real PNG IHDR for RGB (no alpha), 8-bit", () => {
  const png = buildMinimalPng(100, 100, 8, 2);
  const ihdr = parsePngIhdr(png);
  assert.equal(ihdr?.description, "RGB, 8-bit/channel");
});

test("returns null for a non-PNG buffer", () => {
  assert.equal(parsePngIhdr(bytesOf(0xff, 0xd8, 0xff)), null);
});

// ---- Real, minimal, well-formed GIF with a known frame count ----

function buildMinimalGif(frameCount: number): Uint8Array {
  const out: number[] = [];
  out.push(..."GIF89a".split("").map((c) => c.charCodeAt(0)));
  // Logical screen descriptor: width(2) height(2) packed(1, no GCT) bg(1) aspect(1)
  out.push(1, 0, 1, 0, 0x00, 0, 0);
  for (let i = 0; i < frameCount; i++) {
    // Image descriptor: 0x2C, left(2) top(2) width(2) height(2) packed(1, no LCT)
    out.push(0x2c, 0, 0, 0, 0, 1, 0, 1, 0, 0x00);
    out.push(2); // LZW minimum code size
    out.push(2, 0x00, 0x01, 0x00); // one sub-block of 2 bytes, then terminator
  }
  out.push(0x3b); // trailer
  return new Uint8Array(out);
}

test("counts frames in a real single-frame GIF", () => {
  assert.equal(countGifFrames(buildMinimalGif(1)), 1);
});

test("counts frames in a real multi-frame (animated) GIF", () => {
  assert.equal(countGifFrames(buildMinimalGif(5)), 5);
});

test("returns null for a non-GIF buffer", () => {
  assert.equal(countGifFrames(bytesOf(0x89, "PNG")), null);
});

// ---- WebP ANIM chunk detection ----

test("detects a real ANIM chunk in a WebP-shaped buffer", () => {
  const bytes = bytesOf("RIFF", 0, 0, 0, 0, "WEBP", "VP8X", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "ANIM", 0, 0, 0, 0);
  assert.equal(hasWebpAnimChunk(bytes), true);
});

test("static WebP (no ANIM chunk) is not flagged animated", () => {
  const bytes = bytesOf("RIFF", 0, 0, 0, 0, "WEBP", "VP8 ", 0, 0, 0, 0, 1, 2, 3, 4, 5, 6);
  assert.equal(hasWebpAnimChunk(bytes), false);
});

test("non-WebP buffer is never flagged animated by this check", () => {
  assert.equal(hasWebpAnimChunk(bytesOf(0x89, "PNG")), false);
});
