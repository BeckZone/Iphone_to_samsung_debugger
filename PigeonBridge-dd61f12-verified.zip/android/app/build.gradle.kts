plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.serialization")
}

// Signing credentials: never hardcoded here. Resolution order —
//  1. local.properties (gitignored; put PIGEONBRIDGE_STORE_PASSWORD= etc there for local release builds)
//  2. environment variables (what CI / GitHub Actions secrets set — see .github/workflows/android-build.yml)
//  3. the repo's checked-in DEV keystore's known dev credentials, as a last-resort
//     fallback purely so `./gradlew assembleRelease` still works out of the box
//     for anyone who just cloned the repo to try it — see keystore/README.md.
//     This fallback is intentionally only the dev key's own (already-public-in-this-repo)
//     credentials; a real production keystore's password must never have a source fallback.
val localProps = java.util.Properties().apply {
    val f = rootProject.file("local.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
fun secret(propKey: String, envKey: String, devFallback: String): String {
    val fromProps = localProps.getProperty(propKey)?.takeIf { it.isNotBlank() }
    val fromEnv = System.getenv(envKey)?.takeIf { it.isNotBlank() }
    return fromProps ?: fromEnv ?: devFallback
}

android {
    namespace = "app.pigeonbridge.android"
    compileSdk = 34

    defaultConfig {
        applicationId = "app.pigeonbridge.android"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
    }

    signingConfigs {
        create("release") {
            // Matches the keystore used to generate /.well-known/assetlinks.json's
            // sha256_cert_fingerprints (server/public/.well-known/assetlinks.json)
            // when using the checked-in dev keystore. Point PIGEONBRIDGE_KEYSTORE_PATH
            // at your own keystore for a real release — see keystore/README.md.
            storeFile = file(secret("PIGEONBRIDGE_KEYSTORE_PATH", "PIGEONBRIDGE_KEYSTORE_PATH", "../keystore/pigeonbridge-release.keystore"))
            storePassword = secret("PIGEONBRIDGE_STORE_PASSWORD", "PIGEONBRIDGE_STORE_PASSWORD", "pigeonbridge123")
            keyAlias = secret("PIGEONBRIDGE_KEY_ALIAS", "PIGEONBRIDGE_KEY_ALIAS", "pigeonbridge")
            keyPassword = secret("PIGEONBRIDGE_KEY_PASSWORD", "PIGEONBRIDGE_KEY_PASSWORD", "pigeonbridge123")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true // BuildConfig.DEBUG is used to gate attachment-pipeline debug logging
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    testOptions {
        unitTests {
            // StickerDetectorTest is a plain JVM test with no Robolectric.
            // StickerDetector calls into AttachmentDebugLog, which touches
            // android.util.Log — without this, that throws
            // "Method d in android.util.Log not mocked" under plain JUnit.
            // This makes any accidental android.* framework call in a unit
            // test return a harmless default instead of crashing the test.
            isReturnDefaultValues = true
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.4")
    implementation("androidx.activity:activity-compose:1.9.1")
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.navigation:navigation-compose:2.7.7")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("io.coil-kt:coil-compose:2.6.0")
    implementation("io.coil-kt:coil-gif:2.6.0") // animated WebP/GIF sticker rendering, same library already used for AsyncImage
    implementation("androidx.exifinterface:exifinterface:1.3.7") // EXIF orientation for sticker/attachment recovery
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.3")
    implementation("androidx.datastore:datastore-preferences:1.1.1")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
}
