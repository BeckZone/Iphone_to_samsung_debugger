# Background monitoring: what Android actually allows

This is the investigation the rest of this package is built on. Read this
before touching PigeonBridgeNotificationListener.kt or
DefaultSmsRoleHelper.kt — it explains *why* they're built the way they are,
and where the hard ceiling is.

## 1. NotificationListenerService — can it see Samsung Messages notifications?

Yes. Once the user grants Notification Access (a special access grant in
Settings, not a manifest permission), a NotificationListenerService receives
`onNotificationPosted()` for every notification posted by every app on the
device, including Samsung Messages. This part is well documented and
reliable.

## 2. Does the notification expose the actual attachment?

This is the real question, and the honest answer is: **usually no, not the
original file — sometimes a low-resolution preview, and it varies by app
version, so it must be verified empirically per-device.** Here's why:

- Most messaging apps build their "new message with photo" notification
  using `NotificationCompat.BigPictureStyle` or `MessagingStyle`. Both
  typically embed a **Bitmap the app already downscaled/re-encoded for
  notification display** — via `Notification.EXTRA_PICTURE` (a raw
  `Bitmap`, still populated by many apps despite being marked legacy) or
  `Notification.EXTRA_PICTURE_ICON` (an `Icon`, API 23+, which can wrap
  either a Bitmap *or* a `content://` Uri).
- **If** `EXTRA_PICTURE_ICON` wraps a Uri (`Icon.getType() ==
  Icon.TYPE_URI`), that Uri is usually granted only to the system process
  that renders the notification (SystemUI/launcher), not to arbitrary
  third-party listener apps. A `ContentResolver.openInputStream()` call
  from PigeonBridge against that Uri would be expected to throw a
  `SecurityException` in the common case — but this cannot be stated as an
  absolute universal rule for every OEM/app version, so **this code tests
  it directly and reports the real result** rather than assuming either way.
- `NotificationCompat.MessagingStyle.Message.getDataUri()` (API 28+) is a
  real, documented API for messages with attached media, and if Samsung
  Messages populates it, it's the best-case path. Same caveat applies: the
  Uri may or may not actually be openable by us. Tested, not assumed.
- Even in the best case where a Bitmap **is** embedded in the notification,
  it is very likely already a preview/thumbnail the messaging app generated
  for notification display — not guaranteed to be the same file quality
  as what's shown inside the Messages app itself, and almost certainly not
  the original iMessage/GamePigeon-quality asset if any client-side
  recompression happened anywhere in the iPhone -> RCS -> Samsung ->
  notification pipeline.

**Bottom line: there is no version of this feature that can honestly promise
"the original attachment." The listener reports exactly what it received,
and whether a direct read of any discovered Uri actually succeeded, every
time — see AttachmentEvent.attachmentSource and DiagnosticRunner-style
readability fields threaded through to the Diagnostics screen.**

## 3. Default SMS role — does it help?

`RoleManager.ROLE_SMS` gives the holder read/write access to the standard
Android Telephony **SMS and MMS** content providers (`content://sms`,
`content://mms`, including `content://mms/part/{id}` for MMS attachment
binaries). For traditional MMS, this is real, documented, and would
actually work.

**For RCS specifically, this does NOT reliably apply.** RCS on Samsung
devices is typically handled by Samsung's own proprietary RCS stack (or
Google's Jibe/Messages RCS stack, depending on carrier and device
configuration) via IMS, layered on top of — but architecturally separate
from — the classic SMS/MMS Telephony provider. There is no public Android
API that guarantees a default SMS app receives RCS message content or
attachments through the standard provider. Some OEM/carrier
implementations partially mirror RCS messages into the MMS provider for
compatibility; many do not, especially for rich content like stickers.
**This project does not claim RCS support via the SMS role, because there
is no public API that guarantees it exists**, per the explicit instruction
not to overclaim this.

Becoming the default SMS app is also a large behavior change for the user
(it replaces their messaging app for sending texts), and Android requires
a candidate app to implement a working SMS/MMS handler (SMS_DELIVER
receiver, WAP_PUSH_DELIVER receiver, a SENDTO-handling compose activity,
RESPOND_VIA_MESSAGE service) to even be *offered* the role by RoleManager.
**This project implements the role-request button and explanation screen,
and calls the real RoleManager API — but does not implement a full SMS/MMS
client**, since that's a separate, large undertaking on its own and,
per the investigation above, would not solve the RCS/sticker problem even
if built. If RoleManager reports PigeonBridge isn't eligible, the app says
so plainly instead of pretending the button did something.

## 4. What Samsung Messages exposes to third parties, generally

There is no published Samsung SDK or public API for third-party apps to
read RCS message attachments from Samsung Messages. Nothing in this project
relies on undocumented behavior, private APIs, accessibility abuse,
overlays, or root — per the explicit instruction — which is exactly why
the answer to "can we get the real attachment" is "sometimes, empirically,
via whatever the notification happens to expose" rather than "yes."

## Conclusion / what this package actually implements

1. A `NotificationListenerService` that detects Samsung Messages
   notifications (event-driven, no polling), extracts whatever
   Android/Samsung Messages legitimately exposes in the notification's
   extras, and **tests** (not assumes) whether any discovered Uri is
   actually readable.
2. When something readable is found, it's handed to the **existing**
   `AttachmentInspector` / `StickerDetector` / `AttachmentBitmapDecoder`
   pipeline — unmodified, no duplicated logic.
3. When nothing usable is exposed, that fact is recorded and surfaced
   honestly (diagnostics + no false "processed" notification).
4. A RoleManager-based default-SMS-role request flow, opt-in, clearly
   labeled as MMS-only in effect and NOT a solution for RCS.
