import { test } from "node:test";
import assert from "node:assert/strict";
import { chess } from "@pigeonbridge/shared";

test("initial position has 20 legal moves and starts as White (player1) to move", () => {
  const board = chess.createInitialChessBoard();
  const moves = chess.allLegalMoves(board);
  assert.equal(moves.length, 20);
});

test("legal move updates FEN and last move", () => {
  let board = chess.createInitialChessBoard();
  board = chess.applyChessMove(board, "player1", { from: "e2", to: "e4" });
  assert.ok(board.fen.includes("4P3"), "pawn should have advanced to e4");
  assert.deepEqual(board.lastMove, { from: "e2", to: "e4" });
});

test("illegal move throws", () => {
  const board = chess.createInitialChessBoard();
  assert.throws(() => chess.applyChessMove(board, "player1", { from: "e2", to: "e5" }));
});

test("wrong-color move (playing out of turn) throws", () => {
  const board = chess.createInitialChessBoard();
  assert.throws(() => chess.applyChessMove(board, "player2", { from: "e7", to: "e5" }));
});

test("fool's mate is detected as checkmate, black (player2) wins", () => {
  let board = chess.createInitialChessBoard();
  board = chess.applyChessMove(board, "player1", { from: "f2", to: "f3" });
  board = chess.applyChessMove(board, "player2", { from: "e7", to: "e5" });
  board = chess.applyChessMove(board, "player1", { from: "g2", to: "g4" });
  board = chess.applyChessMove(board, "player2", { from: "d8", to: "h4" });
  const outcome = chess.chessOutcome(board);
  assert.deepEqual(outcome, { over: true, winner: "player2", reason: "checkmate" });
});

test("stalemate is detected as a draw", () => {
  // A known stalemate position: Black to move, no legal moves, not in check.
  const board: chess.ChessBoard = {
    fen: "7k/5Q2/6K1/8/8/8/8/8 b - - 0 1",
    pgn: "",
    lastMove: null,
  };
  const outcome = chess.chessOutcome(board);
  assert.deepEqual(outcome, { over: true, winner: "draw", reason: "stalemate" });
});

test("pawn promotion produces a queen (or requested piece)", () => {
  const board: chess.ChessBoard = {
    fen: "8/P6k/8/8/8/8/7K/8 w - - 0 1",
    pgn: "",
    lastMove: null,
  };
  const promoted = chess.applyChessMove(board, "player1", { from: "a7", to: "a8", promotion: "q" });
  assert.ok(promoted.fen.startsWith("Q7"), `expected promoted queen on a8, got fen: ${promoted.fen}`);
});
