import { test } from "node:test";
import assert from "node:assert/strict";
import http from "http";
import { WebSocket, WebSocketServer } from "ws";
import express from "express";
import cors from "cors";
import { gamesRouter } from "../src/routes/games";
import { attachWebSocketServer } from "../src/ws/handler";
import { checkers } from "@pigeonbridge/shared";

function startServer(): Promise<{ url: string; wsUrl: string; close: () => Promise<void> }> {
  const app = express();
  app.use(cors());
  app.use(express.json());
  app.use("/api", gamesRouter);
  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: "/ws" });
  attachWebSocketServer(wss);
  return new Promise((resolve) => {
    server.listen(0, () => {
      const address = server.address();
      const port = typeof address === "object" && address ? address.port : 0;
      resolve({
        url: `http://127.0.0.1:${port}`,
        wsUrl: `ws://127.0.0.1:${port}/ws`,
        close: () => new Promise((r) => server.close(() => r())),
      });
    });
  });
}

function waitForMessage(ws: WebSocket, type: string, timeoutMs = 3000): Promise<any> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`Timed out waiting for ${type}`)), timeoutMs);
    const handler = (raw: any) => {
      const msg = JSON.parse(raw.toString());
      if (msg.type === type) {
        clearTimeout(timer);
        ws.off("message", handler);
        resolve(msg);
      }
    };
    ws.on("message", handler);
  });
}

test("full flow: create game via REST, two players join over WS, play a move, disconnect handling", async () => {
  const { url, wsUrl, close } = await startServer();
  try {
    // 1. Create game via REST (mirrors what the web "Create Game" button does)
    const createRes = await fetch(`${url}/api/games`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ gameType: "checkers", nickname: "Alice" }),
    });
    assert.equal(createRes.status, 201);
    const { gameId, joinUrl } = (await createRes.json()) as any;
    assert.equal(gameId.length, 6);
    assert.ok(joinUrl.includes(gameId));

    // 2. Both players connect over WebSocket and join
    const ws1 = new WebSocket(wsUrl);
    await new Promise((r) => ws1.once("open", r));
    ws1.send(JSON.stringify({ type: "join", gameId, nickname: "Alice", platform: "web" }));
    const joined1 = await waitForMessage(ws1, "joined");
    assert.equal(joined1.session.yourSlot, "player1");
    assert.equal(joined1.session.status, "waiting_for_opponent");

    const ws2 = new WebSocket(wsUrl);
    await new Promise((r) => ws2.once("open", r));
    const opponentJoinedP = waitForMessage(ws1, "opponent_joined");
    ws2.send(JSON.stringify({ type: "join", gameId, nickname: "Bob", platform: "android" }));
    const joined2 = await waitForMessage(ws2, "joined");
    assert.equal(joined2.session.yourSlot, "player2");
    assert.equal(joined2.session.status, "in_progress");
    const opponentJoined = await opponentJoinedP;
    assert.equal(opponentJoined.session.status, "in_progress");

    // 3. Player1 (Alice) makes the opening move
    const board = checkers.createInitialCheckersBoard();
    const legalMove = checkers.legalMovesFor(board, "player1")[0];
    const stateUpdateP = waitForMessage(ws2, "state_update");
    ws1.send(JSON.stringify({ type: "make_move", gameId, move: legalMove }));
    const update = await stateUpdateP;
    assert.equal(update.session.currentTurn, "player2");

    // 4. Out-of-turn move is rejected
    const errorP = waitForMessage(ws1, "error");
    ws1.send(JSON.stringify({ type: "make_move", gameId, move: legalMove }));
    const err = await errorP;
    assert.equal(err.code, "not_your_turn");

    // 5. Disconnect notifies the opponent
    const disconnectedP = waitForMessage(ws2, "opponent_disconnected");
    ws1.close();
    const disconnectMsg = await disconnectedP;
    assert.ok(disconnectMsg.graceMs > 0);

    ws2.close();
  } finally {
    await close();
  }
});

test("REST: unknown game id returns 404", async () => {
  const { url, close } = await startServer();
  try {
    const res = await fetch(`${url}/api/games/ZZZZZZ`);
    assert.equal(res.status, 404);
  } finally {
    await close();
  }
});

test("REST: missing nickname returns 400", async () => {
  const { url, close } = await startServer();
  try {
    const res = await fetch(`${url}/api/games`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ gameType: "checkers" }),
    });
    assert.equal(res.status, 400);
  } finally {
    await close();
  }
});
