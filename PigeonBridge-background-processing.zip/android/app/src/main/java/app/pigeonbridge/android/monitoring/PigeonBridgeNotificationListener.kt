package app.pigeonbridge.android.monitoring

import android.app.Notification
import android.app.PendingIntent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.FileProvider
import app.pigeonbridge.android.MainActivity
import app.pigeonbridge.android.attachment.AttachmentBitmapDecoder
import app.pigeonbridge.android.attachment.AttachmentClassification
import app.pigeonbridge.android.attachment.AttachmentInspector
import app.pigeonbridge.android.attachment.AttachmentQualityClassifier
import app.pigeonbridge.android.attachment.StickerDetector
import app.pigeonbridge.android.background.BackgroundMessagePipeline
import app.pigeonbridge.android.background.BackgroundSettings
import app.pigeonbridge.android.background.EventGate
import app.pigeonbridge.android.background.MessageEventPolicy
import java.io.File
import java.io.FileOutputStream

/**
 * Event-driven monitoring of Samsung/Google Messages notifications. Never
 * polls -- onNotificationPosted() only fires when the system actually has a
 * new notification to deliver, so there is no background CPU/battery cost
 * beyond handling real events (spec: "React to actual system events").
 *
 * See ARCHITECTURE.md in this package for the full investigation this is
 * built on. Short version: this service tests, per event, whether Android
 * legitimately exposes a usable attachment -- it never assumes so, and
 * every outcome (including "nothing usable was exposed") is recorded in
 * MonitoringState for the Diagnostics screen.
 *
 * Reuses the EXISTING attachment package as-is: AttachmentInspector,
 * StickerDetector, AttachmentBitmapDecoder. Nothing here reimplements any
 * of that logic -- this class's only job is turning "a notification was
 * posted" into "a Uri that pipeline can process, if one legitimately
 * exists."
 *
 * Every entry point below is wrapped defensively: an unusual or malformed
 * notification from Samsung Messages (or a future OS/app version this
 * wasn't tested against) must never crash this service. Worst case, an
 * event goes unrecorded rather than the listener dying.
 */
class PigeonBridgeNotificationListener : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        // The system confirming it bound to us -- see MonitoringState.recordListenerConnected's
        // doc for why this is tracked separately from the Settings-level access grant.
        runCatching { MonitoringState.recordListenerConnected() }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        // Top-level guard: whatever happens below, this callback must never throw back into the
        // system (spec: "The service must NEVER crash because Samsung Messages produced an
        // unusual notification").
        try {
            handleNotificationPosted(sbn)
        } catch (t: Throwable) {
            runCatching {
                MonitoringState.recordAttachmentEvent(
                    LastAttachmentEvent(
                        messagingPackage = sbn.packageName,
                        notificationTimestampMillis = sbn.postTime,
                        attachmentExposed = false,
                        attachmentUriAvailable = false,
                        extractionSucceeded = false,
                        attachmentMime = null,
                        attachmentSizeBytes = null,
                        attachmentDimensions = null,
                        stickerClassification = null,
                        qualityClassification = null,
                        processingResult = "Notification parsing failed unexpectedly.",
                        failureReason = "${t.javaClass.simpleName}: ${t.message ?: "no message"}",
                        attachmentSource = "none",
                    ),
                )
            }
        }
    }

    private fun handleNotificationPosted(sbn: StatusBarNotification) {
        val packageName = sbn.packageName
        // Same two checks as before, now in one tested place (MessageEventPolicy): unrelated apps
        // are ignored first, then the user-facing "Disable Monitoring" / background switch.
        if (MessageEventPolicy.gate(packageName, MonitoringState.monitoringEnabled) != EventGate.PROCESS) return

        val notification = sbn.notification ?: return
        val extras = notification.extras

        // Metadata-only snapshot for the debug Notification Test screen -- key NAMES and object
        // TYPES only, never values, and only a short truncated text preview, per spec section 4.
        val messagingStyle = runCatching { NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(notification) }.getOrNull()
        val messages = messagingStyle?.messages.orEmpty()
        val dataUriCount = messages.count { it.dataUri != null }
        val firstDiscoveredUri = messages.firstOrNull { it.dataUri != null }?.dataUri
            ?: extractUriIcon(notification)?.uri

        val extraKeyTypes = runCatching {
            extras.keySet().map { key ->
                val value = extras.get(key)
                "$key:${value?.javaClass?.simpleName ?: "null"}"
            }
        }.getOrDefault(emptyList())

        MonitoringState.recordNotificationSnapshot(
            LastNotificationSnapshot(
                packageName = packageName,
                postedAtMillis = sbn.postTime,
                hasExtraPicture = extras.containsKey(Notification.EXTRA_PICTURE),
                hasExtraPictureIcon = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && extras.containsKey(Notification.EXTRA_PICTURE_ICON),
                messagingStyleMessageCount = messages.size,
                messagingStyleDataUriCount = dataUriCount,
                extraKeyTypes = extraKeyTypes,
                discoveredUriAuthority = firstDiscoveredUri?.let { "${it.scheme}://${it.authority}" },
                textPreviewTruncated = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.take(40),
            ),
        )

        // Text/emoji half of background processing (chat view feed, diagnostics, optional processed
        // notification). Isolated in its own runCatching and placed BEFORE attachment processing,
        // so a problem here can never affect sticker handling and vice versa.
        runCatching {
            BackgroundMessagePipeline.handle(this, packageName, sbn.key, sbn.postTime, notification, messages)
        }

        if (!BackgroundSettings.processStickers) {
            // The user turned sticker processing off. Say so in diagnostics instead of silently doing nothing.
            MonitoringState.recordAttachmentEvent(
                LastAttachmentEvent(
                    messagingPackage = packageName,
                    notificationTimestampMillis = sbn.postTime,
                    attachmentExposed = false,
                    attachmentUriAvailable = false,
                    extractionSucceeded = false,
                    attachmentMime = null,
                    attachmentSizeBytes = null,
                    attachmentDimensions = null,
                    stickerClassification = null,
                    qualityClassification = null,
                    processingResult = "Sticker processing is switched off in Background Message Processing settings.",
                    failureReason = null,
                    attachmentSource = "none",
                ),
            )
            return
        }
        processForAttachment(packageName, sbn.postTime, notification, messages)
    }

    private fun extractUriIcon(notification: Notification): android.graphics.drawable.Icon? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return null
        val icon = notification.extras.getParcelable<android.graphics.drawable.Icon>(Notification.EXTRA_PICTURE_ICON)
        return if (icon?.type == android.graphics.drawable.Icon.TYPE_URI) icon else null
    }

    private fun processForAttachment(
        packageName: String,
        postTime: Long,
        notification: Notification,
        messagingStyleMessages: List<NotificationCompat.MessagingStyle.Message>,
    ) {
        // Try, in order of preference, the legitimate places Android lets a
        // messaging notification carry media. Each attempt is REAL -- if a
        // Uri is found, we actually try to open it and report what happens,
        // rather than assuming access.
        var attachmentSource = "none"
        var workingUri: Uri? = null
        var uriWasDirectlyReadable = false
        var lastFailureReason: String? = null

        // Attempt 1: MessagingStyle.Message.dataUri (API 28+) -- the most "intended for this" API.
        val messageWithData = messagingStyleMessages.firstOrNull { it.dataUri != null }
        if (messageWithData?.dataUri != null) {
            val uri = messageWithData.dataUri!!
            val readResult = tryRead(uri)
            if (readResult == null) {
                workingUri = uri
                uriWasDirectlyReadable = true
                attachmentSource = "MessagingStyle.Message.dataUri"
            } else {
                lastFailureReason = "MessagingStyle.Message.dataUri present but not readable: $readResult"
            }
        }

        // Attempt 2: EXTRA_PICTURE_ICON, if it wraps a content Uri rather than raw bitmap bytes.
        if (workingUri == null) {
            val icon = extractUriIcon(notification)
            val uri = icon?.uri
            if (uri != null) {
                val readResult = tryRead(uri)
                if (readResult == null) {
                    workingUri = uri
                    uriWasDirectlyReadable = true
                    attachmentSource = "EXTRA_PICTURE_ICON (Uri-backed)"
                } else {
                    lastFailureReason = "EXTRA_PICTURE_ICON Uri present but not readable: $readResult"
                }
            }
        }

        // Attempt 3: embedded Bitmap fallback -- EXTRA_PICTURE_ICON (bitmap-backed) or the legacy EXTRA_PICTURE.
        // This is almost certainly a preview/thumbnail the messaging app generated for the notification
        // itself, NOT guaranteed to be the original attachment -- labeled as such below, never claimed
        // as "recovered original".
        var embeddedBitmap: Bitmap? = null
        if (workingUri == null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val icon = notification.extras.getParcelable<android.graphics.drawable.Icon>(Notification.EXTRA_PICTURE_ICON)
                if (icon != null && icon.type == android.graphics.drawable.Icon.TYPE_BITMAP) {
                    embeddedBitmap = runCatching { icon.loadDrawable(this) }.getOrNull()?.let { drawableToBitmap(it) }
                }
            }
            if (embeddedBitmap == null) {
                @Suppress("DEPRECATION")
                embeddedBitmap = runCatching { notification.extras.getParcelable<Bitmap>(Notification.EXTRA_PICTURE) }.getOrNull()
            }
            if (embeddedBitmap != null) {
                val cachedUri = cacheBitmapAsUri(embeddedBitmap)
                if (cachedUri != null) {
                    workingUri = cachedUri
                    uriWasDirectlyReadable = false // this is our own cache copy, not a direct read of the source
                    attachmentSource = "notification-embedded bitmap (EXTRA_PICTURE / EXTRA_PICTURE_ICON) -- likely a preview, not the original file"
                } else {
                    lastFailureReason = "Embedded bitmap found but could not be cached to a Uri"
                }
            }
        }

        if (workingUri == null) {
            MonitoringState.recordAttachmentEvent(
                LastAttachmentEvent(
                    messagingPackage = packageName,
                    notificationTimestampMillis = postTime,
                    attachmentExposed = false,
                    attachmentUriAvailable = false,
                    extractionSucceeded = false,
                    attachmentMime = null,
                    attachmentSizeBytes = null,
                    attachmentDimensions = null,
                    stickerClassification = null,
                    qualityClassification = null,
                    processingResult = "Samsung Messages notification did not expose the attachment.",
                    failureReason = lastFailureReason,
                    attachmentSource = "none",
                ),
            )
            return // no result notification -- nothing usable happened, don't spam the user
        }

        // Reuse the EXISTING pipeline exactly as ShareReceiverScreen does. No duplicated logic.
        val info = runCatching { AttachmentInspector.inspect(this, workingUri) }.getOrNull()
        if (info == null) {
            MonitoringState.recordAttachmentEvent(
                LastAttachmentEvent(
                    messagingPackage = packageName,
                    notificationTimestampMillis = postTime,
                    attachmentExposed = true,
                    attachmentUriAvailable = uriWasDirectlyReadable,
                    extractionSucceeded = false,
                    attachmentMime = null,
                    attachmentSizeBytes = null,
                    attachmentDimensions = null,
                    stickerClassification = null,
                    qualityClassification = null,
                    processingResult = "A Uri was found, but attachment inspection failed.",
                    failureReason = "AttachmentInspector.inspect threw an exception",
                    attachmentSource = attachmentSource,
                ),
            )
            return
        }

        val detailed = StickerDetector.classifyDetailed(info)
        val decoded = runCatching { AttachmentBitmapDecoder.decode(this, workingUri, info) }.getOrNull()
        val quality = AttachmentQualityClassifier.classify(info.widthPx, info.heightPx)

        val resultText = when {
            decoded == null -> "Attachment was exposed but could not be decoded."
            !uriWasDirectlyReadable -> "Processed a notification-embedded preview image (likely low-resolution; the original attachment file was not directly accessible)."
            info.isLikelyPreview -> "Processed the attachment, but it appears to be a low-resolution version -- only a low-resolution version was provided by the messaging system."
            else -> "Processed the attachment at the quality Android exposed it."
        }

        MonitoringState.recordAttachmentEvent(
            LastAttachmentEvent(
                messagingPackage = packageName,
                notificationTimestampMillis = postTime,
                attachmentExposed = true,
                attachmentUriAvailable = uriWasDirectlyReadable,
                extractionSucceeded = decoded != null,
                attachmentMime = info.mimeType,
                attachmentSizeBytes = info.reportedSizeBytes.takeIf { it >= 0 },
                attachmentDimensions = if (info.widthPx > 0) "${info.widthPx} x ${info.heightPx}" else null,
                stickerClassification = detailed.classification.name,
                qualityClassification = quality.quality.name,
                processingResult = resultText,
                failureReason = if (decoded == null) "Bitmap decode failed" else null,
                attachmentSource = attachmentSource,
            ),
        )

        if (decoded != null) {
            postResultNotification(workingUri, detailed.classification, resultText)
        }
    }

    /** Tests real access rather than assuming it -- this is the crux of the whole investigation
     * (see ARCHITECTURE.md). Returns null on success, or a short reason string on failure. */
    private fun tryRead(uri: Uri): String? {
        return try {
            val opened = contentResolver.openInputStream(uri)?.use { true } ?: false
            if (opened) null else "openInputStream returned null"
        } catch (e: SecurityException) {
            "SecurityException (permission denied)"
        } catch (e: Exception) {
            "${e.javaClass.simpleName}"
        }
    }

    private fun drawableToBitmap(drawable: android.graphics.drawable.Drawable): Bitmap? {
        return try {
            if (drawable is android.graphics.drawable.BitmapDrawable) return drawable.bitmap
            val width = drawable.intrinsicWidth.coerceAtLeast(1)
            val height = drawable.intrinsicHeight.coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = android.graphics.Canvas(bmp)
            drawable.setBounds(0, 0, width, height)
            drawable.draw(canvas)
            bmp
        } catch (_: Exception) {
            null
        }
    }

    /** Caches a notification-embedded Bitmap as a lossless PNG in our own cache dir and returns a FileProvider Uri for it -- necessary only because the existing pipeline (AttachmentInspector etc.) works on Uris, not raw Bitmaps; this is an adapter step, not new attachment-analysis logic. PNG chosen specifically to avoid adding NEW lossy compression on top of whatever the source bitmap already is. */
    private fun cacheBitmapAsUri(bitmap: Bitmap): Uri? {
        return try {
            val dir = File(cacheDir, "monitored_attachments").apply { mkdirs() }
            val file = File(dir, "notification_${System.currentTimeMillis()}.png")
            FileOutputStream(file).use { out -> bitmap.compress(Bitmap.CompressFormat.PNG, 100, out) }
            FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        } catch (_: Exception) {
            null
        }
    }

    private fun postResultNotification(uri: Uri, classification: AttachmentClassification, resultText: String) {
        try {
            val channelId = "pigeonbridge_results"
            ensureResultChannel(channelId)

            val openIntent = android.content.Intent(this, MainActivity::class.java).apply {
                action = MainActivity.ACTION_OPEN_PROCESSED_ATTACHMENT
                data = uri
                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val pendingIntent = PendingIntent.getActivity(
                this, 0, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )

            val title = if (classification == AttachmentClassification.LIKELY_STICKER) {
                "PigeonBridge processed a sticker"
            } else {
                "PigeonBridge processed an image attachment"
            }

            val notification = NotificationCompat.Builder(this, channelId)
                .setContentTitle(title)
                .setContentText(resultText)
                .setStyle(NotificationCompat.BigTextStyle().bigText(resultText))
                .setSmallIcon(android.R.drawable.ic_menu_gallery) // placeholder system icon -- swap for a real PigeonBridge notification icon asset
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .addAction(0, "Open sticker", pendingIntent)
                .build()

            NotificationManagerCompat.from(this).notify(RESULT_NOTIFICATION_ID, notification)
        } catch (_: Exception) {
            // Posting our own result notification failing (e.g. POST_NOTIFICATIONS revoked mid-session)
            // must not crash the listener -- the diagnostic event was already recorded regardless.
        }
    }

    private fun ensureResultChannel(channelId: String) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(android.app.NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(channelId) == null) {
            val channel = android.app.NotificationChannel(
                channelId,
                "PigeonBridge results",
                android.app.NotificationManager.IMPORTANCE_DEFAULT,
            ).apply {
                description = "Notifies you when PigeonBridge processes a sticker or image from a messaging notification."
            }
            manager.createNotificationChannel(channel)
        }
    }

    companion object {
        private const val RESULT_NOTIFICATION_ID = 4201
    }
}
