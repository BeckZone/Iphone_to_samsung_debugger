import { PlayerSlot } from "../models";

// Real 2D projectile-motion simulation: given a launch angle + power, we
// integrate the ball's trajectory under gravity and check whether it passes
// through the rim opening (and, if it clips the front rim, whether it still
// drops in vs. bounces out) — not a scripted make/miss roll.
export const SHOT_DISTANCE = 100; // fixed horizontal distance from foul line to hoop
export const HOOP_HEIGHT = 60;
export const RIM_RADIUS = 6.5;
export const BALL_RADIUS = 3.5;
const GRAVITY = 220; // units/s^2
const MAX_LAUNCH_SPEED = 210;
const DT = 1 / 480;
const ROUNDS = 5; // each player shoots ROUNDS times; most makes wins

export interface BasketballMove {
  angleDeg: number; // launch angle above horizontal, ~25-75 sensible range
  power: number; // 0-100
}

export interface BasketballBoard {
  scores: Record<PlayerSlot, number>;
  shotsTaken: Record<PlayerSlot, number>;
  rounds: number;
  lastShot: { by: PlayerSlot; made: boolean; trajectoryPeak: number } | null;
}

export function createInitialBasketballBoard(): BasketballBoard {
  return {
    scores: { player1: 0, player2: 0 },
    shotsTaken: { player1: 0, player2: 0 },
    rounds: ROUNDS,
    lastShot: null,
  };
}

/** Simulates the shot and returns whether it went in, purely from kinematics. */
function simulateShot(angleDeg: number, power: number): { made: boolean; peak: number } {
  const rad = (angleDeg * Math.PI) / 180;
  const speed = (power / 100) * MAX_LAUNCH_SPEED;
  let x = 0;
  let y = 0;
  let vx = Math.cos(rad) * speed;
  let vy = Math.sin(rad) * speed;
  let peak = 0;
  let t = 0;

  while (t < 6) {
    t += DT;
    vy -= GRAVITY * DT;
    x += vx * DT;
    y += vy * DT;
    if (y > peak) peak = y;

    // Check rim crossing while descending (vy < 0) near the hoop's horizontal position.
    if (vy < 0 && Math.abs(x - SHOT_DISTANCE) <= RIM_RADIUS - BALL_RADIUS * 0.3) {
      if (Math.abs(y - HOOP_HEIGHT) <= 2.5) {
        return { made: true, peak };
      }
    }
    // Ball has passed well beyond the hoop or fallen to the ground without scoring.
    if (x > SHOT_DISTANCE + 25 || y < -5) {
      return { made: false, peak };
    }
  }
  return { made: false, peak };
}

export function applyBasketballMove(board: BasketballBoard, slot: PlayerSlot, move: BasketballMove): BasketballBoard {
  if (move.power < 0 || move.power > 100) throw new Error("Power must be 0-100");
  if (move.angleDeg < 5 || move.angleDeg > 85) throw new Error("Angle must be between 5 and 85 degrees");
  if (board.shotsTaken[slot] >= board.rounds) throw new Error("You've already taken all your shots");

  const { made, peak } = simulateShot(move.angleDeg, move.power);

  return {
    scores: { ...board.scores, [slot]: board.scores[slot] + (made ? 1 : 0) },
    shotsTaken: { ...board.shotsTaken, [slot]: board.shotsTaken[slot] + 1 },
    rounds: board.rounds,
    lastShot: { by: slot, made, trajectoryPeak: peak },
  };
}

export function basketballOutcome(board: BasketballBoard): PlayerSlot | "draw" | null {
  if (board.shotsTaken.player1 < board.rounds || board.shotsTaken.player2 < board.rounds) return null;
  if (board.scores.player1 === board.scores.player2) return "draw";
  return board.scores.player1 > board.scores.player2 ? "player1" : "player2";
}
