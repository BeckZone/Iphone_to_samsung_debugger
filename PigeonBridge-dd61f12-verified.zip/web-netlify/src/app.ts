import { analyzeFile } from "./analyzer.ts";
import { formatReport, type DiagnosticReport } from "./formatter.ts";

const dropzone = document.getElementById("dropzone") as HTMLLabelElement;
const fileInput = document.getElementById("fileInput") as HTMLInputElement;
const resultCard = document.getElementById("resultCard") as HTMLDivElement;

// Registering the service worker is what makes the Web Share Target entry
// (manifest.webmanifest's "share_target") actually work once this site is
// installed as a PWA on Android Chrome. Safe to attempt everywhere --
// browsers without service worker support simply skip it, and the normal
// upload/drop flow below works regardless.
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("/sw.js").catch(() => {
    /* non-fatal -- share-to-app just won't be available; direct upload still works */
  });
}

["dragover", "dragenter"].forEach((evt) =>
  dropzone.addEventListener(evt, (e) => {
    e.preventDefault();
    dropzone.classList.add("dragover");
  }),
);
["dragleave", "drop"].forEach((evt) =>
  dropzone.addEventListener(evt, (e) => {
    e.preventDefault();
    dropzone.classList.remove("dragover");
  }),
);
dropzone.addEventListener("drop", (e) => {
  const file = e.dataTransfer?.files?.[0];
  if (file) handleFile(file);
});
fileInput.addEventListener("change", () => {
  const file = fileInput.files?.[0];
  if (file) handleFile(file);
});

// If we were just redirected here from the share target (sw.js), retrieve
// the shared file from Cache Storage and analyze it immediately.
void checkForSharedFile();

async function checkForSharedFile() {
  const params = new URLSearchParams(location.search);
  if (!params.has("shared")) return;
  history.replaceState(null, "", location.pathname); // clean the URL regardless of outcome below
  try {
    const cache = await caches.open("pigeonbridge-share-v1");
    const response = await cache.match("/shared-file");
    if (!response) return;
    const blob = await response.blob();
    const name = response.headers.get("X-File-Name") || "shared-image";
    await cache.delete("/shared-file");
    const file = new File([blob], name, { type: blob.type });
    await handleFile(file);
  } catch {
    // no shared file available -- just show the normal empty upload state
  }
}

async function handleFile(file: File) {
  resultCard.classList.remove("hidden");
  resultCard.innerHTML = `<p class="muted">Analyzing…</p>`;
  try {
    const { report, previewObjectUrl } = await analyzeFile(file);
    renderReport(report, previewObjectUrl);
  } catch (err) {
    resultCard.innerHTML = `<p class="warn">Couldn't analyze this file: ${escapeHtml((err as Error).message)}</p>`;
  }
}

function renderReport(report: DiagnosticReport, previewObjectUrl: string | null) {
  const badgeClass =
    report.classification === "LIKELY_STICKER" ? "badge-sticker" : report.classification === "NORMAL_IMAGE" ? "badge-normal" : "badge-unknown";
  const badgeText = report.classification === "LIKELY_STICKER" ? "Likely sticker" : report.classification === "NORMAL_IMAGE" ? "Normal image" : "Unknown";

  const qualityText = report.quality === "FULL_LARGE" ? "FULL / LARGE" : report.quality === "SMALL" ? "SMALL" : "UNKNOWN";

  resultCard.innerHTML = `
    ${previewObjectUrl ? `<img class="preview-img" src="${previewObjectUrl}" alt="Preview of ${escapeHtml(report.fileName ?? "uploaded image")}" />` : ""}
    <div style="text-align:center; margin: 14px 0;">
      <span class="badge ${badgeClass}">${badgeText}</span>
    </div>
    ${
      report.previewSuspected
        ? `<p class="warn" style="font-size:13px; text-align:center;">Only a low-resolution version appears to be available — this is the best quality this file provides.</p>`
        : ""
    }

    <div class="section-title">File</div>
    ${row("Name", report.fileName ?? "Unknown")}
    ${row("MIME reported", report.mimeReported ?? "Unknown")}
    ${row("MIME detected", report.mimeDetectedFromBytes ?? "Unknown", report.mimeReported != null && report.mimeDetectedFromBytes != null && report.mimeReported !== report.mimeDetectedFromBytes)}
    ${row("Extension", report.fileExtension ?? "Unknown")}
    ${row("Size", report.sizeBytes >= 0 ? `${report.sizeBytes.toLocaleString("en-US")} bytes` : "Size unavailable")}

    <div class="section-title">Image</div>
    ${row("Dimensions", report.widthPx > 0 ? `${report.widthPx} × ${report.heightPx}` : "Unknown")}
    ${row("Aspect ratio", report.widthPx > 0 && report.heightPx > 0 ? (report.widthPx / report.heightPx).toFixed(2) : "Unknown")}
    ${row("Bit depth / color", report.bitDepthDescription ?? "Unknown")}
    ${row("Alpha (transparency)", boolText(report.hasAlpha))}
    ${row("Animated", boolText(report.isAnimated))}
    ${row("Frame count", report.frameCount != null ? String(report.frameCount) : "Unknown")}
    ${row("Decode", report.decodeSucceeded ? "SUCCESS" : "FAIL")}

    <div class="section-title">Sticker classification</div>
    ${row("Result", report.classification)}
    ${row("Score", `${report.stickerScore} sticker / ${report.photoScore} photo`)}
    <div class="signal-list">
      ${report.classificationSignals.map((s) => `<div>• ${escapeHtml(s.detail)}</div>`).join("")}
    </div>

    <div class="section-title">Quality</div>
    ${row("Classification", qualityText)}
    ${row("Reason", report.qualityReason)}

    <div style="margin-top: 20px;">
      <button class="btn btn-primary" id="copyReportBtn">COPY DIAGNOSTIC REPORT</button>
    </div>
    <div style="margin-top: 10px;">
      <button class="btn btn-secondary" id="clearBtn">CLEAR</button>
    </div>
    <p class="muted" id="copyStatus" style="text-align:center; margin-top:8px; min-height:16px;"></p>
  `;

  document.getElementById("copyReportBtn")?.addEventListener("click", async () => {
    const text = formatReport(report);
    const statusEl = document.getElementById("copyStatus")!;
    try {
      await navigator.clipboard.writeText(text);
      statusEl.textContent = "Copied!";
    } catch {
      // Clipboard API can fail without a secure context/permission -- fall back to a selectable textarea.
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
      statusEl.textContent = "Copied!";
    }
    setTimeout(() => (statusEl.textContent = ""), 2000);
  });

  document.getElementById("clearBtn")?.addEventListener("click", () => {
    resultCard.classList.add("hidden");
    resultCard.innerHTML = "";
    fileInput.value = "";
    if (previewObjectUrl) URL.revokeObjectURL(previewObjectUrl);
  });
}

function row(label: string, value: string, warn = false): string {
  return `<div class="row"><span class="label">${escapeHtml(label)}</span><span class="value ${warn ? "warn" : ""}">${escapeHtml(value)}</span></div>`;
}

function boolText(b: boolean | null): string {
  if (b === true) return "YES";
  if (b === false) return "NO";
  return "Unknown";
}

function escapeHtml(s: string): string {
  const div = document.createElement("div");
  div.textContent = s;
  return div.innerHTML;
}
