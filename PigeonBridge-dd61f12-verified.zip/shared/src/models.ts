import { GameType } from "./constants";

export type GameStatus =
  | "waiting_for_opponent" // created, only player1 present
  | "in_progress"
  | "player1_won"
  | "player2_won"
  | "draw"
  | "abandoned";

export type PlayerSlot = "player1" | "player2";

export interface PlayerInfo {
  slot: PlayerSlot;
  nickname: string;
  connected: boolean;
  platform: "android" | "web" | "unknown";
  lastSeenAt: number; // epoch ms
}

/**
 * Generic envelope stored server-side for every session, regardless of game type.
 * `board` is the game-specific state blob (see checkers.ts / darts.ts for shapes).
 */
export interface GameSession<TBoard = unknown> {
  gameId: string;
  gameType: GameType;
  player1: PlayerInfo | null;
  player2: PlayerInfo | null;
  currentTurn: PlayerSlot;
  board: TBoard;
  status: GameStatus;
  createdAt: number;
  lastActivity: number;
  rematchRequestedBy: PlayerSlot[]; // slots that have asked for a rematch
}

/** Public view of a session sent to clients — never leaks internal server bookkeeping. */
export interface PublicGameSession<TBoard = unknown> {
  gameId: string;
  gameType: GameType;
  player1: Omit<PlayerInfo, "lastSeenAt"> | null;
  player2: Omit<PlayerInfo, "lastSeenAt"> | null;
  currentTurn: PlayerSlot;
  board: TBoard;
  status: GameStatus;
  yourSlot: PlayerSlot;
}

export function toPublicSession<TBoard>(
  s: GameSession<TBoard>,
  yourSlot: PlayerSlot
): PublicGameSession<TBoard> {
  const strip = (p: PlayerInfo | null) =>
    p ? { slot: p.slot, nickname: p.nickname, connected: p.connected, platform: p.platform } : null;
  return {
    gameId: s.gameId,
    gameType: s.gameType,
    player1: strip(s.player1),
    player2: strip(s.player2),
    currentTurn: s.currentTurn,
    board: s.board,
    status: s.status,
    yourSlot,
  };
}
