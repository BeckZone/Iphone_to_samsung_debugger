import { Router } from "express";
import {
  buildShareText,
  CreateGameRequest,
  CreateGameResponse,
  GAME_DISPLAY_NAMES,
  GAME_TYPES,
  MAX_NICKNAME_LENGTH,
  MIN_NICKNAME_LENGTH,
} from "@pigeonbridge/shared";
import { sessionStore } from "../game/sessionStore";

const PUBLIC_BASE_URL = process.env.PUBLIC_BASE_URL || "https://pigeonbridge.app";

export const gamesRouter = Router();

function isValidNickname(n: unknown): n is string {
  return typeof n === "string" && n.trim().length >= MIN_NICKNAME_LENGTH && n.trim().length <= MAX_NICKNAME_LENGTH;
}

/** Builds the V2 invite link: https://pigeonbridge.app/g/ABC123 (an Android App Link path). */
export function buildJoinUrl(gameId: string): string {
  return `${PUBLIC_BASE_URL}/g/${gameId}`;
}

gamesRouter.post("/games", (req, res) => {
  const body = req.body as Partial<CreateGameRequest>;
  if (!body.gameType || !(GAME_TYPES as readonly string[]).includes(body.gameType)) {
    return res.status(400).json({ code: "invalid_game_type", message: "Unknown gameType" });
  }
  if (!isValidNickname(body.nickname)) {
    return res.status(400).json({ code: "invalid_nickname", message: "Nickname is required (1-20 chars)" });
  }

  const platform = req.get("X-Client-Platform") === "android" ? "android" : "web";
  const session = sessionStore.create(body.gameType, body.nickname!.trim(), platform);

  const joinUrl = buildJoinUrl(session.gameId);
  const displayName = GAME_DISPLAY_NAMES[session.gameType];
  const shareText = body.inviteMessage?.trim() || buildShareText(joinUrl, session.gameType, displayName);

  const response: CreateGameResponse = { gameId: session.gameId, joinUrl, shareText };
  res.status(201).json(response);
});

gamesRouter.get("/games/:gameId", (req, res) => {
  const session = sessionStore.get(req.params.gameId);
  if (!session) return res.status(404).json({ code: "not_found", message: "Game not found or expired" });

  // Unauthenticated peek used by the invite page (and OG rendering) before the
  // joiner has picked a nickname / opened a websocket. No board state leaks here.
  res.json({
    gameId: session.gameId,
    gameType: session.gameType,
    displayName: GAME_DISPLAY_NAMES[session.gameType],
    status: session.status,
    hostNickname: session.player1?.nickname ?? null,
    hasSecondPlayer: !!session.player2,
  });
});

gamesRouter.get("/health", (_req, res) => {
  res.json({ ok: true, activeSessions: sessionStore.size() });
});
