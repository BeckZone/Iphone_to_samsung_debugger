import { test } from "node:test";
import assert from "node:assert/strict";
import { checkers } from "@pigeonbridge/shared";

test("initial board has 12 pieces per side", () => {
  const board = checkers.createInitialCheckersBoard();
  let red = 0,
    black = 0;
  for (const row of board) for (const cell of row) if (cell === 1) red++; else if (cell === 3) black++;
  assert.equal(red, 12);
  assert.equal(black, 12);
});

test("player1 (red) has legal forward moves from the start", () => {
  const board = checkers.createInitialCheckersBoard();
  const moves = checkers.legalMovesFor(board, "player1");
  assert.ok(moves.length > 0);
  for (const m of moves) assert.ok(m.toRow < m.fromRow, "red should move up (decreasing row)");
});

test("illegal move throws", () => {
  const board = checkers.createInitialCheckersBoard();
  // (5,0) -> (3,0) is not a valid diagonal step (not adjacent), so this must be rejected.
  assert.throws(() => checkers.applyCheckersMove(board, "player1", { fromRow: 5, fromCol: 0, toRow: 3, toCol: 0 }));
  // Moving a piece that isn't there is also illegal.
  assert.throws(() => checkers.applyCheckersMove(board, "player1", { fromRow: 4, fromCol: 1, toRow: 3, toCol: 0 }));
});

test("simple legal move updates board", () => {
  const board = checkers.createInitialCheckersBoard();
  const moves = checkers.legalMovesFor(board, "player1");
  const move = moves[0];
  const result = checkers.applyCheckersMove(board, "player1", move);
  assert.equal(result.board[move.fromRow][move.fromCol], 0);
  assert.equal(result.board[move.toRow][move.toCol], 1);
  assert.equal(result.didCapture, false);
});

test("forced capture: a jump must be taken when available", () => {
  const board = checkers.createInitialCheckersBoard().map((r) => r.slice());
  // Clear a lane and set up: black man at (2,1), red man at (5,2) moved to (3,2) manually,
  // then red at (4,3) simulated as empty so red at (3,2) can jump black at (2,1) -> not empty though.
  // Simpler: build a custom minimal board.
  const custom: checkers.CheckersBoard = Array.from({ length: 8 }, () => Array(8).fill(0)) as any;
  custom[3][2] = 1; // red man
  custom[2][1] = 3; // black man adjacent, jumpable
  // (2,1) opponent between (3,2) and (1,0) which is empty -> capture available
  custom[5][6] = 1; // another red man with only a simple move available
  const moves = checkers.legalMovesFor(custom, "player1");
  assert.ok(moves.length > 0);
  // All returned moves must be jumps (captures), since a capture exists
  for (const m of moves) assert.equal(Math.abs(m.toRow - m.fromRow), 2);
});

test("king promotion on reaching back row", () => {
  const custom: checkers.CheckersBoard = Array.from({ length: 8 }, () => Array(8).fill(0)) as any;
  custom[1][2] = 1; // red man one step from row 0
  const result = checkers.applyCheckersMove(custom, "player1", { fromRow: 1, fromCol: 2, toRow: 0, toCol: 1 });
  assert.equal(result.board[0][1], 2); // promoted to red king
});

test("winner declared when opponent has no pieces left", () => {
  const custom: checkers.CheckersBoard = Array.from({ length: 8 }, () => Array(8).fill(0)) as any;
  custom[3][2] = 1; // only red piece left, no black
  const winner = checkers.checkersWinner(custom, "player2");
  assert.equal(winner, "player1");
});
