import { GameType } from "./constants";
import { PublicGameSession } from "./models";

// ---- Client -> Server ----

export interface JoinMessage {
  type: "join";
  gameId: string;
  nickname: string;
  platform: "android" | "web";
}

export interface MakeMoveMessage {
  type: "make_move";
  gameId: string;
  move: unknown; // narrowed per-game on the server (CheckersMove | DartsMove | ...)
}

export interface RequestRematchMessage {
  type: "request_rematch";
  gameId: string;
}

export interface LeaveMessage {
  type: "leave";
  gameId: string;
}

export interface PingMessage {
  type: "ping";
}

export type ClientMessage =
  | JoinMessage
  | MakeMoveMessage
  | RequestRematchMessage
  | LeaveMessage
  | PingMessage;

// ---- Server -> Client ----

export interface JoinedMessage {
  type: "joined";
  session: PublicGameSession;
}

export interface StateUpdateMessage {
  type: "state_update";
  session: PublicGameSession;
}

export interface OpponentJoinedMessage {
  type: "opponent_joined";
  session: PublicGameSession;
}

export interface OpponentLeftMessage {
  type: "opponent_left";
}

export interface OpponentDisconnectedMessage {
  type: "opponent_disconnected";
  graceMs: number;
}

export interface OpponentReconnectedMessage {
  type: "opponent_reconnected";
}

export interface RematchOfferedMessage {
  type: "rematch_offered";
  bySlot: "player1" | "player2";
}

export interface RematchStartedMessage {
  type: "rematch_started";
  session: PublicGameSession;
}

export interface GameOverMessage {
  type: "game_over";
  session: PublicGameSession;
}

export interface ErrorMessage {
  type: "error";
  code: string;
  message: string;
}

export interface PongMessage {
  type: "pong";
}

export type ServerMessage =
  | JoinedMessage
  | StateUpdateMessage
  | OpponentJoinedMessage
  | OpponentLeftMessage
  | OpponentDisconnectedMessage
  | OpponentReconnectedMessage
  | RematchOfferedMessage
  | RematchStartedMessage
  | GameOverMessage
  | ErrorMessage
  | PongMessage;

export interface CreateGameRequest {
  gameType: GameType;
  nickname: string;
  /** Optional custom invite message override (V2 share sheet lets the host edit it). */
  inviteMessage?: string;
}

export interface CreateGameResponse {
  gameId: string;
  joinUrl: string;
  /** Ready-to-share text, e.g. "🎮 Let's play Basketball!\n\nTap here to play:\nhttps://pigeonbridge.app/g/8XK29F" */
  shareText: string;
}

export const GAME_EMOJI: Record<GameType, string> = {
  checkers: "⚫",
  darts: "🎯",
  chess: "♟️",
  cup_pong: "🍺",
  basketball: "🏀",
  eight_ball_pool: "🎱",
};

export function buildShareText(joinUrl: string, gameType: GameType, displayName: string): string {
  return `🎮 Let's play ${displayName}!\n\nTap here to play:\n${joinUrl}`;
}
