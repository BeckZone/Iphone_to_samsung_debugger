package app.pigeonbridge.android.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import app.pigeonbridge.android.background.BackgroundProcessingState
import app.pigeonbridge.android.background.BackgroundSettings
import app.pigeonbridge.android.background.FailureExplainer
import app.pigeonbridge.android.background.ProcessingStatusFormatter
import app.pigeonbridge.android.messages.MessageFeed
import app.pigeonbridge.android.monitoring.MonitoringState
import app.pigeonbridge.android.ui.PigeonCard
import app.pigeonbridge.android.ui.PrimaryButton
import app.pigeonbridge.android.ui.SecondaryButton
import app.pigeonbridge.android.ui.theme.PBAccent
import java.text.DateFormat
import java.util.Date

private val Muted = Color(0xFFA8A3C7)

/**
 * "Background Message Processing": the switches, the permission status, and a plain statement
 * of what Android does and does not allow. Everything shown is queried live; nothing is assumed.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackgroundProcessingScreen(
    onBack: () -> Unit,
    onOpenMessages: () -> Unit,
    onOpenMonitoring: () -> Unit,
) {
    val context = LocalContext.current
    var tick by remember { mutableStateOf(0) }

    var background by remember { mutableStateOf(BackgroundSettings.backgroundProcessing) }
    var stickers by remember { mutableStateOf(BackgroundSettings.processStickers) }
    var artwork by remember { mutableStateOf(BackgroundSettings.alternateEmojiArtwork) }
    var processedNotifications by remember { mutableStateOf(BackgroundSettings.processedNotifications) }

    // Permissions can change while we are in the system Settings screens; re-read on resume.
    DisposableEffect(context) {
        val lifecycle = (context as? ComponentActivity)?.lifecycle
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_RESUME) tick++ }
        lifecycle?.addObserver(observer)
        onDispose { lifecycle?.removeObserver(observer) }
    }

    val postPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    val accessGranted = remember(tick) { MonitoringState.notificationAccessGranted(context) }
    val postNeeded = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
    val postGranted = remember(tick) {
        !postNeeded || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    }
    val notificationsEnabled = remember(tick) { NotificationManagerCompat.from(context).areNotificationsEnabled() }
    val status = remember(tick) { BackgroundProcessingState.status(context) }

    Scaffold(topBar = { TopAppBar(title = { Text("Background Message Processing") }) }) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp),
        ) {
            PigeonCard {
                Column {
                    Text("STATUS", fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp))
                    Text(ProcessingStatusFormatter.headline(status), fontSize = 13.sp)
                    Text(
                        "Last message event: ${status.lastMessageEventMillis?.let { formatTime(it) } ?: "None yet"}",
                        fontSize = 12.sp, color = Muted, modifier = Modifier.padding(top = 8.dp),
                    )
                    Text(
                        "Last processed: ${status.lastProcessedMillis?.let { formatTime(it) } ?: "None yet"}",
                        fontSize = 12.sp, color = Muted,
                    )
                }
            }

            Section("Switches")
            ToggleRow("Background processing", "Master switch. Off = PigeonBridge ignores every notification.", background) {
                background = it
                BackgroundSettings.backgroundProcessing = it
                tick++
            }
            ToggleRow("Process incoming stickers", "Look for a picture in the messaging notification and run the sticker pipeline on it.", stickers) {
                stickers = it
                BackgroundSettings.processStickers = it
            }
            ToggleRow(
                "Emoji artwork (Twemoji)",
                "Draw emoji inside PigeonBridge with the bundled open-source Twemoji set instead of your phone's emoji font. The underlying Unicode is never changed. This is Twemoji, not Apple's emoji.",
                artwork,
            ) {
                artwork = it
                BackgroundSettings.alternateEmojiArtwork = it
            }
            ToggleRow(
                "Processed notification preview",
                "Post a separate, silent PigeonBridge notification for emoji-only messages. Your Messages notification is not touched. Off by default.",
                processedNotifications,
            ) {
                processedNotifications = it
                BackgroundSettings.processedNotifications = it
                if (it && postNeeded && !postGranted) postPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            Text(
                "There is no PhotoMoji switch: PigeonBridge has no PhotoMoji feature to switch.",
                fontSize = 11.sp, color = Muted, modifier = Modifier.padding(top = 6.dp),
            )

            Section("What you need to enable")
            PigeonCard {
                Column {
                    PermRow("Notification access (required)", accessGranted)
                    PermRow("Notification permission (only for the optional preview)", postGranted && notificationsEnabled)
                }
            }
            Column(modifier = Modifier.padding(top = 10.dp)) {
                SecondaryButton("Open Notification Access Settings") {
                    context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                }
            }
            if (postNeeded && !postGranted) {
                Column(modifier = Modifier.padding(top = 8.dp)) {
                    SecondaryButton("Allow PigeonBridge notifications") {
                        postPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
            } else if (!notificationsEnabled) {
                Column(modifier = Modifier.padding(top = 8.dp)) {
                    SecondaryButton("Open app notification settings") {
                        context.startActivity(
                            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName),
                        )
                    }
                }
            }

            Section("Diagnostics")
            PigeonCard {
                val event = remember(tick) { MonitoringState.lastAttachmentEvent() }
                Column {
                    PermRow("Listener connected", status.listenerObserved)
                    DiagRow("Supported messaging app detected", event?.messagingPackage ?: status.lastMessageEventMillis?.let { "Yes (see last event)" } ?: "None yet")
                    DiagRow("Last message event", status.lastMessageEventMillis?.let { formatTime(it) } ?: "None yet")
                    DiagRow("Last processing attempt", event?.notificationTimestampMillis?.let { formatTime(it) } ?: "None yet")
                    DiagRow("Last successful processing", status.lastProcessedMillis?.let { formatTime(it) } ?: "None yet")
                    DiagRow("Extraction method", event?.attachmentSource ?: "none")
                    DiagRow("URI type", event?.attachmentSource?.let { uriTypeOf(it) } ?: "N/A")
                    DiagRow("Attachment dimensions", event?.attachmentDimensions ?: "Unknown")
                    DiagRow("Emoji detected (last message)", status.lastEmojiCount?.toString() ?: "N/A")
                    DiagRow("Rendering method", status.lastRenderingMethod ?: "N/A")
                    DiagRow("Surfaced into Messages UI", ProcessingStatusFormatter.SURFACED_INTO_MESSAGES_UI)
                    FailureExplainer.explain(event?.failureReason)?.let { DiagRow("Last problem", it) }
                }
            }

            Section("What Android does and does not allow")
            PigeonCard {
                Column {
                    Para("Works automatically, even when PigeonBridge is closed: once notification access is on, Android tells PigeonBridge about each new Samsung/Google Messages notification. PigeonBridge reads the text and any picture the notification carries, records what happened, and (if you turned it on) posts its own silent notification.")
                    Para("Does not work: changing how Samsung Messages or Google Messages look. Another app cannot restyle their screens, swap their emoji font, or edit their messages. Doing that would need root, accessibility tricks or patching those apps, and PigeonBridge uses none of them.")
                    Para("Does not work: removing or replacing Messages' own notification. PigeonBridge never hides it.")
                    Para("Does not work: copying emoji elsewhere. Copied emoji are plain Unicode, so other apps draw them with their own font.")
                    Para("Stickers: Android only passes along what the messaging app puts in the notification. Often that is just a small preview, or nothing. Diagnostics shows exactly what was exposed.")
                    Para("Becoming the default SMS app would let PigeonBridge receive SMS/MMS directly, but it would have to be a complete texting app, and it still would not cover RCS chats or let it change Samsung Messages.")
                }
            }

            Column(modifier = Modifier.padding(top = 16.dp)) {
                SecondaryButton("Open chat view") { onOpenMessages() }
                Column(modifier = Modifier.padding(top = 8.dp)) { SecondaryButton("Open Background Monitoring") { onOpenMonitoring() } }
                Column(modifier = Modifier.padding(top = 8.dp)) {
                    SecondaryButton("Clear processed-message history") {
                        MessageFeed.shared.clear()
                        BackgroundProcessingState.clear()
                        tick++
                    }
                }
                Column(modifier = Modifier.padding(top = 8.dp)) { PrimaryButton("Back") { onBack() } }
            }
        }
    }
}

@Composable
private fun Section(title: String) {
    Text(title.uppercase(), fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(top = 20.dp, bottom = 8.dp))
}

@Composable
private fun Para(text: String) {
    Text(text, fontSize = 12.sp, color = Muted, modifier = Modifier.padding(vertical = 4.dp))
}

@Composable
private fun ToggleRow(title: String, detail: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, fontSize = 15.sp)
            Text(detail, fontSize = 11.sp, color = Muted)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun DiagRow(label: String, value: String) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label, fontSize = 11.sp, color = Muted)
        Text(value, fontSize = 13.sp)
    }
}

private fun uriTypeOf(source: String): String = when {
    source.startsWith("MessagingStyle.Message.dataUri") -> "content URI from the message (read directly)"
    source.startsWith("EXTRA_PICTURE_ICON (Uri") -> "content URI from the notification picture"
    source.startsWith("notification-embedded") -> "none (embedded bitmap copied to PigeonBridge's private cache)"
    else -> "none exposed"
}

@Composable
private fun PermRow(label: String, ok: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, fontSize = 13.sp, modifier = Modifier.weight(1f).padding(end = 8.dp))
        Text(if (ok) "On" else "Off", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = if (ok) PBAccent else Muted)
    }
}

private fun formatTime(millis: Long): String =
    DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM).format(Date(millis))
