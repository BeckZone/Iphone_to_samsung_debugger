package app.pigeonbridge.android.attachment

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri

/**
 * Decodes an attachment Uri to a display-ready Bitmap while preserving
 * quality: full resolution by default (no forced downscale), ARGB_8888 so
 * transparency survives, and EXIF rotation applied so the image displays
 * upright. The only time this samples down at all is the safety cap below —
 * to avoid an OOM crash on a genuinely huge image (spec test case #9) — and
 * even then it picks the largest power-of-two sample that still fits under
 * the cap, not an arbitrary thumbnail size.
 *
 * This does not re-encode or recompress anything: the result is a decoded
 * in-memory Bitmap for on-screen display, never written back out as a new
 * (lossy) file.
 */
object AttachmentBitmapDecoder {

    /**
     * Generous safety cap — comfortably larger than any real sticker or
     * typical shared photo, so this essentially never triggers except for
     * the "very large image" test case. Prevents an OutOfMemoryError on a
     * pathological multi-thousand-pixel image rather than silently
     * degrading normal attachments.
     */
    private const val MAX_SAFE_DIMENSION = 4096

    data class DecodedAttachment(
        val bitmap: Bitmap,
        val wasDownsampled: Boolean,
        val sampleSize: Int,
    )

    fun decode(context: Context, uri: Uri, info: AttachmentInfo): DecodedAttachment? {
        val resolver = context.contentResolver
        val sampleSize = if (info.widthPx > 0 && info.heightPx > 0) {
            computeSafeSampleSize(info.widthPx, info.heightPx)
        } else {
            1 // bounds unknown (shouldn't normally happen if inspect() ran first) — attempt an unsampled decode
        }

        val bitmap = try {
            resolver.openInputStream(uri)?.use { stream ->
                val opts = BitmapFactory.Options().apply {
                    inSampleSize = sampleSize
                    inPreferredConfig = Bitmap.Config.ARGB_8888 // preserves alpha; never downgrade to RGB_565 (loses transparency) or re-encode as JPEG
                }
                BitmapFactory.decodeStream(stream, null, opts)
            }
        } catch (t: Throwable) {
            AttachmentDebugLog.logError("decodeFullQuality", uri, t)
            null
        }

        if (bitmap == null) {
            AttachmentDebugLog.logDecode(uri, success = false, outWidth = -1, outHeight = -1, sampleSize = sampleSize)
            return null
        }

        val rotated = applyExifRotation(bitmap, info.exifRotationDegrees)
        AttachmentDebugLog.logDecode(uri, success = true, outWidth = rotated.width, outHeight = rotated.height, sampleSize = sampleSize)
        return DecodedAttachment(bitmap = rotated, wasDownsampled = sampleSize > 1, sampleSize = sampleSize)
    }

    private fun computeSafeSampleSize(width: Int, height: Int): Int {
        var sample = 1
        var w = width
        var h = height
        while (w / 2 >= MAX_SAFE_DIMENSION || h / 2 >= MAX_SAFE_DIMENSION) {
            w /= 2
            h /= 2
            sample *= 2
        }
        return sample
    }

    private fun applyExifRotation(bitmap: Bitmap, degrees: Int): Bitmap {
        if (degrees == 0) return bitmap
        val matrix = Matrix().apply { postRotate(degrees.toFloat()) }
        val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        if (rotated !== bitmap) bitmap.recycle()
        return rotated
    }
}
