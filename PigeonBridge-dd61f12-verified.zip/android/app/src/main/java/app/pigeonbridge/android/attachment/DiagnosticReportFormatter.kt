package app.pigeonbridge.android.attachment

/**
 * Formats a [DiagnosticReport] into the plain-text report copied by
 * DiagnosticScreen's "Copy Report" button. Pure string formatting — no
 * Android types in or out — so this is unit-tested directly
 * (DiagnosticReportFormatterTest.kt).
 *
 * Deliberately excludes message text or anything beyond the one shared
 * attachment's technical metadata (spec Part 12: "Do NOT include private
 * message text or unrelated personal information").
 */
object DiagnosticReportFormatter {

    fun format(report: DiagnosticReport): String {
        val sb = StringBuilder()
        sb.appendLine("PigeonBridge Attachment Diagnostic")
        sb.appendLine()

        sb.appendLine("URI scheme: ${report.uriScheme ?: "Unknown"}")
        sb.appendLine("URI authority: ${report.uriAuthority ?: "Unknown"}")
        sb.appendLine("URI path: ${report.uriPath ?: "Unknown"}")
        sb.appendLine()

        sb.appendLine("MIME reported: ${report.mimeReported ?: "Unknown"}")
        sb.appendLine("MIME detected (from bytes): ${report.mimeDetectedFromBytes ?: "Unknown"}")
        if (report.mimeReported != null && report.mimeDetectedFromBytes != null && report.mimeReported != report.mimeDetectedFromBytes) {
            sb.appendLine("  (!) Reported and detected MIME disagree")
        }
        sb.appendLine("File extension: ${report.fileExtension ?: "Unknown"}")
        sb.appendLine()

        sb.appendLine("Display name: ${report.displayName ?: "Unknown"}")
        if (report.reportedSizeBytes >= 0) {
            sb.appendLine("File size: ${"%,d".format(java.util.Locale.US, report.reportedSizeBytes)} bytes (${formatKbMb(report.reportedSizeBytes)})")
        } else {
            sb.appendLine("File size: Size unavailable")
        }
        sb.appendLine("Last modified: ${report.lastModifiedMillis?.let { formatTimestamp(it) } ?: "Unknown"}")
        sb.appendLine()

        if (report.widthPx > 0 && report.heightPx > 0) {
            sb.appendLine("Dimensions: ${report.widthPx} × ${report.heightPx}")
            sb.appendLine("Aspect ratio: ${"%.2f".format(java.util.Locale.US, report.widthPx.toDouble() / report.heightPx.toDouble())}")
        } else {
            sb.appendLine("Dimensions: Unknown")
            sb.appendLine("Aspect ratio: Unknown")
        }
        sb.appendLine("Bit depth / color format: ${report.bitDepthDescription ?: "Unknown"}")
        sb.appendLine("Alpha: ${boolText(report.hasAlpha)}")
        sb.appendLine("Animated: ${boolText(report.isAnimated)}")
        sb.appendLine("Frame count: ${report.frameCount?.toString() ?: "Unknown"}")
        sb.appendLine("EXIF orientation: ${report.exifOrientationRaw?.toString() ?: "Unknown"}")
        sb.appendLine()

        sb.appendLine("URI readable: ${if (report.uriReadable) "YES" else "NO"}")
        sb.appendLine("Stream readable: ${if (report.streamReadable) "YES" else "NO"}")
        sb.appendLine("Bitmap decode: ${if (report.bitmapDecodeSucceeded) "SUCCESS" else "FAIL"}")
        if (report.bitmapDecodeSucceeded && report.decodedWidthPx != null && report.decodedHeightPx != null) {
            sb.appendLine("Decoded dimensions: ${report.decodedWidthPx} × ${report.decodedHeightPx}")
        }
        sb.appendLine()

        sb.appendLine("Preview suspected: ${if (report.previewSuspected) "YES" else "NO"}")
        if (report.previewReasons.isNotEmpty()) {
            if (report.previewReasons.size == 1) {
                sb.appendLine("Preview reason: ${report.previewReasons.first()}")
            } else {
                sb.appendLine("Preview reasons:")
                report.previewReasons.forEach { sb.appendLine("  - $it") }
            }
        }
        sb.appendLine()

        sb.appendLine("Sticker classification: ${report.classification}")
        sb.appendLine("Sticker score: ${report.stickerScore} (photo score: ${report.photoScore})")
        sb.appendLine("Scoring signals:")
        report.classificationSignals.forEach { sb.appendLine("  - ${it.name}: ${it.detail}") }
        sb.appendLine()

        sb.appendLine("Read permission: ${boolText(report.readPermissionGranted)}")
        sb.appendLine("Persistable permission: ${if (report.persistablePermissionGranted) "YES" else "NO"}")
        sb.appendLine("Granted via: ${report.grantedVia}")
        sb.appendLine()

        sb.appendLine("Alternate representation: ${report.alternateRepresentationSummary}")
        sb.appendLine()

        sb.appendLine("Attachment quality: ${qualityText(report.quality)}")
        sb.appendLine("Quality reason: ${report.qualityReason}")

        return sb.toString()
    }

    private fun boolText(b: Boolean?): String = when (b) {
        true -> "YES"
        false -> "NO"
        null -> "Unknown"
    }

    private fun qualityText(q: QualityClass): String = when (q) {
        QualityClass.FULL_LARGE -> "FULL / LARGE"
        QualityClass.SMALL -> "SMALL"
        QualityClass.UNKNOWN -> "UNKNOWN"
    }

    private fun formatKbMb(bytes: Long): String {
        val kb = bytes / 1024.0
        return if (kb >= 1024) "%.2f MB".format(java.util.Locale.US, kb / 1024.0) else "%.1f KB".format(java.util.Locale.US, kb)
    }

    private fun formatTimestamp(millis: Long): String {
        return try {
            java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date(millis))
        } catch (t: Throwable) {
            millis.toString()
        }
    }
}
