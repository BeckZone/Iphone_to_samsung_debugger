import { WebSocket, WebSocketServer } from "ws";
import { IncomingMessage } from "http";
import {
  ClientMessage,
  ServerMessage,
  MAX_NICKNAME_LENGTH,
  MIN_NICKNAME_LENGTH,
  PlayerSlot,
  RECONNECT_GRACE_MS,
  WS_RATE_LIMIT_MESSAGES_PER_10S,
  toPublicSession,
} from "@pigeonbridge/shared";
import { sessionStore } from "../game/sessionStore";
import { applyMove, createInitialBoard, isGameImplemented } from "../game/engine";

interface SocketMeta {
  gameId: string | null;
  slot: PlayerSlot | null;
  msgTimestamps: number[]; // sliding window for rate limiting
  disconnectTimer: NodeJS.Timeout | null;
}

const meta = new WeakMap<WebSocket, SocketMeta>();
// gameId -> slot -> live socket, so we can push updates to both players
const liveSockets = new Map<string, Partial<Record<PlayerSlot, WebSocket>>>();

function send(ws: WebSocket, msg: ServerMessage) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(msg));
}

function sendError(ws: WebSocket, code: string, message: string) {
  send(ws, { type: "error", code, message });
}

function broadcastToGame(gameId: string, build: (slot: PlayerSlot) => ServerMessage) {
  const sockets = liveSockets.get(gameId);
  if (!sockets) return;
  (["player1", "player2"] as PlayerSlot[]).forEach((slot) => {
    const sock = sockets[slot];
    if (sock) send(sock, build(slot));
  });
}

function withinRateLimit(sm: SocketMeta): boolean {
  const now = Date.now();
  sm.msgTimestamps = sm.msgTimestamps.filter((t) => now - t < 10_000);
  if (sm.msgTimestamps.length >= WS_RATE_LIMIT_MESSAGES_PER_10S) return false;
  sm.msgTimestamps.push(now);
  return true;
}

export function attachWebSocketServer(wss: WebSocketServer) {
  wss.on("connection", (ws: WebSocket, _req: IncomingMessage) => {
    meta.set(ws, { gameId: null, slot: null, msgTimestamps: [], disconnectTimer: null });

    ws.on("message", (raw) => {
      const sm = meta.get(ws)!;
      if (!withinRateLimit(sm)) {
        sendError(ws, "rate_limited", "Too many messages, slow down");
        return;
      }

      let msg: ClientMessage;
      try {
        msg = JSON.parse(raw.toString());
      } catch {
        sendError(ws, "bad_json", "Message must be valid JSON");
        return;
      }

      try {
        handleMessage(ws, sm, msg);
      } catch (err: any) {
        sendError(ws, "server_error", err?.message ?? "Unexpected error");
      }
    });

    ws.on("close", () => handleDisconnect(ws));
  });
}

function handleMessage(ws: WebSocket, sm: SocketMeta, msg: ClientMessage) {
  switch (msg.type) {
    case "ping":
      send(ws, { type: "pong" });
      return;
    case "join":
      return handleJoin(ws, sm, msg);
    case "make_move":
      return handleMove(ws, sm, msg);
    case "request_rematch":
      return handleRematch(ws, sm, msg);
    case "leave":
      return handleLeave(ws, sm);
    default:
      sendError(ws, "unknown_message", "Unrecognized message type");
  }
}

function handleJoin(ws: WebSocket, sm: SocketMeta, msg: Extract<ClientMessage, { type: "join" }>) {
  const nickname = (msg.nickname ?? "").trim();
  if (nickname.length < MIN_NICKNAME_LENGTH || nickname.length > MAX_NICKNAME_LENGTH) {
    return sendError(ws, "invalid_nickname", "Nickname is required (1-20 chars)");
  }
  const session = sessionStore.get(msg.gameId);
  if (!session) return sendError(ws, "not_found", "Game not found or expired");

  const now = Date.now();
  let slot: PlayerSlot;

  // Reconnect case: same-looking player rejoining a game already in progress.
  if (session.player1 && session.player1.nickname === nickname && !session.player1.connected) {
    slot = "player1";
  } else if (session.player2 && session.player2.nickname === nickname && !session.player2.connected) {
    slot = "player2";
  } else if (!session.player1) {
    slot = "player1";
    session.player1 = { slot, nickname, connected: false, platform: msg.platform, lastSeenAt: now };
  } else if (!session.player2) {
    slot = "player2";
    session.player2 = { slot, nickname, connected: false, platform: msg.platform, lastSeenAt: now };
  } else {
    return sendError(ws, "game_full", "This game already has two players");
  }

  const player = session[slot]!;
  const wasReconnect = player.connected === false && session.status === "in_progress";
  player.connected = true;
  player.lastSeenAt = now;
  session.lastActivity = now;
  if (session.player1 && session.player2 && session.status === "waiting_for_opponent") {
    session.status = "in_progress";
  }
  sessionStore.set(session.gameId, session);

  sm.gameId = session.gameId;
  sm.slot = slot;
  if (!liveSockets.has(session.gameId)) liveSockets.set(session.gameId, {});
  liveSockets.get(session.gameId)![slot] = ws;

  const otherSlot: PlayerSlot = slot === "player1" ? "player2" : "player1";
  const otherSocket = liveSockets.get(session.gameId)?.[otherSlot];
  if (otherSocket && meta.get(otherSocket)?.disconnectTimer) {
    clearTimeout(meta.get(otherSocket)!.disconnectTimer!);
    meta.get(otherSocket)!.disconnectTimer = null;
  }

  send(ws, { type: "joined", session: toPublicSession(session, slot) });

  if (wasReconnect) {
    broadcastToGame(session.gameId, () => ({ type: "opponent_reconnected" }));
  } else if (session.player1 && session.player2) {
    // notify the *other* player specifically that someone joined
    if (otherSocket) send(otherSocket, { type: "opponent_joined", session: toPublicSession(session, otherSlot) });
  }
}

function requireJoined(sm: SocketMeta, ws: WebSocket): { gameId: string; slot: PlayerSlot } | null {
  if (!sm.gameId || !sm.slot) {
    sendError(ws, "not_joined", "Join a game before sending this message");
    return null;
  }
  return { gameId: sm.gameId, slot: sm.slot };
}

function handleMove(ws: WebSocket, sm: SocketMeta, msg: Extract<ClientMessage, { type: "make_move" }>) {
  const ctx = requireJoined(sm, ws);
  if (!ctx) return;
  const session = sessionStore.get(ctx.gameId);
  if (!session) return sendError(ws, "not_found", "Game not found or expired");
  if (session.status !== "in_progress") return sendError(ws, "game_not_active", "Game isn't in progress");
  if (!isGameImplemented(session.gameType)) {
    return sendError(ws, "not_implemented", `${session.gameType} isn't playable yet`);
  }
  if (session.currentTurn !== ctx.slot) return sendError(ws, "not_your_turn", "Wait for your turn");

  let result;
  try {
    result = applyMove(session.gameType, session.board, ctx.slot, msg.move);
  } catch (err: any) {
    return sendError(ws, "illegal_move", err?.message ?? "Illegal move");
  }

  session.board = result.board;
  session.currentTurn = result.nextTurn;
  session.lastActivity = Date.now();
  if (result.winner === "draw") session.status = "draw";
  else if (result.winner === "player1") session.status = "player1_won";
  else if (result.winner === "player2") session.status = "player2_won";
  sessionStore.set(session.gameId, session);

  if (session.status === "in_progress") {
    broadcastToGame(session.gameId, (slot) => ({ type: "state_update", session: toPublicSession(session, slot) }));
  } else {
    broadcastToGame(session.gameId, (slot) => ({ type: "game_over", session: toPublicSession(session, slot) }));
  }
}

function handleRematch(ws: WebSocket, sm: SocketMeta, msg: Extract<ClientMessage, { type: "request_rematch" }>) {
  const ctx = requireJoined(sm, ws);
  if (!ctx) return;
  const session = sessionStore.get(ctx.gameId);
  if (!session) return sendError(ws, "not_found", "Game not found or expired");

  if (!session.rematchRequestedBy.includes(ctx.slot)) {
    session.rematchRequestedBy.push(ctx.slot);
  }

  if (session.rematchRequestedBy.length === 2) {
    session.board = createInitialBoard(session.gameType);
    session.status = "in_progress";
    session.currentTurn = "player1";
    session.rematchRequestedBy = [];
    session.lastActivity = Date.now();
    sessionStore.set(session.gameId, session);
    broadcastToGame(session.gameId, (slot) => ({ type: "rematch_started", session: toPublicSession(session, slot) }));
  } else {
    sessionStore.set(session.gameId, session);
    broadcastToGame(session.gameId, () => ({ type: "rematch_offered", bySlot: ctx.slot }));
  }
}

function handleLeave(ws: WebSocket, sm: SocketMeta) {
  if (!sm.gameId || !sm.slot) return;
  const session = sessionStore.get(sm.gameId);
  const gameId = sm.gameId;
  const slot = sm.slot;
  liveSockets.get(gameId)?.[slot] && delete liveSockets.get(gameId)![slot];
  sm.gameId = null;
  sm.slot = null;
  if (session) {
    session.status = session.status === "in_progress" ? "abandoned" : session.status;
    sessionStore.set(gameId, session);
    broadcastToGame(gameId, () => ({ type: "opponent_left" }));
  }
}

function handleDisconnect(ws: WebSocket) {
  const sm = meta.get(ws);
  if (!sm?.gameId || !sm.slot) return;
  const { gameId, slot } = sm;
  const session = sessionStore.get(gameId);
  if (!session) return;

  const player = session[slot];
  if (player) player.connected = false;
  sessionStore.set(gameId, session);

  broadcastToGame(gameId, () => ({ type: "opponent_disconnected", graceMs: RECONNECT_GRACE_MS }));

  sm.disconnectTimer = setTimeout(() => {
    const s = sessionStore.get(gameId);
    if (!s) return;
    const p = s[slot];
    if (p && !p.connected && s.status === "in_progress") {
      // Forfeit: the other player wins by default after the grace period.
      s.status = slot === "player1" ? "player2_won" : "player1_won";
      sessionStore.set(gameId, s);
      broadcastToGame(gameId, (sl) => ({ type: "game_over", session: toPublicSession(s, sl) }));
    }
  }, RECONNECT_GRACE_MS);
}
