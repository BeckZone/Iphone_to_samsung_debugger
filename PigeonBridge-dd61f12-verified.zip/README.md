# PigeonBridge

A cross-platform mini-game system that lets an Android/Samsung user play
against an iPhone GamePigeon user — via PigeonBridge's own invite links and
multiplayer sessions, since Android can't execute Apple's proprietary
GamePigeon iMessage attachments directly.

## Project structure

```
pigeonbridge/
  shared/    TS types, WS message contracts, rules engines for all 6 games
  server/    Express + WebSocket backend, invite pages with Open Graph tags
  web/       Browser client — home page + /play (all 6 games, canvas + click UI)
  android/   Kotlin/Compose Android app
  .github/workflows/android-build.yml   CI that builds a downloadable APK
```

## 1. All working games

All six games are implemented with server-authoritative rules, real-time
WebSocket sync, reconnection, rematch, and win/draw detection — verified via
39 automated tests (unit + live two-socket integration tests) and live
manual playthroughs of every game type over real WebSocket connections:

| Game | Rules engine | Notes |
|---|---|---|
| **Checkers** | Hand-written, `shared/src/games/checkers.ts` | Forced captures, multi-jump, king promotion |
| **Darts** | Hand-written, `shared/src/games/darts.ts` | 501, double-out, bust detection |
| **Chess** | Wraps [`chess.js`](https://github.com/jhlywa/chess.js) | Castling, en passant, promotion, check/checkmate/stalemate/draw — a real library, not hand-rolled legality |
| **Basketball** | Real projectile-motion physics, `shared/src/games/basketball.ts` | Gravity + launch angle/power simulated to an actual trajectory, not a random roll |
| **Cup Pong** | Real projectile physics + collision, `shared/src/games/cuppong.ts` | Landing position computed from the same kind of trajectory sim, checked against cup positions |
| **8-Ball Pool** | Real 2D physics engine, `shared/src/games/eightball.ts` | Elastic ball-ball collisions, cushion bounces, friction, pocket capture, foul/scratch detection, suit assignment, legal 8-ball win/loss |

**Honest scope note on the physics games:** these simulate real 2D
kinematics (not scripted outcomes), but are intentionally 2D-only — no
spin/english, no jump/masse shots, no ball-height effects. That's the
tradeoff for something that runs identically on a phone and stays
synchronized between two clients, versus a full 3D physics engine.

## 2. Tested features

- Game creation, joining, and full move validation (all 6 games) — server rejects illegal moves, out-of-turn moves, and malformed input
- Real-time WebSocket sync between two players, verified live
- Disconnect → grace-period → forfeit-on-timeout, and reconnect mid-game
- Rematch (both players must agree; resets the board, keeps the session)
- Leave game
- Win/draw/checkmate/stalemate detection per game
- Dynamic Open Graph invite pages (`/g/:gameId`) — verified per-game title/description/image for all 6 games
- `/.well-known/assetlinks.json` served with a **real** SHA-256 cert fingerprint (from a genuine generated keystore, not a placeholder)
- REST rate limiting (20 game-creations/min/IP) — verified live, returns 429 after the limit
- Structured JSON request logging in production mode — verified live
- 39/39 automated tests passing (`npm run test -w server`)

## 3. Remaining limitations

- **An actual GamePigeon iMessage attachment still can't run on Android.**
  This is a hard platform limitation, not something this project works
  around — Apple's iMessage attachment format is proprietary and this
  project does not decrypt, intercept, or reverse-engineer iMessage. See
  "The GamePigeon image problem" below for exactly what PigeonBridge does
  instead.
- **Android app has never been compiled in this environment** — there's no
  Android SDK here. It's real, complete Kotlin/Compose source; the first
  real build signal is the CI workflow (see below) or Android Studio. A real
  bug (a missing Gradle plugin required by the `@Serializable` DTOs) was
  found and fixed during this project purely by code review, since it
  couldn't be caught by a local compile — worth knowing if something else
  like it surfaces on your first real build.
- **Automatic incoming-message scanning was not implemented** (Part 8,
  Option B). Reading a user's SMS/RCS stream to auto-detect PigeonBridge
  links is invasive relative to the payoff, since a plain tapped link (and
  the verified Android App Link) already gives a one-tap open. The
  share-to-app flow (Option C) is implemented instead.
- **Basketball/Cup Pong/8-Ball touch controls are 2D physics**, as noted
  above — no spin, jump shots, or 3D effects.
- **No database** — sessions are in-memory (`server/src/game/sessionStore.ts`),
  fine for one server process; horizontal scaling would need Redis or similar
  for shared session state (see "Scaling" below).

## The GamePigeon image problem — exactly what happens and why

When an iPhone user sends an actual GamePigeon game through iMessage to an
Android user, it renders as a **plain image** on Android — this is expected
and PigeonBridge cannot change it (Apple's proprietary attachment format
isn't something a third-party Android app can execute, and this project
doesn't attempt to bypass, decrypt, or impersonate iMessage to try).

What PigeonBridge does instead:

1. **Link recognition (works automatically):** if the message instead
   contains a `pigeonbridge.app/g/...` link, tapping it opens the app
   directly via a verified Android App Link — no chooser, no homepage
   detour. This is the fully-automatic path, verified working.
2. **Automatic image detection was evaluated and not implemented** — see
   "Remaining limitations" above for why.
3. **Image share fallback (implemented):** if the user has an actual
   GamePigeon image (e.g. they long-press → Share → PigeonBridge), the app
   opens `ShareReceiverScreen`, which **honestly explains** that an image
   alone carries no game ID, player identity, board state, or server
   state — there's nothing to actually join — and offers a one-tap path to
   create a real PigeonBridge invite to send back instead. This
   deliberately does **not** run any image classifier that guesses which
   game it might be; a wrong guess would be exactly the false-positive
   detection this project was told not to build, and even a correct guess
   couldn't produce a real joinable session from a static image.

## 4. Running the server + web locally

```bash
npm install
npm run build -w shared
npm run build -w server
npm run build -w web     # produces web/dist, which the server serves as static files
npm run test -w server   # 39 tests
PORT=3001 PUBLIC_BASE_URL=http://localhost:3001 npm run dev:server
```

Then open `http://localhost:3001` to create a game, or `http://localhost:3001/g/<code>`
to see the invite page.

## 5. Deploying the backend

The server is a single Node process serving REST (`/api`), WebSocket (`/ws`),
the invite pages (`/g/:gameId`), and the web app's static files together —
simple to deploy as one thing (Render, Fly.io, a VPS, etc).

Environment variables:
- `PORT` — port to listen on
- `PUBLIC_BASE_URL` — the public https URL (e.g. `https://pigeonbridge.app`), used to build invite links and Open Graph URLs
- `ANDROID_PACKAGE` — must match the Android app's applicationId (`app.pigeonbridge.android` by default) — used in the invite page's `intent://` fallback
- `LOG_LEVEL` — pino log level (default `info`)
- `NODE_ENV=production` — switches logging to structured JSON lines (unset/dev prints pretty-printed logs)

No database credentials or API keys exist yet (sessions are in-memory — see
"Scaling" below), so there's nothing else to configure as a secret on the
server side. The Android signing secrets are documented separately in
`android/keystore/README.md`.

### Scaling beyond one server process
Sessions live in `server/src/game/sessionStore.ts`'s in-memory Map. Fine for
a single instance; running more than one process (for horizontal scaling)
needs shared session state — Redis is the natural fit (swap `sessionStore`'s
Map for Redis hashes, and broadcast WS messages through Redis pub/sub since
two players could land on different server processes).

## 6. Building the Android APK

### Option A — GitHub Actions (no local Android Studio needed)
1. Push this repo to GitHub.
2. `.github/workflows/android-build.yml` runs automatically (GitHub's
   runners have the Android SDK preinstalled) and builds both a debug and
   release APK, signed with the dev keystore by default.
3. Download the APK from the run's **Artifacts** section, or from the
   auto-created GitHub Release if you pushed a tag like `v2.0`.
4. Transfer the APK to a Samsung/Android phone and install it (allow
   "install unknown apps" for whichever app you used to open it).

### Option B — Android Studio (local build)
1. Open `android/` in Android Studio (Giraffe or newer), let Gradle sync.
2. `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
3. Find the APK under `android/app/build/outputs/apk/debug/`.

### Before a real production release
See `android/keystore/README.md` for the full process: generate your own
keystore, set it via `local.properties` (local builds) or GitHub Actions
secrets (CI builds) instead of the checked-in dev key, and update
`assetlinks.json` with the new fingerprint.

## 7. App Link configuration & exact domain requirements

App Links only verify for the **exact** domain and package they're
configured for — if you're not deploying to `pigeonbridge.app`, update all
of these together:

| What | Where | Default value |
|---|---|---|
| Public server URL | `PUBLIC_BASE_URL` env var | — |
| App Links host | `android/app/src/main/AndroidManifest.xml` (`android:host="pigeonbridge.app"`, two intent-filters) | `pigeonbridge.app` |
| Digital Asset Links | `server/public/.well-known/assetlinks.json`, served at `https://<domain>/.well-known/assetlinks.json` | package `app.pigeonbridge.android` + the dev keystore's fingerprint |
| Android package name | `android/app/build.gradle.kts` (`applicationId`) and `server`'s `ANDROID_PACKAGE` env var | `app.pigeonbridge.android` |

How it fits together: Android checks `assetlinks.json` at install time to
confirm the app with that exact package name + signing certificate is
allowed to handle links on that domain; once verified, tapping
`https://<domain>/g/*` opens the app directly (no chooser, no browser
detour). `server/src/routes/invite.ts` also has a JS `intent://` fallback
for the rare case verification hasn't completed yet.

## 8. Exact iPhone instructions

1. Open `https://pigeonbridge.app` in Safari (no install).
2. Pick a game, enter a nickname, tap **CREATE GAME**.
3. Tap **SEND INVITE** → iOS share sheet → Messages → send to the Android friend.
   The message reads:
   ```
   🎮 Let's play Basketball!

   Tap here to play:
   https://pigeonbridge.app/g/8XK29F
   ```
4. Wait on the "waiting for opponent" card — it auto-advances once the Android player joins.
5. Play directly in Safari; no account, no install.

## 9. Exact Android instructions

1. Open the PigeonBridge app (or tap a `pigeonbridge.app/g/*` link someone sent — opens the app directly via App Links).
2. **CREATE GAME** → pick a game, nickname → **SEND INVITE** → native Android share sheet → Messages → send to the iPhone friend.
3. Or **JOIN GAME** and paste/tap a 6-character code or link someone sent you.
4. Checkers/Darts play as native screens; Chess/Basketball/Cup Pong/8-Ball play inside an embedded WebView pointed at the same multiplayer session (see "Android architecture note" below).
5. If a GamePigeon image (not a PigeonBridge link) arrives instead, use Android's **Share → PigeonBridge** on that image — see "The GamePigeon image problem" above for exactly what happens.

## Android architecture note: why 4 of 6 games use a WebView

Checkers and Darts are native Jetpack Compose screens. Chess, Basketball,
Cup Pong, and 8-Ball Pool instead embed a `WebView` pointed at the same
`/play` page the browser client uses. This is a deliberate choice, not a
placeholder: it avoids maintaining two separate, divergent implementations
of non-trivial canvas drag-physics UI (one in browser Canvas/JS, one in
Kotlin Compose Canvas), the WebView is real Chromium on-device so
touch/canvas behavior matches Android Chrome exactly, and it connects to the
exact same server-authoritative multiplayer session over the same
WebSocket protocol either client uses.

## Database schema

There isn't one — by design, for this MVP. Game sessions are the only
server-side state, and they live entirely in memory
(`server/src/game/sessionStore.ts`'s `Map<gameId, GameSession>`), because a
game session is inherently short-lived (created, played, abandoned or
finished within a session's `GAME_ABANDON_TIMEOUT_MS` window) and nothing
about this project currently needs data to outlive a single game. If
persistent accounts, match history, or cross-device session recovery are
added later, that's the point at which a real schema (players, game_sessions
with a JSONB board-state column, move history) and a database (Postgres is
the natural fit given the JSON-shaped board state) would get introduced —
deliberately not built ahead of an actual need.
