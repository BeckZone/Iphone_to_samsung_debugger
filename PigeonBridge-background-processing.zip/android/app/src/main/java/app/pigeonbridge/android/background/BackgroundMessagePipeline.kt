package app.pigeonbridge.android.background

import android.app.Notification
import android.content.Context
import androidx.core.app.NotificationCompat
import app.pigeonbridge.android.emoji.EmojiAssets
import app.pigeonbridge.android.emoji.EmojiSegmenter
import app.pigeonbridge.android.messages.MessageFeed
import app.pigeonbridge.android.messages.NotificationMessageReader

/**
 * The text/emoji half of background processing. Called by the notification listener for each
 * supported-app notification, after the listener's own gate has already said PROCESS.
 *
 * Event-driven: it runs only inside onNotificationPosted. There is no timer, no polling, no
 * WorkManager job and no foreground service, because everything it does is a few milliseconds
 * of work per real event.
 *
 * Steps: read the messages -> keep only ones not seen before -> record diagnostics -> for each
 * new message decide (pure planner) whether a PigeonBridge notification is warranted -> post it.
 * It never cancels or alters the messaging app's own notification.
 */
object BackgroundMessagePipeline {
    private val planner = ProcessedNotificationPlanner()

    fun handle(
        context: Context,
        packageName: String,
        notificationKey: String,
        postTime: Long,
        notification: Notification,
        styleMessages: List<NotificationCompat.MessagingStyle.Message>,
    ) {
        val now = System.currentTimeMillis()
        BackgroundProcessingState.recordEvent(now)

        val read = NotificationMessageReader.read(packageName, notificationKey, postTime, notification, styleMessages)
        val fresh = MessageFeed.shared.addAndGetNew(read)
        if (fresh.isEmpty()) return // re-delivery of messages we already handled: do nothing

        val settings = BackgroundSettings.snapshot()
        val lookup = EmojiAssets.lookup(context)

        for (message in fresh) {
            val count = lookup?.let { EmojiSegmenter.findEmoji(message.text, it).size } ?: 0
            val method = when {
                lookup == null -> "System font (emoji artwork could not be loaded)"
                count == 0 -> "No emoji in this message"
                settings.alternateEmojiArtwork -> "Twemoji artwork (drawn inside PigeonBridge only)"
                else -> "System font (emoji artwork switch is off)"
            }
            val onlyKeys = if (lookup != null && settings.alternateEmojiArtwork) {
                EmojiSegmenter.emojiOnlyFileKeys(message.text, lookup)
            } else {
                null
            }

            var surfaced = SurfacedVia.NONE
            val result = planner.plan(message, onlyKeys, settings, now)
            if (result is PlanResult.Post && ProcessedEmojiNotifier.post(context, result.plan)) {
                surfaced = SurfacedVia.PROCESSED_NOTIFICATION
            }
            BackgroundProcessingState.recordProcessed(now, count, method, surfaced)
        }
    }
}
