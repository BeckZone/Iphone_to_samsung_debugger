package app.pigeonbridge.android.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.pigeonbridge.android.attachment.DiagnosticReport
import app.pigeonbridge.android.attachment.DiagnosticReportFormatter
import app.pigeonbridge.android.attachment.DiagnosticRunner
import app.pigeonbridge.android.attachment.QualityClass
import app.pigeonbridge.android.ui.PigeonCard
import app.pigeonbridge.android.ui.PrimaryButton
import app.pigeonbridge.android.ui.SecondaryButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Debug-only diagnostic tool for the real-world iPhone -> Samsung sticker
 * problem. Answers one question with observable evidence: exactly what
 * attachment data is Android actually handing PigeonBridge for a given
 * shared image.
 *
 * Entry point: reached only from ShareReceiverScreen's debug-only
 * "View Diagnostics" link (itself gated on BuildConfig.DEBUG — see
 * ShareReceiverScreen.kt), passing along the SAME real content:// Uri
 * received from the share intent. This screen re-checks BuildConfig.DEBUG
 * itself too, as defense in depth in case it's ever reached another way.
 *
 * This is read-only: it reuses AttachmentInspector / StickerDetector /
 * AttachmentBitmapDecoder exactly as the real pipeline does, and adds only
 * read-only probes (DiagnosticRunner) on top. It never modifies the
 * attachment, never recompresses/upscales anything, never requests new
 * permissions, and never uploads anything anywhere.
 */
@Composable
fun DiagnosticScreen(
    imageUri: String,
    onBack: () -> Unit,
) {
    if (!app.pigeonbridge.android.BuildConfig.DEBUG) {
        // Defense in depth: this screen must never do anything in a release build.
        Scaffold(topBar = { TopAppBar(title = { Text("Diagnostics") }) }) { padding ->
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("Diagnostic Mode is only available in debug builds.")
            }
        }
        return
    }

    val context = LocalContext.current
    val uri = remember(imageUri) { Uri.parse(imageUri) }

    var report by remember { mutableStateOf<DiagnosticReport?>(null) }
    var previewBitmap by remember { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(null) }
    var isRunning by remember { mutableStateOf(false) }
    var runCount by remember { mutableStateOf(0) }

    suspend fun runDiagnostics() {
        isRunning = true
        val result = withContext(Dispatchers.IO) { DiagnosticRunner.run(context, uri) }
        report = result.report
        previewBitmap = result.decodedBitmap?.asImageBitmap()
        isRunning = false
    }

    LaunchedEffect(imageUri, runCount) {
        runDiagnostics()
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Diagnostic Mode") }) }) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp),
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    SecondaryButton("Run Diagnostics", enabled = !isRunning) { runCount++ }
                }
                Box(modifier = Modifier.weight(1f)) {
                    SecondaryButton("Clear") {
                        report = null
                        previewBitmap = null
                    }
                }
                Box(modifier = Modifier.weight(1f)) {
                    SecondaryButton("Back") { onBack() }
                }
            }

            if (isRunning) {
                Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }

            val currentReport = report
            if (currentReport != null) {
                DiagnosticReportView(report = currentReport, previewBitmap = previewBitmap, context = context)
            }
        }
    }
}

@Composable
private fun DiagnosticReportView(
    report: DiagnosticReport,
    previewBitmap: androidx.compose.ui.graphics.ImageBitmap?,
    context: Context,
) {
    LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        item {
            if (previewBitmap != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                        .clip(RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    Image(
                        bitmap = previewBitmap,
                        contentDescription = "Decoded attachment preview",
                        contentScale = ContentScale.Fit, // never upscaled — Fit only ever shrinks to bounds, preserving aspect ratio
                        modifier = Modifier.fillMaxSize(),
                    )
                }
                Text(
                    "Decoded dimensions: ${report.decodedWidthPx ?: "?"} × ${report.decodedHeightPx ?: "?"}",
                    fontSize = 12.sp,
                    modifier = Modifier.padding(vertical = 6.dp),
                )
            } else {
                Text("No preview — bitmap decode failed or hasn't run yet.", fontSize = 13.sp, modifier = Modifier.padding(vertical = 12.dp))
            }
        }

        item { DiagnosticSection("URI") {
            DiagnosticRow("Scheme", report.uriScheme ?: "Unknown")
            DiagnosticRow("Authority", report.uriAuthority ?: "Unknown")
            DiagnosticRow("Path", report.uriPath ?: "Unknown")
        } }

        item { DiagnosticSection("MIME") {
            DiagnosticRow("Reported", report.mimeReported ?: "Unknown")
            DiagnosticRow("Detected (bytes)", report.mimeDetectedFromBytes ?: "Unknown")
            if (report.mimeReported != null && report.mimeDetectedFromBytes != null && report.mimeReported != report.mimeDetectedFromBytes) {
                DiagnosticRow("⚠ Disagreement", "Reported and detected MIME differ", warn = true)
            }
            DiagnosticRow("File extension", report.fileExtension ?: "Unknown")
        } }

        item { DiagnosticSection("File metadata") {
            DiagnosticRow("Display name", report.displayName ?: "Unknown")
            DiagnosticRow(
                "File size",
                if (report.reportedSizeBytes >= 0) "${"%,d".format(report.reportedSizeBytes)} bytes" else "Size unavailable",
            )
            DiagnosticRow("Last modified", report.lastModifiedMillis?.toString() ?: "Unknown")
        } }

        item { DiagnosticSection("Image metadata") {
            DiagnosticRow("Dimensions", if (report.widthPx > 0) "${report.widthPx} × ${report.heightPx}" else "Unknown")
            DiagnosticRow(
                "Aspect ratio",
                if (report.widthPx > 0 && report.heightPx > 0) "%.2f".format(report.widthPx.toDouble() / report.heightPx.toDouble()) else "Unknown",
            )
            DiagnosticRow("Bit depth / color format", report.bitDepthDescription ?: "Unknown")
            DiagnosticRow("Alpha", boolText(report.hasAlpha))
            DiagnosticRow("Animated", boolText(report.isAnimated))
            DiagnosticRow("Frame count", report.frameCount?.toString() ?: "Unknown")
            DiagnosticRow("EXIF orientation", report.exifOrientationRaw?.toString() ?: "Unknown")
        } }

        item { DiagnosticSection("Preview detection") {
            DiagnosticRow("Preview suspected", if (report.previewSuspected) "YES" else "NO")
            report.previewReasons.forEach { DiagnosticRow("Reason", it) }
        } }

        item { DiagnosticSection("Sticker classification") {
            DiagnosticRow("Result", report.classification.name)
            DiagnosticRow("Sticker score", "${report.stickerScore} (photo: ${report.photoScore})")
            report.classificationSignals.forEach { DiagnosticRow(it.name, it.detail) }
        } }

        item { DiagnosticSection("Readability tests") {
            DiagnosticRow("Test A — URI readable", if (report.uriReadable) "YES" else "NO")
            DiagnosticRow("Test B — Stream readable", if (report.streamReadable) "YES" else "NO")
            DiagnosticRow("Test C — Bitmap decode", if (report.bitmapDecodeSucceeded) "SUCCESS" else "FAIL")
        } }

        item { DiagnosticSection("URI permissions") {
            DiagnosticRow("Read permission", boolText(report.readPermissionGranted))
            DiagnosticRow("Persistable permission", if (report.persistablePermissionGranted) "YES" else "NO")
            DiagnosticRow("Granted via", report.grantedVia)
        } }

        item { DiagnosticSection("Alternate representations") {
            DiagnosticRow("", report.alternateRepresentationSummary)
        } }

        item { DiagnosticSection("Quality") {
            DiagnosticRow("Attachment quality", qualityText(report.quality))
            DiagnosticRow("Reason", report.qualityReason)
        } }

        item { BackgroundMonitoringSection(context) }

        item {
            Column(modifier = Modifier.padding(vertical = 16.dp)) {
                PrimaryButton("COPY DIAGNOSTIC REPORT") {
                    val text = DiagnosticReportFormatter.format(report)
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("PigeonBridge Attachment Diagnostic", text))
                }
            }
        }
    }
}

@Composable
private fun DiagnosticSection(title: String, content: @Composable () -> Unit) {
    PigeonCard(modifier = Modifier.padding(vertical = 6.dp)) {
        Column {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(bottom = 6.dp))
            content()
        }
    }
}

@Composable
private fun DiagnosticRow(label: String, value: String, warn: Boolean = false) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        if (label.isNotEmpty()) {
            Text(label, fontSize = 12.sp, color = Color(0xFFA8A3C7), modifier = Modifier.padding(end = 8.dp))
        }
        Text(
            value,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace,
            color = if (warn) Color(0xFFFBBF24) else Color.Unspecified,
        )
    }
}

private fun boolText(b: Boolean?): String = when (b) {
    true -> "YES"
    false -> "NO"
    null -> "Unknown"
}

private fun qualityText(q: QualityClass): String = when (q) {
    QualityClass.FULL_LARGE -> "FULL / LARGE"
    QualityClass.SMALL -> "SMALL"
    QualityClass.UNKNOWN -> "UNKNOWN"
}

@Composable
private fun BackgroundMonitoringSection(context: Context) {
    val notificationAccess = app.pigeonbridge.android.monitoring.MonitoringState.notificationAccessGranted(context)
    val smsRoleHeld = app.pigeonbridge.android.monitoring.DefaultSmsRoleHelper.isRoleHeld(context)
    val listenerActive = app.pigeonbridge.android.monitoring.MonitoringState.listenerServiceActive()
    val event = app.pigeonbridge.android.monitoring.MonitoringState.lastAttachmentEvent()

    DiagnosticSection("Background monitoring") {
        DiagnosticRow("Background monitoring", if (app.pigeonbridge.android.monitoring.MonitoringState.monitoringEnabled) "ON" else "OFF")
        DiagnosticRow("Notification access", if (notificationAccess) "ON" else "OFF")
        DiagnosticRow("Listener service", if (listenerActive) "Active" else "Not observed")
        DiagnosticRow("SMS role", if (smsRoleHeld) "ON" else "OFF")
        DiagnosticRow("Last messaging package detected", event?.messagingPackage ?: "None yet")
        DiagnosticRow("Attachment exposed", event?.let { if (it.attachmentExposed) "YES" else "NO" } ?: "N/A")
        DiagnosticRow("Attachment URI available", event?.let { if (it.attachmentUriAvailable) "YES" else "NO" } ?: "N/A")
        DiagnosticRow("Last extraction result", event?.let { if (it.extractionSucceeded) "SUCCESS" else "FAILURE" } ?: "N/A")
        DiagnosticRow("Attachment MIME", event?.attachmentMime ?: "Unknown")
        DiagnosticRow("Attachment size", event?.attachmentSizeBytes?.let { "$it bytes" } ?: "Unknown")
        DiagnosticRow("Attachment dimensions", event?.attachmentDimensions ?: "Unknown")
        DiagnosticRow("Sticker classification", event?.stickerClassification ?: "N/A")
        DiagnosticRow("Quality classification", event?.qualityClassification ?: "N/A")
        DiagnosticRow("Processing result", event?.processingResult ?: "No attachment processed yet")
        if (event?.failureReason != null) {
            DiagnosticRow("Failure reason", event.failureReason, warn = true)
        }
        DiagnosticRow("Extraction source", event?.attachmentSource ?: "none")
        val bg = app.pigeonbridge.android.background.BackgroundProcessingState.status(context)
        val fmt = { ms: Long? -> ms?.let { java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.SHORT, java.text.DateFormat.MEDIUM).format(java.util.Date(it)) } ?: "None yet" }
        DiagnosticRow("Last message event", fmt(bg.lastMessageEventMillis))
        DiagnosticRow("Last successful processing", fmt(bg.lastProcessedMillis))
        DiagnosticRow("Emoji detected (last message)", bg.lastEmojiCount?.toString() ?: "N/A")
        DiagnosticRow("Emoji rendering method", bg.lastRenderingMethod ?: "N/A")
        DiagnosticRow("Surfaced into Messages UI", app.pigeonbridge.android.background.ProcessingStatusFormatter.SURFACED_INTO_MESSAGES_UI)
        DiagnosticRow("Status", app.pigeonbridge.android.background.ProcessingStatusFormatter.headline(bg))
    }
}
