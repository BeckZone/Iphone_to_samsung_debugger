// Pure, DOM-free byte-level parsing. Kept separate from analyzer.ts (which
// needs Image()/canvas, browser-only) so this half can run and be unit
// tested under plain Node.

/** Sniffs MIME type from magic bytes -- independent of what the browser's File.type reports. Mirrors the same signature checks as the Android AttachmentInspector/DiagnosticRunner. */
export function detectMimeFromBytes(bytes: Uint8Array): string | null {
  if (bytes.length < 4) return null;
  if (bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47) return "image/png";
  if (bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return "image/jpeg";
  if (bytes.length >= 12 && asciiAt(bytes, 0, 4) === "RIFF" && asciiAt(bytes, 8, 4) === "WEBP") return "image/webp";
  if (bytes.length >= 6 && (asciiAt(bytes, 0, 6) === "GIF87a" || asciiAt(bytes, 0, 6) === "GIF89a")) return "image/gif";
  if (bytes.length >= 12 && asciiAt(bytes, 4, 4) === "ftyp") return "image/heic";
  return null;
}

function asciiAt(bytes: Uint8Array, offset: number, len: number): string {
  let s = "";
  for (let i = 0; i < len; i++) s += String.fromCharCode(bytes[offset + i]);
  return s;
}

/** Parses a PNG's IHDR chunk (always the first chunk, fixed offset) for bit depth + color type. Returns null for anything that isn't a well-formed PNG header. */
export function parsePngIhdr(bytes: Uint8Array): { bitDepth: number; colorType: number; description: string } | null {
  if (bytes.length < 26) return null;
  if (detectMimeFromBytes(bytes) !== "image/png") return null;
  // PNG signature (8 bytes) + IHDR chunk: length(4) "IHDR"(4) width(4) height(4) bitDepth(1) colorType(1) ...
  if (asciiAt(bytes, 12, 4) !== "IHDR") return null;
  const bitDepth = bytes[24];
  const colorType = bytes[25];
  const colorTypeName: Record<number, string> = {
    0: "Grayscale",
    2: "RGB",
    3: "Palette",
    4: "Grayscale+Alpha",
    6: "RGBA",
  };
  const name = colorTypeName[colorType] ?? `type ${colorType}`;
  return { bitDepth, colorType, description: `${name}, ${bitDepth}-bit/channel` };
}

/**
 * Counts GIF frames by walking the block structure (does not decode pixel
 * data). Returns null if the buffer isn't a well-formed-enough GIF to walk
 * safely, rather than guessing. A GIF with more than 1 image descriptor
 * block is animated.
 */
export function countGifFrames(bytes: Uint8Array): number | null {
  if (detectMimeFromBytes(bytes) !== "image/gif") return null;
  try {
    let pos = 6; // past "GIF87a"/"GIF89a"
    if (pos + 7 > bytes.length) return null;
    const packed = bytes[pos + 4];
    const hasGlobalColorTable = (packed & 0x80) !== 0;
    const globalColorTableSize = hasGlobalColorTable ? 3 * Math.pow(2, (packed & 0x07) + 1) : 0;
    pos += 7 + globalColorTableSize; // logical screen descriptor (7 bytes) + optional global color table

    let frames = 0;
    let guard = 0;
    while (pos < bytes.length && guard < 100_000) {
      guard++;
      const marker = bytes[pos];
      if (marker === 0x3b) break; // trailer
      if (marker === 0x21) {
        // Extension block: label byte, then sub-blocks terminated by a 0x00 size byte.
        pos += 2;
        pos = skipSubBlocks(bytes, pos);
      } else if (marker === 0x2c) {
        // Image descriptor: 9 bytes header, then optional local color table, then LZW min code size + sub-blocks.
        frames++;
        const lctPacked = bytes[pos + 9];
        const hasLocalColorTable = (lctPacked & 0x80) !== 0;
        const localColorTableSize = hasLocalColorTable ? 3 * Math.pow(2, (lctPacked & 0x07) + 1) : 0;
        pos += 10 + localColorTableSize; // image descriptor (10 bytes incl. packed) + local color table
        pos += 1; // LZW minimum code size
        pos = skipSubBlocks(bytes, pos);
      } else {
        // Unexpected byte -- stop rather than risk an infinite/incorrect walk.
        break;
      }
    }
    return frames > 0 ? frames : null;
  } catch {
    return null;
  }
}

function skipSubBlocks(bytes: Uint8Array, startPos: number): number {
  let pos = startPos;
  while (pos < bytes.length) {
    const size = bytes[pos];
    pos += 1;
    if (size === 0) break;
    pos += size;
  }
  return pos;
}

/**
 * Animated WebP files always contain an "ANIM" chunk (FourCC) right after
 * the VP8X chunk; static WebP files never do. A bounded substring search
 * for that exact 4-byte tag is a reliable, honest best-effort signal --
 * not a full RIFF chunk walk, but a real structural fact about the format,
 * not a guess.
 */
export function hasWebpAnimChunk(bytes: Uint8Array): boolean {
  if (detectMimeFromBytes(bytes) !== "image/webp") return false;
  const searchLimit = Math.min(bytes.length, 4096); // ANIM chunk is always near the start
  for (let i = 12; i < searchLimit - 4; i++) {
    if (bytes[i] === 0x41 && bytes[i + 1] === 0x4e && bytes[i + 2] === 0x49 && bytes[i + 3] === 0x4d) {
      return true; // "ANIM"
    }
  }
  return false;
}
