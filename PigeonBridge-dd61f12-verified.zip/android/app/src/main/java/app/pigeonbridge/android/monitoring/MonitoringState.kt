package app.pigeonbridge.android.monitoring

import android.content.Context
import androidx.core.app.NotificationManagerCompat
import app.pigeonbridge.android.PigeonBridgeApp

/**
 * One captured notification event's worth of diagnostic data. Persisted as
 * plain SharedPreferences values so it survives process death -- the
 * listener can be killed/restarted by the system at any time, and this
 * state must still be readable afterward.
 */
data class LastAttachmentEvent(
    val messagingPackage: String?,
    val notificationTimestampMillis: Long?,
    val attachmentExposed: Boolean,
    /** True only when a discovered Uri was actually opened successfully (ContentResolver.openInputStream succeeded) -- never assumed from a Uri merely being present. */
    val attachmentUriAvailable: Boolean,
    /** Whether SOME usable data (readable Uri or notification-embedded bitmap) was obtained at all -- distinct from attachmentUriAvailable, which is specifically about a direct source-file read. */
    val extractionSucceeded: Boolean,
    val attachmentMime: String?,
    val attachmentSizeBytes: Long?,
    val attachmentDimensions: String?,
    val stickerClassification: String?,
    val qualityClassification: String?,
    val processingResult: String,
    /** Set only when extraction or processing failed, with a short human-readable reason -- null on success. */
    val failureReason: String?,
    /** Where the data actually came from -- e.g. "MessagingStyle.Message.dataUri", "EXTRA_PICTURE_ICON (bitmap)", "none". Shown in Diagnostics so it's clear this was tested, not assumed. */
    val attachmentSource: String,
)

/**
 * Minimal metadata-only snapshot of the last relevant notification, for the
 * debug-only Notification Test screen. Deliberately does NOT store the
 * notification's free-text body beyond a short, truncated preview -- per
 * spec: "store only the minimum metadata needed for debugging."
 */
data class LastNotificationSnapshot(
    val packageName: String,
    val postedAtMillis: Long,
    val hasExtraPicture: Boolean,
    val hasExtraPictureIcon: Boolean,
    val messagingStyleMessageCount: Int,
    val messagingStyleDataUriCount: Int,
    /** "keyName:TypeSimpleName" pairs, e.g. "android.text:String" -- key names AND object types, never values, per spec section 4. */
    val extraKeyTypes: List<String>,
    /** Scheme + authority only of any discovered Uri, e.g. "content://com.samsung.android.messaging.fileprovider" -- never the full path, which could itself be identifying. */
    val discoveredUriAuthority: String?,
    /** First ~40 chars only, for "does this look like an image message" debugging -- not the full message. */
    val textPreviewTruncated: String?,
)

private const val PREFS = "pigeonbridge_monitoring"
private const val KEY_MONITORING_ENABLED = "monitoring_enabled"
private const val KEY_SMS_ROLE_REQUESTED_ONCE = "sms_role_requested_once"
private const val KEY_LISTENER_CONNECTED_AT = "listener_connected_at"

object MonitoringState {
    private val prefs get() = PigeonBridgeApp.instance.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** User-facing soft toggle. The NotificationListenerService keeps receiving system callbacks
     * regardless (that's controlled only by the OS-level Notification Access grant), but when this
     * is off, PigeonBridgeNotificationListener no-ops instead of processing anything -- this is how
     * "Disable Monitoring" works without the user having to revoke OS-level notification access. */
    var monitoringEnabled: Boolean
        get() = prefs.getBoolean(KEY_MONITORING_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_MONITORING_ENABLED, value).apply()

    var smsRoleRequestedOnce: Boolean
        get() = prefs.getBoolean(KEY_SMS_ROLE_REQUESTED_ONCE, false)
        set(value) = prefs.edit().putBoolean(KEY_SMS_ROLE_REQUESTED_ONCE, value).apply()

    fun notificationAccessGranted(context: Context): Boolean {
        val enabledListeners = NotificationManagerCompat.getEnabledListenerPackages(context)
        return context.packageName in enabledListeners
    }

    /** Call from PigeonBridgeNotificationListener.onListenerConnected() -- this is the system confirming
     * it actually bound to our service, which is a stronger "is this alive" signal than notification
     * access merely being granted in Settings (the grant can exist while the service itself hasn't been
     * (re)bound yet, e.g. right after a fresh install or an OS-triggered service restart). */
    fun recordListenerConnected() {
        prefs.edit().putLong(KEY_LISTENER_CONNECTED_AT, System.currentTimeMillis()).apply()
    }

    fun listenerLastConnectedMillis(): Long? = prefs.getLong(KEY_LISTENER_CONNECTED_AT, -1).takeIf { it >= 0 }

    /** "Active" means the system has bound to our listener at least once this install; it does not mean
     * a messaging notification has necessarily arrived yet. Shown as "Active / Not observed" per spec. */
    fun listenerServiceActive(): Boolean = listenerLastConnectedMillis() != null

    fun recordAttachmentEvent(event: LastAttachmentEvent) {
        prefs.edit()
            .putString("evt_pkg", event.messagingPackage)
            .putLong("evt_ts", event.notificationTimestampMillis ?: -1)
            .putBoolean("evt_exposed", event.attachmentExposed)
            .putBoolean("evt_uri_avail", event.attachmentUriAvailable)
            .putBoolean("evt_extraction_ok", event.extractionSucceeded)
            .putString("evt_mime", event.attachmentMime)
            .putLong("evt_size", event.attachmentSizeBytes ?: -1)
            .putString("evt_dims", event.attachmentDimensions)
            .putString("evt_sticker", event.stickerClassification)
            .putString("evt_quality", event.qualityClassification)
            .putString("evt_result", event.processingResult)
            .putString("evt_failure", event.failureReason)
            .putString("evt_source", event.attachmentSource)
            .apply()
    }

    fun lastAttachmentEvent(): LastAttachmentEvent? {
        val pkg = prefs.getString("evt_pkg", null) ?: return null
        return LastAttachmentEvent(
            messagingPackage = pkg,
            notificationTimestampMillis = prefs.getLong("evt_ts", -1).takeIf { it >= 0 },
            attachmentExposed = prefs.getBoolean("evt_exposed", false),
            attachmentUriAvailable = prefs.getBoolean("evt_uri_avail", false),
            extractionSucceeded = prefs.getBoolean("evt_extraction_ok", false),
            attachmentMime = prefs.getString("evt_mime", null),
            attachmentSizeBytes = prefs.getLong("evt_size", -1).takeIf { it >= 0 },
            attachmentDimensions = prefs.getString("evt_dims", null),
            stickerClassification = prefs.getString("evt_sticker", null),
            qualityClassification = prefs.getString("evt_quality", null),
            processingResult = prefs.getString("evt_result", null) ?: "No attachment processed yet",
            failureReason = prefs.getString("evt_failure", null),
            attachmentSource = prefs.getString("evt_source", null) ?: "none",
        )
    }

    fun recordNotificationSnapshot(snapshot: LastNotificationSnapshot) {
        prefs.edit()
            .putString("ntf_pkg", snapshot.packageName)
            .putLong("ntf_ts", snapshot.postedAtMillis)
            .putBoolean("ntf_pic", snapshot.hasExtraPicture)
            .putBoolean("ntf_pic_icon", snapshot.hasExtraPictureIcon)
            .putInt("ntf_msg_count", snapshot.messagingStyleMessageCount)
            .putInt("ntf_msg_uri_count", snapshot.messagingStyleDataUriCount)
            .putString("ntf_extra_key_types", snapshot.extraKeyTypes.joinToString("|"))
            .putString("ntf_uri_authority", snapshot.discoveredUriAuthority)
            .putString("ntf_text_preview", snapshot.textPreviewTruncated)
            .apply()
    }

    fun lastNotificationSnapshot(): LastNotificationSnapshot? {
        val pkg = prefs.getString("ntf_pkg", null) ?: return null
        return LastNotificationSnapshot(
            packageName = pkg,
            postedAtMillis = prefs.getLong("ntf_ts", 0),
            hasExtraPicture = prefs.getBoolean("ntf_pic", false),
            hasExtraPictureIcon = prefs.getBoolean("ntf_pic_icon", false),
            messagingStyleMessageCount = prefs.getInt("ntf_msg_count", 0),
            messagingStyleDataUriCount = prefs.getInt("ntf_msg_uri_count", 0),
            extraKeyTypes = prefs.getString("ntf_extra_key_types", "")?.split("|")?.filter { it.isNotBlank() } ?: emptyList(),
            discoveredUriAuthority = prefs.getString("ntf_uri_authority", null),
            textPreviewTruncated = prefs.getString("ntf_text_preview", null),
        )
    }

    /** Clears ONLY PigeonBridge's own diagnostic SharedPreferences file. Never touches any other
     * app's notifications, messages, or files -- there is nothing else in this file to clear. */
    fun clearMonitoringHistory() {
        prefs.edit()
            .remove("evt_pkg").remove("evt_ts").remove("evt_exposed").remove("evt_uri_avail")
            .remove("evt_extraction_ok").remove("evt_mime").remove("evt_size").remove("evt_dims")
            .remove("evt_sticker").remove("evt_quality").remove("evt_result").remove("evt_failure")
            .remove("evt_source")
            .remove("ntf_pkg").remove("ntf_ts").remove("ntf_pic").remove("ntf_pic_icon")
            .remove("ntf_msg_count").remove("ntf_msg_uri_count").remove("ntf_extra_key_types")
            .remove("ntf_uri_authority").remove("ntf_text_preview")
            .apply()
        // Deliberately does NOT touch KEY_MONITORING_ENABLED, KEY_SMS_ROLE_REQUESTED_ONCE, or
        // KEY_LISTENER_CONNECTED_AT -- those are configuration/liveness state, not "history".
    }
}
