import { GAME_TYPES, GAME_DISPLAY_NAMES, GAME_EMOJI, IMPLEMENTED_GAMES, GameType, CreateGameResponse } from "@pigeonbridge/shared";

const NICK_KEY = "pigeonbridge_nickname";

const gameGrid = document.getElementById("gameGrid")!;
const nicknameInput = document.getElementById("nickname") as HTMLInputElement;
const createBtn = document.getElementById("createBtn") as HTMLButtonElement;
const createCard = document.getElementById("createCard")!;
const inviteCard = document.getElementById("inviteCard")!;
const inviteCode = document.getElementById("inviteCode")!;
const sendInviteBtn = document.getElementById("sendInviteBtn") as HTMLButtonElement;
const copyLinkBtn = document.getElementById("copyLinkBtn") as HTMLButtonElement;
const joinCode = document.getElementById("joinCode") as HTMLInputElement;
const joinBtn = document.getElementById("joinBtn") as HTMLButtonElement;

let selectedGame: GameType | null = null;
let currentShareText = "";
let currentJoinUrl = "";

try {
  const saved = localStorage.getItem(NICK_KEY);
  if (saved) nicknameInput.value = saved;
} catch {}

for (const gt of GAME_TYPES) {
  const btn = document.createElement("div");
  const implemented = (IMPLEMENTED_GAMES as readonly GameType[]).includes(gt);
  btn.className = "game-btn" + (implemented ? "" : " disabled");
  btn.innerHTML = `<span class="e">${GAME_EMOJI[gt]}</span>${GAME_DISPLAY_NAMES[gt]}${implemented ? "" : "<br><small>coming soon</small>"}`;
  if (implemented) {
    btn.addEventListener("click", () => {
      selectedGame = gt;
      [...Array.from(gameGrid.children)].forEach((c) => c.classList.remove("selected"));
      btn.classList.add("selected");
    });
  }
  gameGrid.appendChild(btn);
}

createBtn.addEventListener("click", async () => {
  const nickname = nicknameInput.value.trim();
  if (!selectedGame) return alert("Pick a game first.");
  if (!nickname) return alert("Enter a nickname first.");
  try {
    localStorage.setItem(NICK_KEY, nickname);
  } catch {}

  createBtn.disabled = true;
  createBtn.textContent = "Creating…";
  try {
    const res = await fetch("/api/games", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ gameType: selectedGame, nickname }),
    });
    if (!res.ok) throw new Error((await res.json())?.message || "Failed to create game");
    const data: CreateGameResponse = await res.json();
    currentShareText = data.shareText;
    currentJoinUrl = data.joinUrl;
    inviteCode.textContent = data.gameId;
    createCard.classList.add("hidden");
    inviteCard.classList.remove("hidden");
    pollForOpponent(data.gameId, selectedGame, nickname);
  } catch (e: any) {
    alert(e.message || "Something went wrong");
  } finally {
    createBtn.disabled = false;
    createBtn.textContent = "CREATE GAME";
  }
});

sendInviteBtn.addEventListener("click", async () => {
  if (navigator.share) {
    try {
      await navigator.share({ text: currentShareText, url: currentJoinUrl });
      return;
    } catch {
      /* user cancelled or share unsupported for this payload; fall through to copy */
    }
  }
  await copyToClipboard(currentShareText);
  alert("Invite copied — paste it into Messages.");
});

copyLinkBtn.addEventListener("click", async () => {
  await copyToClipboard(currentJoinUrl);
  copyLinkBtn.textContent = "Copied!";
  setTimeout(() => (copyLinkBtn.textContent = "COPY LINK"), 1500);
});

async function copyToClipboard(text: string) {
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const ta = document.createElement("textarea");
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand("copy");
    document.body.removeChild(ta);
  }
}

joinBtn.addEventListener("click", () => {
  const code = joinCode.value.trim().toUpperCase();
  if (code.length !== 6) return alert("Enter the 6-character invite code.");
  const nickname = nicknameInput.value.trim() || prompt("Your nickname?") || "";
  if (!nickname) return;
  try {
    localStorage.setItem(NICK_KEY, nickname);
  } catch {}
  window.location.href = `/play?gameId=${encodeURIComponent(code)}&nickname=${encodeURIComponent(nickname)}`;
});

// Lightweight poll (host side) just to flip the label once someone joins;
// the actual game itself is played on /play once the host also heads there.
function pollForOpponent(gameId: string, gameType: GameType, nickname: string) {
  const waitingLabel = document.getElementById("waitingLabel")!;
  const iv = setInterval(async () => {
    try {
      const res = await fetch(`/api/games/${gameId}`);
      if (!res.ok) return;
      const data = await res.json();
      if (data.hasSecondPlayer) {
        clearInterval(iv);
        waitingLabel.textContent = "Opponent joined! Opening game…";
        setTimeout(() => {
          window.location.href = `/play?gameId=${encodeURIComponent(gameId)}&nickname=${encodeURIComponent(nickname)}`;
        }, 600);
      }
    } catch {}
  }, 2000);
}
