package app.pigeonbridge.android.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.pigeonbridge.android.data.GAME_DISPLAY_NAMES
import app.pigeonbridge.android.data.GAME_EMOJI
import app.pigeonbridge.android.data.GameType
import app.pigeonbridge.android.ui.GameViewModel
import app.pigeonbridge.android.ui.PigeonCard
import app.pigeonbridge.android.ui.PrimaryButton
import app.pigeonbridge.android.ui.SecondaryButton

@Composable
fun HomeScreen(
    viewModel: GameViewModel,
    onCreateGame: () -> Unit,
    onJoinGame: () -> Unit,
    onOpenRecentGame: (String) -> Unit,
    onOpenSettings: () -> Unit,
) {
    val recent = viewModel.recentGames()

    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.End) {
                IconButton(onClick = onOpenSettings) {
                    Text("⚙️", fontSize = 20.sp)
                }
            }
            Text("🎮 PigeonBridge", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Column(modifier = Modifier.padding(top = 40.dp)) {
                PrimaryButton("CREATE GAME", onClick = onCreateGame)
            }
            Column(modifier = Modifier.padding(top = 12.dp)) {
                SecondaryButton("JOIN GAME", onClick = onJoinGame)
            }

            if (recent.isNotEmpty()) {
                Column(modifier = Modifier.padding(top = 28.dp).fillMaxSize()) {
                    Text("Recent Games", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 10.dp)) {
                        items(recent) { entry ->
                            val parts = entry.split("|")
                            val gameId = parts.getOrNull(0) ?: return@items
                            val gameTypeWire = parts.getOrNull(1) ?: "checkers"
                            val opponent = parts.getOrNull(2)?.takeIf { it != "?" }
                            val gameType = runCatching { GameType.fromWire(gameTypeWire) }.getOrNull()
                                ?: GameType.CHECKERS
                            PigeonCard(
                                modifier = Modifier.padding(vertical = 0.dp),
                            ) {
                                Column {
                                    Text(
                                        "${GAME_EMOJI[gameType]} ${GAME_DISPLAY_NAMES[gameType]}",
                                        fontWeight = FontWeight.Bold,
                                    )
                                    Text(
                                        opponent?.let { "vs $it" } ?: "Code: $gameId",
                                        fontSize = 13.sp,
                                    )
                                    Column(modifier = Modifier.padding(top = 8.dp)) {
                                        SecondaryButton("RESUME") { onOpenRecentGame(gameId) }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
