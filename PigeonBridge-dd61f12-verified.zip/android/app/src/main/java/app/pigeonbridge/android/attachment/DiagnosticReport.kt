package app.pigeonbridge.android.attachment

/**
 * Everything Diagnostic Mode displays/copies, as plain data (no Uri,
 * Bitmap, or other Android framework types) so [DiagnosticReportFormatter]
 * — and by extension this whole report's text output — is unit-testable
 * without an Android runtime. The screen (DiagnosticScreen.kt) is
 * responsible for gathering all of this via AttachmentInspector,
 * StickerDetector, AttachmentQualityClassifier, and the extra ContentResolver
 * probes in AttachmentDiagnostics.kt, then building one of these.
 */
data class DiagnosticReport(
    // URI
    val uriString: String,
    val uriScheme: String?,
    val uriAuthority: String?,
    val uriPath: String?,

    // MIME
    val mimeReported: String?,
    val mimeDetectedFromBytes: String?,
    val fileExtension: String?,

    // File metadata
    val displayName: String?,
    val reportedSizeBytes: Long, // -1 = unavailable
    val lastModifiedMillis: Long?, // null = unavailable

    // Image metadata
    val widthPx: Int, // -1 = unknown
    val heightPx: Int,
    val hasAlpha: Boolean?,
    val exifOrientationRaw: Int?, // raw EXIF tag value where obtainable, null = unknown/not applicable
    val bitDepthDescription: String?, // e.g. "ARGB_8888 (32-bit)"
    val isAnimated: Boolean?, // null = unknown
    val frameCount: Int?, // null = unknown

    // Preview detection (from the EXISTING AttachmentInspector.isLikelyPreview — not recomputed)
    val previewSuspected: Boolean,
    val previewReasons: List<String>,

    // Sticker classification (from the EXISTING StickerDetector)
    val classification: AttachmentClassification,
    val classificationSignals: List<SignalScore>,
    val stickerScore: Int,
    val photoScore: Int,

    // Readability tests
    val uriReadable: Boolean,
    val streamReadable: Boolean,
    val bitmapDecodeSucceeded: Boolean,
    val decodedWidthPx: Int?,
    val decodedHeightPx: Int?,

    // URI permissions
    val readPermissionGranted: Boolean?, // null = couldn't be determined
    val persistablePermissionGranted: Boolean,
    val grantedVia: String,

    // Alternate representations
    val alternateRepresentationSummary: String,

    // Quality
    val quality: QualityClass,
    val qualityReason: String,
)
