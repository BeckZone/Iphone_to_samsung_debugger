package app.pigeonbridge.android.network

import app.pigeonbridge.android.data.CreateGameResponseDto
import app.pigeonbridge.android.data.GamePeekDto
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.serialization.json.Json
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Talks to the PigeonBridge server's REST API (server/src/routes/games.ts).
 * Base URL is configurable so debug builds can point at a local dev server
 * (e.g. 10.0.2.2:3001 from the emulator) while release points at production.
 */
class PigeonBridgeApi(private val baseUrl: String = "https://pigeonbridge.app") {
    private val client = OkHttpClient()
    private val json = Json { ignoreUnknownKeys = true }

    suspend fun createGame(gameType: String, nickname: String): CreateGameResponseDto {
        val bodyJson = kotlinx.serialization.json.buildJsonObject {
            put("gameType", kotlinx.serialization.json.JsonPrimitive(gameType))
            put("nickname", kotlinx.serialization.json.JsonPrimitive(nickname))
        }.toString()
        val req = Request.Builder()
            .url("$baseUrl/api/games")
            .header("X-Client-Platform", "android")
            .post(bodyJson.toRequestBody("application/json".toMediaType()))
            .build()
        val respBody = execute(req)
        return json.decodeFromString(CreateGameResponseDto.serializer(), respBody)
    }

    suspend fun peekGame(gameId: String): GamePeekDto {
        val req = Request.Builder().url("$baseUrl/api/games/$gameId").get().build()
        val respBody = execute(req)
        return json.decodeFromString(GamePeekDto.serializer(), respBody)
    }

    val webSocketUrl: String
        get() = baseUrl.replace("https://", "wss://").replace("http://", "ws://") + "/ws"

    fun joinUrl(gameId: String): String = "$baseUrl/g/$gameId"

    private suspend fun execute(req: Request): String = suspendCancellableCoroutine { cont ->
        val call = client.newCall(req)
        cont.invokeOnCancellation { call.cancel() }
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (cont.isActive) cont.resumeWithException(e)
            }

            override fun onResponse(call: Call, response: okhttp3.Response) {
                response.use {
                    val text = it.body?.string() ?: ""
                    if (!it.isSuccessful) {
                        cont.resumeWithException(IOException("HTTP ${it.code}: $text"))
                    } else if (cont.isActive) {
                        cont.resume(text)
                    }
                }
            }
        })
    }
}
