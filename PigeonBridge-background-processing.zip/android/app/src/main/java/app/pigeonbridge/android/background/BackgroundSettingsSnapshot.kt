package app.pigeonbridge.android.background

import app.pigeonbridge.android.monitoring.MessagingPackages

/**
 * The user's "Background Message Processing" choices at one moment. Plain data so the
 * decision logic below can be tested on the JVM; the Android-backed store that fills it in
 * is [BackgroundSettings].
 *
 * Defaults match what the app did before these switches existed (processing on, stickers on,
 * emoji artwork on), except processed notifications, which are opt-in so nobody gets extra
 * notifications they did not ask for.
 */
data class BackgroundSettingsSnapshot(
    /** Master switch (the same one as "Enable/Disable Monitoring"). When off, nothing is processed. */
    val backgroundProcessing: Boolean = true,
    /** Process image/sticker attachments the messaging notification exposes. */
    val processStickers: Boolean = true,
    /** Post a separate PigeonBridge notification for emoji-only messages. Off by default. */
    val processedNotifications: Boolean = false,
    /** Draw emoji inside PigeonBridge with the bundled Twemoji artwork instead of the system font. */
    val alternateEmojiArtwork: Boolean = true,
)

enum class EventGate { PROCESS, IGNORE_UNRELATED_APP, IGNORE_BACKGROUND_OFF }

/**
 * The first question for every notification: should PigeonBridge look at it at all?
 *
 * Order matters and is tested: an unrelated app is rejected BEFORE anything else, so a
 * notification from, say, a banking app is never inspected or recorded, whatever the switches say.
 */
object MessageEventPolicy {
    fun gate(packageName: String, backgroundProcessingOn: Boolean): EventGate {
        if (!MessagingPackages.isKnownMessagingPackage(packageName)) return EventGate.IGNORE_UNRELATED_APP
        if (!backgroundProcessingOn) return EventGate.IGNORE_BACKGROUND_OFF
        return EventGate.PROCESS
    }
}
