package app.pigeonbridge.android.attachment

import android.net.Uri
import android.util.Log
import app.pigeonbridge.android.BuildConfig

/**
 * Debug-only logging for attachment inspection/classification. Gated behind
 * BuildConfig.DEBUG so nothing here runs — or costs anything — in a release
 * build. Per spec Part 9: logs technical metadata only (URI, MIME, size,
 * dimensions, alpha, decode path); never logs message text or any content
 * beyond the one attachment being inspected.
 */
internal object AttachmentDebugLog {
    private const val TAG = "PigeonBridgeAttachment"

    fun logInspection(uri: Uri, info: AttachmentInfo) {
        if (!BuildConfig.DEBUG) return
        Log.d(
            TAG,
            "inspect() uri=$uri mime=${info.mimeType} name=${info.displayName} " +
                "sizeBytes=${info.reportedSizeBytes} dims=${info.widthPx}x${info.heightPx} " +
                "hasAlpha=${info.hasAlpha} exifRotation=${info.exifRotationDegrees} " +
                "isLikelyPreview=${info.isLikelyPreview} decodeFailed=${info.decodeFailed} " +
                "decodePath=${info.decodePath}",
        )
    }

    fun logClassification(result: ClassificationResult) {
        if (!BuildConfig.DEBUG) return
        Log.d(TAG, "classify() -> ${result.classification} signals=${result.signals}")
    }

    fun logDecode(uri: Uri, success: Boolean, outWidth: Int, outHeight: Int, sampleSize: Int) {
        if (!BuildConfig.DEBUG) return
        Log.d(TAG, "decodeFullQuality() uri=$uri success=$success outDims=${outWidth}x$outHeight inSampleSize=$sampleSize")
    }

    fun logError(where: String, uri: Uri?, t: Throwable) {
        if (!BuildConfig.DEBUG) return
        Log.w(TAG, "$where failed for uri=$uri: ${t.javaClass.simpleName}: ${t.message}")
    }
}
