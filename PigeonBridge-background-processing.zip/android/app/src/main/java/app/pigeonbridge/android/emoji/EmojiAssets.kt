package app.pigeonbridge.android.emoji

import android.content.Context
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap

/**
 * Loads the bundled emoji artwork (the PNG files in the assets/emoji folder; see NOTICE.txt
 * in that folder for their license and attribution) and the index of which images exist.
 *
 * Everything here fails soft: if the index or an image cannot be read, callers get null and
 * the UI simply shows the original text, so an asset problem can never make text vanish.
 */
object EmojiAssets {
    private const val DIR = "emoji"
    private const val CACHE_BYTES = 6 * 1024 * 1024

    private val cache = object : LruCache<String, ImageBitmap>(CACHE_BYTES) {
        override fun sizeOf(key: String, value: ImageBitmap): Int = value.width * value.height * 4
    }

    @Volatile
    private var cachedLookup: EmojiLookup? = null
    private var loadFailed = false // guarded by `this`

    /** The index of available emoji images, or null if it could not be read. */
    fun lookup(context: Context): EmojiLookup? {
        cachedLookup?.let { return it }
        synchronized(this) {
            cachedLookup?.let { return it }
            if (loadFailed) return null
            return try {
                val keys = context.applicationContext.assets
                    .open("$DIR/index.txt")
                    .bufferedReader()
                    .use { it.readLines() }
                EmojiLookup(keys).also { cachedLookup = it }
            } catch (e: Exception) {
                loadFailed = true
                null
            }
        }
    }

    /** The decoded image for [fileKey] (a name from the index), or null if unavailable. */
    fun bitmap(context: Context, fileKey: String): ImageBitmap? {
        cache.get(fileKey)?.let { return it }
        return try {
            val decoded = context.applicationContext.assets
                .open("$DIR/$fileKey.png")
                .use { BitmapFactory.decodeStream(it) }
            decoded?.asImageBitmap()?.also { cache.put(fileKey, it) }
        } catch (e: Exception) {
            null
        }
    }
}
