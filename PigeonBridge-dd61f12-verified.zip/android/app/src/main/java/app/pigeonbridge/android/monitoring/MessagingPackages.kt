package app.pigeonbridge.android.monitoring

/**
 * Known Samsung/Google Messages package names. Kept as an allowlist so the
 * listener only ever inspects notifications from an actual messaging app --
 * never anything else, per spec ("does NOT read unrelated notifications").
 *
 * IMPORTANT: this list is our best knowledge, not a guarantee for any given
 * device -- Samsung Messages' package name can vary by region/carrier
 * variant. Diagnostics -> "Last messaging package detected" shows the exact
 * package this device actually posts notifications from, so the list can be
 * corrected for a specific device/build if needed.
 */
object MessagingPackages {
    val KNOWN = setOf(
        "com.samsung.android.messaging", // Samsung Messages, most devices
        "com.google.android.apps.messaging", // Google Messages (Samsung devices can be configured to use this instead)
    )

    fun isKnownMessagingPackage(packageName: String): Boolean = packageName in KNOWN
}
