package app.pigeonbridge.android.messages

/**
 * One message line shown in PigeonBridge's message-style view.
 *
 * [key] identifies the message for de-duplication (Android re-delivers the same messages
 * inside later notifications for the same conversation). [text] is the original text exactly
 * as the messaging app put it in the notification; nothing here rewrites it.
 */
data class FeedMessage(
    val key: String,
    val packageName: String,
    val sender: String,
    val text: String,
    val timeMillis: Long,
)

/**
 * In-memory list of recent messages for the message-style screen.
 *
 * Privacy by design: this lives only in the app's memory. Nothing is written to disk, logged
 * or uploaded, and it is empty again whenever the app process ends or the user taps Clear.
 *
 * Pure Kotlin (no android.* imports) so it can be unit-tested on the JVM.
 */
class MessageFeed(
    private val maxMessages: Int = 200,
    private val maxRememberedKeys: Int = 2000,
) {
    private val lock = Any()
    private val items = ArrayList<FeedMessage>()
    private val seenKeys = LinkedHashSet<String>()
    private val listeners = ArrayList<() -> Unit>()

    /** Adds messages not seen before. Returns how many were actually new. */
    fun add(incoming: List<FeedMessage>): Int = addAndGetNew(incoming).size

    /** Like [add], but returns the messages that were actually new (in the order given). */
    fun addAndGetNew(incoming: List<FeedMessage>): List<FeedMessage> {
        val fresh = ArrayList<FeedMessage>()
        val toNotify: List<() -> Unit>
        synchronized(lock) {
            for (m in incoming) {
                if (m.text.isBlank()) continue
                if (!seenKeys.add(m.key)) continue
                items.add(m)
                fresh.add(m)
            }
            if (fresh.isEmpty()) return fresh
            // Stable sort: messages with equal timestamps keep the order they arrived in.
            items.sortBy { it.timeMillis }
            while (items.size > maxMessages) items.removeAt(0)
            // Remember keys beyond what is displayed so evicted/cleared messages that Android
            // re-delivers inside a later notification do not come back.
            while (seenKeys.size > maxRememberedKeys) {
                val oldest = seenKeys.iterator()
                oldest.next()
                oldest.remove()
            }
            toNotify = ArrayList(listeners)
        }
        for (l in toNotify) {
            try {
                l()
            } catch (e: Exception) {
                // A broken listener must never break message delivery.
            }
        }
        return fresh
    }

    /** Messages oldest to newest. */
    fun snapshot(): List<FeedMessage> = synchronized(lock) { ArrayList(items) }

    /** Clears what is shown. Already-seen messages stay "seen", so they do not reappear. */
    fun clear() {
        val toNotify: List<() -> Unit>
        synchronized(lock) {
            if (items.isEmpty()) return
            items.clear()
            toNotify = ArrayList(listeners)
        }
        for (l in toNotify) {
            try {
                l()
            } catch (e: Exception) {
            }
        }
    }

    /** Registers a change listener; returns a function that removes it. */
    fun addChangeListener(listener: () -> Unit): () -> Unit {
        synchronized(lock) { listeners.add(listener) }
        return { synchronized(lock) { listeners.remove(listener) } }
    }

    companion object {
        /** The single feed the notification listener writes to and the screen reads from. */
        val shared = MessageFeed()
    }
}
