package app.pigeonbridge.android.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import app.pigeonbridge.android.ui.GameViewModel
import app.pigeonbridge.android.ui.PrimaryButton

@Composable
fun JoinGameScreen(
    viewModel: GameViewModel,
    onJoin: (String) -> Unit,
    onBack: () -> Unit,
) {
    var code by remember { mutableStateOf("") }
    var nickname by remember { mutableStateOf(viewModel.nickname) }
    var error by remember { mutableStateOf<String?>(null) }

    Scaffold(topBar = { TopAppBar(title = { Text("Join Game") }) }) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
            TextField(
                value = code,
                onValueChange = { code = it.uppercase().take(6) },
                placeholder = { Text("Invite code (e.g. 8XK29F)") },
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            )
            TextField(
                value = nickname,
                onValueChange = { nickname = it.take(20) },
                placeholder = { Text("Your nickname") },
                modifier = Modifier.fillMaxWidth().padding(bottom = 20.dp),
            )
            error?.let { Text(it, modifier = Modifier.padding(bottom = 12.dp)) }
            PrimaryButton(
                text = "JOIN GAME",
                enabled = code.length == 6 && nickname.isNotBlank(),
            ) {
                viewModel.peekGame(code) { peek ->
                    if (peek == null) {
                        error = "Game not found or expired."
                    } else if (peek.hasSecondPlayer) {
                        error = "That game already has two players."
                    } else {
                        onJoin(code)
                    }
                }
            }
        }
    }
}
