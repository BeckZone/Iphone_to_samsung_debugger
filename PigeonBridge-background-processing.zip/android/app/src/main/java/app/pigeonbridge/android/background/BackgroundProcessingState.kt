package app.pigeonbridge.android.background

import android.content.Context
import app.pigeonbridge.android.PigeonBridgeApp
import app.pigeonbridge.android.monitoring.MonitoringState

/**
 * Small persisted record of what the background pipeline last did, for the Diagnostics and
 * Background Message Processing screens. Metadata only: no message text is stored here.
 */
object BackgroundProcessingState {
    private const val PREFS = "pigeonbridge_background_state"
    private val prefs get() = PigeonBridgeApp.instance.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun recordEvent(nowMillis: Long) {
        prefs.edit().putLong("last_event", nowMillis).apply()
    }

    fun recordProcessed(nowMillis: Long, emojiCount: Int, renderingMethod: String, surfacedVia: SurfacedVia) {
        prefs.edit()
            .putLong("last_processed", nowMillis)
            .putInt("emoji_count", emojiCount)
            .putString("rendering", renderingMethod)
            .putString("surfaced", surfacedVia.name)
            .apply()
    }

    fun recordSurfaced(via: SurfacedVia) {
        prefs.edit().putString("surfaced", via.name).apply()
    }

    fun lastEventMillis(): Long? = prefs.getLong("last_event", -1).takeIf { it >= 0 }
    fun lastProcessedMillis(): Long? = prefs.getLong("last_processed", -1).takeIf { it >= 0 }
    fun lastEmojiCount(): Int? = if (prefs.contains("emoji_count")) prefs.getInt("emoji_count", 0) else null
    fun lastRenderingMethod(): String? = prefs.getString("rendering", null)
    fun lastSurfacedVia(): SurfacedVia? =
        prefs.getString("surfaced", null)?.let { name -> SurfacedVia.values().firstOrNull { it.name == name } }

    fun clear() {
        prefs.edit().clear().apply()
    }

    fun status(context: Context): ProcessingStatus = ProcessingStatus(
        backgroundProcessingOn = BackgroundSettings.backgroundProcessing,
        notificationAccessGranted = MonitoringState.notificationAccessGranted(context),
        listenerObserved = MonitoringState.listenerServiceActive(),
        lastMessageEventMillis = lastEventMillis(),
        lastProcessedMillis = lastProcessedMillis(),
        lastEmojiCount = lastEmojiCount(),
        lastRenderingMethod = lastRenderingMethod(),
        lastSurfacedVia = lastSurfacedVia(),
    )
}
