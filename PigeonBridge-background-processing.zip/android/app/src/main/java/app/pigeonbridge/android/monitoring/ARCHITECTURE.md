# Background monitoring: what Android actually allows

This is the investigation the rest of this package is built on. Read this
before touching PigeonBridgeNotificationListener.kt or
DefaultSmsRoleHelper.kt — it explains *why* they're built the way they are,
and where the hard ceiling is.

## 1. NotificationListenerService — can it see Samsung Messages notifications?

Yes. Once the user grants Notification Access (a special access grant in
Settings, not a manifest permission), a NotificationListenerService receives
`onNotificationPosted()` for every notification posted by every app on the
device, including Samsung Messages. This part is well documented and
reliable.

## 2. Does the notification expose the actual attachment?

This is the real question, and the honest answer is: **usually no, not the
original file — sometimes a low-resolution preview, and it varies by app
version, so it must be verified empirically per-device.** Here's why:

- Most messaging apps build their "new message with photo" notification
  using `NotificationCompat.BigPictureStyle` or `MessagingStyle`. Both
  typically embed a **Bitmap the app already downscaled/re-encoded for
  notification display** — via `Notification.EXTRA_PICTURE` (a raw
  `Bitmap`, still populated by many apps despite being marked legacy) or
  `Notification.EXTRA_PICTURE_ICON` (an `Icon`, API 23+, which can wrap
  either a Bitmap *or* a `content://` Uri).
- **If** `EXTRA_PICTURE_ICON` wraps a Uri (`Icon.getType() ==
  Icon.TYPE_URI`), that Uri is usually granted only to the system process
  that renders the notification (SystemUI/launcher), not to arbitrary
  third-party listener apps. A `ContentResolver.openInputStream()` call
  from PigeonBridge against that Uri would be expected to throw a
  `SecurityException` in the common case — but this cannot be stated as an
  absolute universal rule for every OEM/app version, so **this code tests
  it directly and reports the real result** rather than assuming either way.
- `NotificationCompat.MessagingStyle.Message.getDataUri()` (API 28+) is a
  real, documented API for messages with attached media, and if Samsung
  Messages populates it, it's the best-case path. Same caveat applies: the
  Uri may or may not actually be openable by us. Tested, not assumed.
- Even in the best case where a Bitmap **is** embedded in the notification,
  it is very likely already a preview/thumbnail the messaging app generated
  for notification display — not guaranteed to be the same file quality
  as what's shown inside the Messages app itself, and almost certainly not
  the original iMessage/GamePigeon-quality asset if any client-side
  recompression happened anywhere in the iPhone -> RCS -> Samsung ->
  notification pipeline.

**Bottom line: there is no version of this feature that can honestly promise
"the original attachment." The listener reports exactly what it received,
and whether a direct read of any discovered Uri actually succeeded, every
time — see AttachmentEvent.attachmentSource and DiagnosticRunner-style
readability fields threaded through to the Diagnostics screen.**

## 3. Default SMS role — does it help?

`RoleManager.ROLE_SMS` gives the holder read/write access to the standard
Android Telephony **SMS and MMS** content providers (`content://sms`,
`content://mms`, including `content://mms/part/{id}` for MMS attachment
binaries). For traditional MMS, this is real, documented, and would
actually work.

**For RCS specifically, this does NOT reliably apply.** RCS on Samsung
devices is typically handled by Samsung's own proprietary RCS stack (or
Google's Jibe/Messages RCS stack, depending on carrier and device
configuration) via IMS, layered on top of — but architecturally separate
from — the classic SMS/MMS Telephony provider. There is no public Android
API that guarantees a default SMS app receives RCS message content or
attachments through the standard provider. Some OEM/carrier
implementations partially mirror RCS messages into the MMS provider for
compatibility; many do not, especially for rich content like stickers.
**This project does not claim RCS support via the SMS role, because there
is no public API that guarantees it exists**, per the explicit instruction
not to overclaim this.

Becoming the default SMS app is also a large behavior change for the user
(it replaces their messaging app for sending texts), and Android requires
a candidate app to implement a working SMS/MMS handler (SMS_DELIVER
receiver, WAP_PUSH_DELIVER receiver, a SENDTO-handling compose activity,
RESPOND_VIA_MESSAGE service) to even be *offered* the role by RoleManager.
**This project implements the role-request button and explanation screen,
and calls the real RoleManager API — but does not implement a full SMS/MMS
client**, since that's a separate, large undertaking on its own and,
per the investigation above, would not solve the RCS/sticker problem even
if built. If RoleManager reports PigeonBridge isn't eligible, the app says
so plainly instead of pretending the button did something.

## 4. What Samsung Messages exposes to third parties, generally

There is no published Samsung SDK or public API for third-party apps to
read RCS message attachments from Samsung Messages. Nothing in this project
relies on undocumented behavior, private APIs, accessibility abuse,
overlays, or root — per the explicit instruction — which is exactly why
the answer to "can we get the real attachment" is "sometimes, empirically,
via whatever the notification happens to expose" rather than "yes."

## Conclusion / what this package actually implements

1. A `NotificationListenerService` that detects Samsung Messages
   notifications (event-driven, no polling), extracts whatever
   Android/Samsung Messages legitimately exposes in the notification's
   extras, and **tests** (not assumes) whether any discovered Uri is
   actually readable.
2. When something readable is found, it's handed to the **existing**
   `AttachmentInspector` / `StickerDetector` / `AttachmentBitmapDecoder`
   pipeline — unmodified, no duplicated logic.
3. When nothing usable is exposed, that fact is recorded and surfaced
   honestly (diagnostics + no false "processed" notification).
4. A RoleManager-based default-SMS-role request flow, opt-in, clearly
   labeled as MMS-only in effect and NOT a solution for RCS.

---

# Addendum: "Background Message Processing" (invisible-as-Android-allows design)

Everything above still holds and is unchanged. This addendum records the second
investigation (event-driven processing, default-SMS eligibility, URI access, emoji,
notification replacement) and what was built from it.

## A. Capability matrix

| Wish | Possible with public APIs? | What PigeonBridge does |
|---|---|---|
| Run without the app open | **Yes** | The system binds `PigeonBridgeNotificationListener` and calls `onNotificationPosted` for each notification once the user grants Notification access. No foreground service, no polling. |
| Read message text/emoji of a Samsung/Google Messages notification | **Yes** (what the notification carries) | `NotificationMessageReader` reads `MessagingStyle` messages, falling back to title/text extras. Group summaries are skipped. |
| Read a picture/sticker | **Sometimes** | Tried in order: `MessagingStyle.Message.dataUri`, `EXTRA_PICTURE_ICON` URI, embedded bitmap. Each is actually opened, not assumed; the outcome is recorded. |
| Change how Samsung/Google Messages draw emoji or messages | **No** | Another app cannot restyle or inject into those apps without root, accessibility abuse, overlays or patching their APK. None is used. |
| Replace the system emoji font | **No** | Needs root/OEM privileges. Not attempted. |
| Hide or replace Messages' own notification | **Technically possible via `cancelNotification`, deliberately NOT done** | It would hide real messages from the user and break reply/mark-read actions. The code never cancels another app's notification. |
| Show a processed result without opening the app | **Yes, as PigeonBridge's own notification** | Optional, off by default, silent, titled "PigeonBridge: ...", emoji-only messages, de-duplicated and rate-limited. |
| Show emoji with different artwork | **Only inside PigeonBridge** | `EmojiText` draws Twemoji (CC-BY 4.0) images over the original Unicode, which is never changed. |

## B. Default SMS role (ROLE_SMS)

`RoleManager.createRequestRoleIntent(ROLE_SMS)` only offers apps that qualify. To qualify, an
app must declare and really implement:

- a receiver for `SMS_DELIVER` (permission `BROADCAST_SMS`) and `WAP_PUSH_DELIVER` (`BROADCAST_WAP_PUSH`, MMS);
- an activity handling `SENDTO` with `sms:`/`smsto:`/`mms:`/`mmsto:` (compose);
- a service handling `RESPOND_VIA_MESSAGE` (`SEND_RESPOND_VIA_MESSAGE`);
- and in practice the SMS/MMS permissions, a conversation database, MMS download/send, delivery reports, notifications, and group/dual-SIM handling.

PigeonBridge has none of that, and faking those declarations to appear eligible would be
dishonest and would break the user's texting. So it does **not** qualify and does not claim to.

Would it unlock anything? Only SMS/MMS: it would receive them directly through
`Telephony.Sms/Mms` rather than via notifications. It would **not** cover RCS chats (Samsung's
and Google's RCS stacks are not exposed to third-party default-SMS apps), would **not** let
PigeonBridge change Samsung Messages, and would make PigeonBridge responsible for the user's
entire texting. The only way to control how messages are rendered is to be the app that
renders them, i.e. a real messaging client. That is a separate, large product, not an extension of this one.

## C. ContentProvider / URI access

A notification can carry a `content://` URI (message `dataUri`, picture icon). Android grants
the listener access only if the sender attached a URI permission grant to the notification.
PigeonBridge therefore calls `ContentResolver.openInputStream` for real and records the result:
success, `SecurityException` (the messaging app did not grant access), or null stream. These are
translated to plain sentences by `FailureExplainer`. PigeonBridge never asks the user for broad
storage permission to work around a refused URI; a refusal is reported, not bypassed.

## D. Why no WorkManager and no foreground service

Everything done per event is a few milliseconds: read text, check a set, optionally decode a small
bitmap, optionally post one notification. Nothing needs to be guaranteed to run later, so WorkManager
would add scheduling for no benefit, and a foreground service would add a permanent notification
and battery cost. Revisit only if real-device data shows decoding large attachments is too slow for
the main thread (`onNotificationPosted` runs on the main thread); then move decoding off-thread.

## E. Emoji

`EmojiSegmenter` (pure Kotlin, JVM-tested against the real asset index) finds emoji incl. skin tones,
ZWJ sequences, flags, tag flags and keycaps, and reports ranges of the original string only. Artwork
is Twemoji 15.0, not Apple's. Look-alike limit: it is "iPhone-like" in being a colorful emoji set,
not identical. Applies only inside PigeonBridge (chat view, game screens, the optional notification).

## F. Manifest audit (nothing added by this change)

| Declaration | Why it is needed |
|---|---|
| `INTERNET` | Talk to the PigeonBridge game server. |
| `ACCESS_NETWORK_STATE` | Detect connectivity for the game connection. |
| `POST_NOTIFICATIONS` | Show the existing result notification and the optional processed-emoji notification (runtime-requested on API 33+ from the new screen). |
| `NotificationListenerService` (system-held `BIND_NOTIFICATION_LISTENER_SERVICE`) | Core feature. The user grants Notification access in system Settings. |
| `FileProvider` (not exported) | Hands a notification-embedded bitmap to the Uri-based attachment pipeline from private cache. |
| Activity intent filters | Game invite links and "Share image to PigeonBridge". |

Not requested: SMS, contacts, call log, location, storage, accessibility, overlay, install-packages,
foreground service, boot-completed. Note: `allowBackup="true"` (pre-existing, unchanged) means app
preferences, which hold diagnostic metadata, can be included in device backups; consider setting it
to false if that is a concern.
