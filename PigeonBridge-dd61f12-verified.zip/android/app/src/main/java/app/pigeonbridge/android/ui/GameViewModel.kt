package app.pigeonbridge.android.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.pigeonbridge.android.PigeonBridgeApp
import app.pigeonbridge.android.data.CreateGameResponseDto
import app.pigeonbridge.android.data.GamePeekDto
import app.pigeonbridge.android.network.GameConnectionState
import app.pigeonbridge.android.network.GameSocket
import app.pigeonbridge.android.network.PigeonBridgeApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive

private const val NICKNAME_KEY = "nickname"
private const val SERVER_URL_KEY = "server_base_url"
private const val DEFAULT_SERVER_URL = "https://pigeonbridge.app"

/**
 * Single ViewModel shared across the Create/Invite/Game screens (scoped to
 * the NavHost's parent, see PigeonBridgeNavHost) so the socket connection
 * survives navigation between "waiting for opponent" and the actual game
 * screen, matching how a real GamePigeon-style flow shouldn't reconnect
 * mid-invite.
 */
class GameViewModel : ViewModel() {
    private val prefs get() = PigeonBridgeApp.instance.prefs()

    private val baseUrl: String
        get() = prefs.getString(SERVER_URL_KEY, DEFAULT_SERVER_URL) ?: DEFAULT_SERVER_URL

    private val api get() = PigeonBridgeApi(baseUrl)
    private var socket: GameSocket? = null

    var nickname: String
        get() = prefs.getString(NICKNAME_KEY, "") ?: ""
        set(value) {
            prefs.edit().putString(NICKNAME_KEY, value).apply()
        }

    private val _connection = MutableStateFlow<GameConnectionState>(GameConnectionState.Connecting)
    val connection: StateFlow<GameConnectionState> = _connection.asStateFlow()

    private val _session = MutableStateFlow<JsonObject?>(null)
    val session: StateFlow<JsonObject?> = _session.asStateFlow()

    private val _createResult = MutableStateFlow<CreateGameResponseDto?>(null)
    val createResult: StateFlow<CreateGameResponseDto?> = _createResult.asStateFlow()

    private val _peekResult = MutableStateFlow<GamePeekDto?>(null)
    val peekResult: StateFlow<GamePeekDto?> = _peekResult.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    fun mySlot(): String? = (_session.value?.get("yourSlot"))?.jsonPrimitive?.content

    /** Recent games list, most recent first — persisted as "gameId|gameType|opponent|timestamp" entries. */
    fun recentGames(): List<String> = prefs.getStringSet("recent_games", emptySet())
        ?.sortedByDescending { it.substringAfterLast("|").toLongOrNull() ?: 0L }
        ?: emptyList()

    private fun recordRecentGame(gameId: String, gameType: String, opponent: String?) {
        val existing = prefs.getStringSet("recent_games", emptySet())?.toMutableSet() ?: mutableSetOf()
        existing.removeAll { it.startsWith("$gameId|") }
        existing.add("$gameId|$gameType|${opponent ?: "?"}|${System.currentTimeMillis()}")
        prefs.edit().putStringSet("recent_games", existing).apply()
    }

    fun createGame(gameType: String, nickname: String, onDone: (CreateGameResponseDto?) -> Unit) {
        this.nickname = nickname
        viewModelScope.launch {
            try {
                val result = api.createGame(gameType, nickname)
                _createResult.value = result
                recordRecentGame(result.gameId, gameType, null)
                onDone(result)
            } catch (e: Exception) {
                _errorMessage.value = e.message ?: "Couldn't create game"
                onDone(null)
            }
        }
    }

    fun peekGame(gameId: String, onDone: (GamePeekDto?) -> Unit) {
        viewModelScope.launch {
            try {
                val result = api.peekGame(gameId)
                _peekResult.value = result
                onDone(result)
            } catch (e: Exception) {
                _errorMessage.value = e.message ?: "Game not found or expired"
                onDone(null)
            }
        }
    }

    fun connectAndJoin(gameId: String, nickname: String) {
        this.nickname = nickname
        socket?.close()
        _connection.value = GameConnectionState.Connecting
        socket = GameSocket(api.webSocketUrl) { event ->
            when (event) {
                is GameConnectionState.Joined -> {
                    _session.value = event.session
                    recordRecentGame(
                        gameId,
                        event.session["gameType"]?.jsonPrimitive?.content ?: "checkers",
                        opponentNickname(event.session),
                    )
                }
                is GameConnectionState.StateUpdate -> _session.value = event.session
                is GameConnectionState.GameOver -> _session.value = event.session
                is GameConnectionState.Error -> _errorMessage.value = event.message
                else -> {}
            }
            _connection.value = event
        }
        socket?.connect()
        // GameSocket has no separate onOpen hook wired to auto-join; OkHttp
        // buffers sends made immediately after newWebSocket() until the
        // handshake completes, so sending join() right away is safe.
        socket?.join(gameId, nickname)
    }

    private fun opponentNickname(session: JsonObject): String? {
        val mySlot = session["yourSlot"]?.jsonPrimitive?.content
        val otherKey = if (mySlot == "player1") "player2" else "player1"
        val other = session[otherKey] as? JsonObject ?: return null
        return other["nickname"]?.jsonPrimitive?.content
    }

    fun makeMove(gameId: String, move: JsonElement) {
        socket?.makeMove(gameId, move)
    }

    fun requestRematch(gameId: String) {
        socket?.requestRematch(gameId)
    }

    fun leave(gameId: String) {
        socket?.leave(gameId)
    }

    fun playUrl(gameId: String, nickname: String): String {
        val encodedNick = java.net.URLEncoder.encode(nickname, "UTF-8")
        return "$baseUrl/play?gameId=$gameId&nickname=$encodedNick"
    }

    fun clearError() {
        _errorMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        socket?.close()
    }
}
