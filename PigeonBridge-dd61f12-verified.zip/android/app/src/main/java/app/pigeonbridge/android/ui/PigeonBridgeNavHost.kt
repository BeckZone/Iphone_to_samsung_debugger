package app.pigeonbridge.android.ui

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import app.pigeonbridge.android.ui.screens.CreateGameScreen
import app.pigeonbridge.android.ui.screens.DiagnosticScreen
import app.pigeonbridge.android.ui.screens.GameScreen
import app.pigeonbridge.android.ui.screens.HomeScreen
import app.pigeonbridge.android.ui.screens.InviteScreen
import app.pigeonbridge.android.ui.screens.JoinGameScreen
import app.pigeonbridge.android.ui.screens.MonitoringScreen
import app.pigeonbridge.android.ui.screens.NotificationTestScreen
import app.pigeonbridge.android.ui.screens.SettingsScreen
import app.pigeonbridge.android.ui.screens.ShareReceiverScreen

/**
 * Screens map onto the ones enumerated in the spec:
 * Home, Create Game, Join Game, Invite, Game, Settings.
 * The ViewModel is created once here and reused by Invite + Game so the
 * WebSocket connection persists across that transition.
 */
@Composable
fun PigeonBridgeNavHost(navController: NavHostController) {
    val gameViewModel: GameViewModel = viewModel()

    NavHost(navController = navController, startDestination = "home") {
        composable("home") {
            HomeScreen(
                viewModel = gameViewModel,
                onCreateGame = { navController.navigate("create") },
                onJoinGame = { navController.navigate("join") },
                onOpenRecentGame = { gameId -> navController.navigate("game/$gameId") },
                onOpenSettings = { navController.navigate("settings") },
            )
        }
        composable("create") {
            CreateGameScreen(
                viewModel = gameViewModel,
                onGameCreated = { gameId -> navController.navigate("invite/$gameId") { popUpTo("home") } },
                onBack = { navController.popBackStack() },
            )
        }
        composable("join") {
            JoinGameScreen(
                viewModel = gameViewModel,
                onJoin = { gameId -> navController.navigate("game/$gameId") { popUpTo("home") } },
                onBack = { navController.popBackStack() },
            )
        }
        composable(
            route = "invite/{gameId}",
            arguments = listOf(navArgument("gameId") { type = NavType.StringType }),
        ) { backStackEntry ->
            val gameId = backStackEntry.arguments?.getString("gameId").orEmpty()
            InviteScreen(
                gameId = gameId,
                viewModel = gameViewModel,
                onPlay = { navController.navigate("game/$gameId") { popUpTo("home") } },
                onBackToHome = { navController.popBackStack("home", inclusive = false) },
            )
        }
        composable(
            route = "game/{gameId}",
            arguments = listOf(navArgument("gameId") { type = NavType.StringType }),
        ) { backStackEntry ->
            val gameId = backStackEntry.arguments?.getString("gameId").orEmpty()
            GameScreen(
                gameId = gameId,
                viewModel = gameViewModel,
                onLeave = { navController.popBackStack("home", inclusive = false) },
            )
        }
        composable("settings") {
            SettingsScreen(
                viewModel = gameViewModel,
                onBack = { navController.popBackStack() },
                onOpenMonitoring = { navController.navigate("monitoring") },
            )
        }
        composable("monitoring") {
            MonitoringScreen(
                onBack = { navController.popBackStack() },
                onOpenNotificationTest = if (app.pigeonbridge.android.BuildConfig.DEBUG) {
                    { navController.navigate("notification-test") }
                } else null,
            )
        }
        composable("notification-test") {
            NotificationTestScreen(onBack = { navController.popBackStack() })
        }
        composable(
            route = "share-receiver/{imageUri}",
            arguments = listOf(navArgument("imageUri") { type = NavType.StringType }),
        ) { backStackEntry ->
            val imageUri = backStackEntry.arguments?.getString("imageUri").orEmpty()
            ShareReceiverScreen(
                imageUri = Uri.decode(imageUri),
                onCreateGame = { navController.navigate("create") },
                onBackToHome = { navController.popBackStack("home", inclusive = false) },
                onOpenDiagnostics = { navController.navigate("diagnostics/$imageUri") },
            )
        }
        composable(
            // debug-only screen (see DiagnosticScreen.kt); only ever reached from
            // ShareReceiverScreen's debug-gated "View Diagnostics" link
            route = "diagnostics/{imageUri}",
            arguments = listOf(navArgument("imageUri") { type = NavType.StringType }),
        ) { backStackEntry ->
            val imageUri = backStackEntry.arguments?.getString("imageUri").orEmpty()
            DiagnosticScreen(
                imageUri = Uri.decode(imageUri),
                onBack = { navController.popBackStack() },
            )
        }
    }
}
