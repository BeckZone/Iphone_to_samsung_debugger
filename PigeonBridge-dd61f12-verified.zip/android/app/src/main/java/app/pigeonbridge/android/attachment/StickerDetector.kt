package app.pigeonbridge.android.attachment

/**
 * One scoring signal's contribution, exposed for Diagnostic Mode
 * (see DiagnosticScreen / AttachmentDiagnostics). Not used by normal
 * classification — [StickerDetector.classify] never reads this class.
 */
data class SignalScore(
    val name: String,
    val stickerPoints: Int,
    val photoPoints: Int,
    val detail: String,
)

/** Full scoring breakdown for Diagnostic Mode — same computation as [StickerDetector.classify], just exposing the intermediate signals. */
data class DetailedClassification(
    val classification: AttachmentClassification,
    val stickerScore: Int,
    val photoScore: Int,
    val signals: List<SignalScore>,
)

/**
 * Heuristic classifier: does this attachment look like a sticker, a normal
 * photo, or is there not enough signal to say? Pure function of
 * [AttachmentInfo] — no Context, no Bitmap, no I/O — so this can be
 * unit-tested directly (see app/src/test/.../StickerDetectorTest.kt)
 * without an Android runtime.
 *
 * Deliberately conservative: per spec, "do NOT assume every transparent
 * image is a sticker" — a large transparent PNG (e.g. a diagram or a
 * screenshot with a transparent background) should NOT be classified as a
 * sticker just because it has alpha. Classification requires *multiple*
 * corroborating signals, not any single one.
 *
 * [classify] (the original, unchanged public entry point) and
 * [classifyDetailed] (added for Diagnostic Mode) both call the same private
 * [evaluate] so there is exactly one implementation of the scoring rules —
 * classify()'s behavior is unchanged, byte-for-byte, by this refactor.
 */
object StickerDetector {

    /** Stickers are typically small — well under a normal photo's resolution on either axis. */
    private const val STICKER_MAX_DIMENSION = 768

    /** Below this, an image is almost certainly a sticker/emoji-scale asset regardless of other signals. */
    private const val STICKER_TINY_DIMENSION = 300

    fun classify(info: AttachmentInfo): ClassificationResult {
        val detailed = evaluate(info)
        val result = ClassificationResult(detailed.classification, detailed.signals.map { it.detail })
        AttachmentDebugLog.logClassification(result)
        return result
    }

    /** Same classification as [classify], plus the per-signal score breakdown, for Diagnostic Mode. */
    fun classifyDetailed(info: AttachmentInfo): DetailedClassification {
        val detailed = evaluate(info)
        AttachmentDebugLog.logClassification(ClassificationResult(detailed.classification, detailed.signals.map { it.detail }))
        return detailed
    }

    private fun evaluate(info: AttachmentInfo): DetailedClassification {
        if (info.decodeFailed) {
            return DetailedClassification(
                classification = AttachmentClassification.UNKNOWN,
                stickerScore = 0,
                photoScore = 0,
                signals = listOf(SignalScore("decode", 0, 0, "decode failed — corrupt or unsupported attachment")),
            )
        }

        val signals = mutableListOf<SignalScore>()

        // Signal: alpha transparency. Common for stickers, essentially never present in a camera photo.
        when (info.hasAlpha) {
            true -> signals += SignalScore("alpha", 1, 0, "has alpha channel (+1 sticker)")
            false -> signals += SignalScore("alpha", 0, 1, "no alpha channel (+1 photo)")
            null -> signals += SignalScore("alpha", 0, 0, "alpha undetermined")
        }

        // Signal: MIME type. Stickers are essentially always PNG/WebP/GIF (formats with alpha/animation support);
        // JPEG has neither, so a JPEG is strong evidence against "sticker" regardless of dimensions.
        when (info.mimeType) {
            "image/png", "image/webp", "image/gif" ->
                signals += SignalScore("mime", 1, 0, "sticker-typical MIME ${info.mimeType} (+1 sticker)")
            "image/jpeg" ->
                signals += SignalScore("mime", 0, 2, "JPEG has no transparency/animation support (+2 photo)")
            else ->
                signals += SignalScore("mime", 0, 0, "MIME ${info.mimeType} not decisive")
        }

        // Signal: dimensions. Stickers are small; the smaller, the more confident.
        val maxDim = maxOf(info.widthPx, info.heightPx)
        when {
            info.widthPx in 1..STICKER_TINY_DIMENSION && info.heightPx in 1..STICKER_TINY_DIMENSION ->
                signals += SignalScore("dimension", 2, 0, "tiny dimensions ${info.widthPx}x${info.heightPx} (+2 sticker)")
            maxDim in 1..STICKER_MAX_DIMENSION ->
                signals += SignalScore("dimension", 1, 0, "small dimensions ${info.widthPx}x${info.heightPx} (+1 sticker)")
            maxDim > STICKER_MAX_DIMENSION ->
                signals += SignalScore("dimension", 0, 2, "large dimensions ${info.widthPx}x${info.heightPx}, larger than a typical sticker (+2 photo)")
            else ->
                signals += SignalScore("dimension", 0, 0, "dimensions unknown")
        }

        // Signal: unusual (non-photo-like) aspect ratio — a sticker's canvas is
        // often square-ish or has an odd crop; a camera photo is close to a
        // standard 4:3 / 3:2 / 16:9 ratio. Only counted when dimensions are
        // already sticker-scale, so this doesn't misfire on a panorama photo.
        if (maxDim in 1..STICKER_MAX_DIMENSION && info.widthPx > 0 && info.heightPx > 0) {
            val ratio = info.widthPx.toDouble() / info.heightPx.toDouble()
            val looksLikeStandardPhotoRatio = ratio in 0.6..0.85 || ratio in 1.2..1.8
            if (!looksLikeStandardPhotoRatio) {
                signals += SignalScore("aspect_ratio", 1, 0, "non-photo-like aspect ratio %.2f (+1 sticker)".format(java.util.Locale.US, ratio))
            } else {
                signals += SignalScore("aspect_ratio", 0, 0, "standard photo-like aspect ratio %.2f".format(java.util.Locale.US, ratio))
            }
        } else {
            signals += SignalScore("aspect_ratio", 0, 0, "not evaluated (dimensions not sticker-scale or unknown)")
        }

        // Signal: filename hints, when present.
        val name = info.displayName?.lowercase().orEmpty()
        if (name.contains("sticker")) {
            signals += SignalScore("filename", 1, 0, "filename mentions 'sticker' (+1 sticker)")
        } else {
            signals += SignalScore("filename", 0, 0, "no filename hint")
        }

        val stickerScore = signals.sumOf { it.stickerPoints }
        val photoScore = signals.sumOf { it.photoPoints }
        val classification = when {
            stickerScore >= 3 && stickerScore > photoScore -> AttachmentClassification.LIKELY_STICKER
            photoScore > stickerScore -> AttachmentClassification.NORMAL_IMAGE
            else -> AttachmentClassification.UNKNOWN
        }

        return DetailedClassification(classification, stickerScore, photoScore, signals)
    }
}
