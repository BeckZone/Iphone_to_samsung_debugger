package app.pigeonbridge.android.network

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.int
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.WebSocket
import okhttp3.WebSocketListener

sealed class GameConnectionState {
    object Connecting : GameConnectionState()
    data class Joined(val session: JsonObject) : GameConnectionState()
    data class StateUpdate(val session: JsonObject) : GameConnectionState()
    data class GameOver(val session: JsonObject) : GameConnectionState()
    object OpponentLeft : GameConnectionState()
    data class OpponentDisconnected(val graceMs: Int) : GameConnectionState()
    object OpponentReconnected : GameConnectionState()
    data class RematchOffered(val bySlot: String) : GameConnectionState()
    data class Error(val code: String, val message: String) : GameConnectionState()
    object Closed : GameConnectionState()
}

/**
 * Thin wrapper around a raw OkHttp WebSocket implementing the client<->server
 * contract from shared/src/ws-messages.ts. Board state is left as a raw
 * JsonObject/JsonElement here (rather than a fixed Kotlin data class) since
 * its shape differs per game type — GameViewModel decodes it per-game the
 * same way web/src/play.ts does.
 */
class GameSocket(
    private val serverUrl: String,
    private val onEvent: (GameConnectionState) -> Unit,
) {
    private val client = OkHttpClient()
    private var socket: WebSocket? = null
    private val json = Json { ignoreUnknownKeys = true }

    fun connect() {
        val req = Request.Builder().url(serverUrl).build()
        socket = client.newWebSocket(req, object : WebSocketListener() {
            override fun onMessage(webSocket: WebSocket, text: String) {
                handleServerMessage(text)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: okhttp3.Response?) {
                onEvent(GameConnectionState.Error("socket_failure", t.message ?: "Connection failed"))
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                onEvent(GameConnectionState.Closed)
            }
        })
    }

    private fun handleServerMessage(text: String) {
        val obj = json.parseToJsonElement(text).jsonObject
        when (obj["type"]?.jsonPrimitive?.content) {
            "joined" -> onEvent(GameConnectionState.Joined(obj["session"]!!.jsonObject))
            "state_update", "opponent_joined", "rematch_started" ->
                onEvent(GameConnectionState.StateUpdate(obj["session"]!!.jsonObject))
            "game_over" -> onEvent(GameConnectionState.GameOver(obj["session"]!!.jsonObject))
            "opponent_left" -> onEvent(GameConnectionState.OpponentLeft)
            "opponent_disconnected" ->
                onEvent(GameConnectionState.OpponentDisconnected(obj["graceMs"]?.jsonPrimitive?.int ?: 0))
            "opponent_reconnected" -> onEvent(GameConnectionState.OpponentReconnected)
            "rematch_offered" -> onEvent(GameConnectionState.RematchOffered(obj["bySlot"]!!.jsonPrimitive.content))
            "error" -> onEvent(
                GameConnectionState.Error(
                    obj["code"]?.jsonPrimitive?.content ?: "unknown",
                    obj["message"]?.jsonPrimitive?.content ?: "Unknown error",
                )
            )
            "pong" -> { /* no-op, used only to keep the socket alive */ }
        }
    }

    fun join(gameId: String, nickname: String) {
        send(buildJsonObject {
            put("type", JsonPrimitive("join"))
            put("gameId", JsonPrimitive(gameId))
            put("nickname", JsonPrimitive(nickname))
            put("platform", JsonPrimitive("android"))
        })
    }

    fun makeMove(gameId: String, move: JsonElement) {
        send(buildJsonObject {
            put("type", JsonPrimitive("make_move"))
            put("gameId", JsonPrimitive(gameId))
            put("move", move)
        })
    }

    fun requestRematch(gameId: String) {
        send(buildJsonObject {
            put("type", JsonPrimitive("request_rematch"))
            put("gameId", JsonPrimitive(gameId))
        })
    }

    fun leave(gameId: String) {
        send(buildJsonObject {
            put("type", JsonPrimitive("leave"))
            put("gameId", JsonPrimitive(gameId))
        })
    }

    fun ping() {
        send(buildJsonObject { put("type", JsonPrimitive("ping")) })
    }

    private fun send(obj: JsonObject) {
        socket?.send(obj.toString())
    }

    fun close() {
        socket?.close(1000, "leaving")
    }
}
