import { PlayerSlot } from "../models";

// 8x8 board, standard checkers. player1 = "red", moves "up" (toward row 0).
// player2 = "black", moves "down" (toward row 7). Row 0 = top.
// Cell values: 0 empty, 1 red man, 2 red king, 3 black man, 4 black king.
export type CheckersCell = 0 | 1 | 2 | 3 | 4;
export type CheckersBoard = CheckersCell[][]; // [row][col], 8x8

export interface CheckersMove {
  fromRow: number;
  fromCol: number;
  toRow: number;
  toCol: number;
}

export function createInitialCheckersBoard(): CheckersBoard {
  const board: CheckersBoard = Array.from({ length: 8 }, () => Array<CheckersCell>(8).fill(0));
  for (let row = 0; row < 3; row++) {
    for (let col = 0; col < 8; col++) {
      if ((row + col) % 2 === 1) board[row][col] = 3; // black men, top
    }
  }
  for (let row = 5; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      if ((row + col) % 2 === 1) board[row][col] = 1; // red men, bottom
    }
  }
  return board;
}

function isRed(cell: CheckersCell) {
  return cell === 1 || cell === 2;
}
function isBlack(cell: CheckersCell) {
  return cell === 3 || cell === 4;
}
function isKing(cell: CheckersCell) {
  return cell === 2 || cell === 4;
}
function inBounds(r: number, c: number) {
  return r >= 0 && r < 8 && c >= 0 && c < 8;
}

/** All legal moves for a slot. If any capture exists for that slot, only captures are legal (forced capture rule). */
export function legalMovesFor(board: CheckersBoard, slot: PlayerSlot): CheckersMove[] {
  const mine = slot === "player1" ? isRed : isBlack;
  const simple: CheckersMove[] = [];
  const captures: CheckersMove[] = [];

  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const cell = board[r][c];
      if (!mine(cell)) continue;
      const king = isKing(cell);
      const dirs: [number, number][] = king
        ? [
            [-1, -1],
            [-1, 1],
            [1, -1],
            [1, 1],
          ]
        : slot === "player1"
        ? [
            [-1, -1],
            [-1, 1],
          ] // red moves up (decreasing row)
        : [
            [1, -1],
            [1, 1],
          ]; // black moves down (increasing row)

      for (const [dr, dc] of dirs) {
        const nr = r + dr,
          nc = c + dc;
        if (inBounds(nr, nc) && board[nr][nc] === 0) {
          simple.push({ fromRow: r, fromCol: c, toRow: nr, toCol: nc });
        }
        const jr = r + dr * 2,
          jc = c + dc * 2;
        if (inBounds(jr, jc) && board[jr][jc] === 0 && inBounds(nr, nc)) {
          const mid = board[nr][nc];
          const midIsOpponent = slot === "player1" ? isBlack(mid) : isRed(mid);
          if (midIsOpponent) {
            captures.push({ fromRow: r, fromCol: c, toRow: jr, toCol: jc });
          }
        }
      }
    }
  }
  return captures.length > 0 ? captures : simple;
}

export interface ApplyResult {
  board: CheckersBoard;
  didCapture: boolean;
  mustContinueFrom: { row: number; col: number } | null; // multi-jump in progress
}

/** Validates and applies a single move. Throws on illegal move. */
export function applyCheckersMove(board: CheckersBoard, slot: PlayerSlot, move: CheckersMove): ApplyResult {
  const legal = legalMovesFor(board, slot);
  const match = legal.find(
    (m) => m.fromRow === move.fromRow && m.fromCol === move.fromCol && m.toRow === move.toRow && m.toCol === move.toCol
  );
  if (!match) throw new Error("Illegal move");

  const next: CheckersBoard = board.map((row) => row.slice()) as CheckersBoard;
  const piece = next[move.fromRow][move.fromCol];
  next[move.fromRow][move.fromCol] = 0;

  const isJump = Math.abs(move.toRow - move.fromRow) === 2;
  let didCapture = false;
  if (isJump) {
    const midRow = (move.fromRow + move.toRow) / 2;
    const midCol = (move.fromCol + move.toCol) / 2;
    next[midRow][midCol] = 0;
    didCapture = true;
  }

  // Promotion
  let finalPiece = piece;
  if (piece === 1 && move.toRow === 0) finalPiece = 2;
  if (piece === 3 && move.toRow === 7) finalPiece = 4;
  next[move.toRow][move.toCol] = finalPiece;

  // Check for continued multi-jump with the same piece
  let mustContinueFrom: { row: number; col: number } | null = null;
  if (didCapture) {
    const further = legalMovesFor(next, slot).filter(
      (m) => m.fromRow === move.toRow && m.fromCol === move.toCol && Math.abs(m.toRow - m.fromRow) === 2
    );
    if (further.length > 0) mustContinueFrom = { row: move.toRow, col: move.toCol };
  }

  return { board: next, didCapture, mustContinueFrom };
}

export function checkersWinner(board: CheckersBoard, nextTurn: PlayerSlot): PlayerSlot | "draw" | null {
  const redLeft = board.some((row) => row.some(isRed));
  const blackLeft = board.some((row) => row.some(isBlack));
  if (!redLeft) return "player2";
  if (!blackLeft) return "player1";
  // If the player to move has no legal moves, they lose.
  if (legalMovesFor(board, nextTurn).length === 0) {
    return nextTurn === "player1" ? "player2" : "player1";
  }
  return null;
}
