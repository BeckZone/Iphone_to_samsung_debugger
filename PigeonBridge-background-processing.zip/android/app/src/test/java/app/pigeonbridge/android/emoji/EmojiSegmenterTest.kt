package app.pigeonbridge.android.emoji

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Plain JVM tests (no Robolectric) for the emoji segmenter. They run against the REAL
 * shipped asset index (src/main/assets/emoji/index.txt), so a pass means the images that
 * actually ship in the APK are reachable, not just that the logic works on a toy table.
 */
class EmojiSegmenterTest {

    private val realLookup: EmojiLookup by lazy {
        // Gradle runs unit tests with the module directory (app/) as the working directory.
        val index = File("src/main/assets/emoji/index.txt")
        assertTrue("asset index missing at ${index.absolutePath}", index.exists())
        EmojiLookup(index.readLines())
    }

    /** Builds a string from code points, so the tests never depend on source-file encoding. */
    private fun s(vararg codePoints: Int): String {
        val sb = StringBuilder()
        for (cp in codePoints) sb.appendCodePoint(cp)
        return sb.toString()
    }

    private fun find(text: String) = EmojiSegmenter.findEmoji(text, realLookup)

    private fun assertSingleFullMatch(text: String, expectedKey: String) {
        val m = find(text)
        assertEquals("match count for key $expectedKey", 1, m.size)
        assertEquals(0, m[0].start)
        assertEquals(text.length, m[0].end)
        assertEquals(expectedKey, m[0].fileKey)
    }

    // ---- normal text is never touched ------------------------------------------------

    @Test
    fun plainTextHasNoMatches() {
        assertEquals(0, find("").size)
        assertEquals(0, find("Hello, world! 123 #hashtag *star* 4:30pm").size)
    }

    @Test
    fun bareDigitsHashAndStarAreNotEmoji() {
        assertEquals(0, find("0123456789#*").size)
    }

    @Test
    fun textDefaultSymbolsStayTextWithoutVariationSelector() {
        // copyright, registered, trade mark, double exclamation, left-right arrow, spade
        for (cp in intArrayOf(0xA9, 0xAE, 0x2122, 0x203C, 0x2194, 0x2660)) {
            assertEquals("U+${cp.toString(16)} must stay text", 0, find(s(cp)).size)
        }
    }

    @Test
    fun textDefaultSymbolBecomesEmojiOnlyWithFe0f() {
        assertSingleFullMatch(s(0xA9, 0xFE0F), "a9")
        assertSingleFullMatch(s(0x2122, 0xFE0F), "2122")
    }

    @Test
    fun explicitTextSelectorForcesText() {
        assertEquals(0, find(s(0x2764, 0xFE0E)).size)
    }

    // ---- single emoji -----------------------------------------------------------------

    @Test
    fun simpleSupplementaryEmoji() {
        assertSingleFullMatch(s(0x1F600), "1f600")
    }

    @Test
    fun heartWithAndWithoutVariationSelectorKeepsOriginalRange() {
        assertSingleFullMatch(s(0x2764, 0xFE0F), "2764")
        // Without FE0F the heart is text-default, so it is left as text.
        assertEquals(0, find(s(0x2764)).size)
    }

    @Test
    fun emojiInsideTextKeepsExactOffsets() {
        val text = "ab" + s(0x1F600) + "cd" + s(0x1F44D)
        val m = find(text)
        assertEquals(2, m.size)
        assertEquals(2, m[0].start)
        assertEquals(4, m[0].end)
        assertEquals(6, m[1].start)
        assertEquals(8, m[1].end)
    }

    // ---- skin tones, gender, ZWJ ------------------------------------------------------

    @Test
    fun skinToneModifierSequence() {
        assertSingleFullMatch(s(0x1F44D, 0x1F3FD), "1f44d-1f3fd")
    }

    @Test
    fun textDefaultBaseWithSkinToneIsEmoji() {
        // U+261D (index pointing up) is text-default but a modifier makes it an emoji.
        assertSingleFullMatch(s(0x261D, 0x1F3FD), "261d-1f3fd")
    }

    @Test
    fun zwjFamily() {
        assertSingleFullMatch(
            s(0x1F468, 0x200D, 0x1F469, 0x200D, 0x1F467, 0x200D, 0x1F466),
            "1f468-200d-1f469-200d-1f467-200d-1f466",
        )
    }

    @Test
    fun zwjProfessionWithSkinTone() {
        assertSingleFullMatch(s(0x1F468, 0x1F3FD, 0x200D, 0x1F4BB), "1f468-1f3fd-200d-1f4bb")
    }

    @Test
    fun genderedSequenceWithAndWithoutOptionalFe0f() {
        val expected = "1f3c3-200d-2640-fe0f"
        assertSingleFullMatch(s(0x1F3C3, 0x200D, 0x2640, 0xFE0F), expected)
        assertSingleFullMatch(s(0x1F3C3, 0x200D, 0x2640), expected)
    }

    @Test
    fun multiRaceHandshakeWithTwoSkinTones() {
        assertSingleFullMatch(
            s(0x1F9D1, 0x1F3FB, 0x200D, 0x1F91D, 0x200D, 0x1F9D1, 0x1F3FF),
            "1f9d1-1f3fb-200d-1f91d-200d-1f9d1-1f3ff",
        )
    }

    @Test
    fun rainbowFlagWithAndWithoutFe0f() {
        val expected = "1f3f3-fe0f-200d-1f308"
        assertSingleFullMatch(s(0x1F3F3, 0xFE0F, 0x200D, 0x1F308), expected)
        assertSingleFullMatch(s(0x1F3F3, 0x200D, 0x1F308), expected)
    }

    @Test
    fun heartOnFireAndEyeInSpeechBubble() {
        assertSingleFullMatch(s(0x2764, 0xFE0F, 0x200D, 0x1F525), "2764-fe0f-200d-1f525")
        assertSingleFullMatch(
            s(0x1F441, 0xFE0F, 0x200D, 0x1F5E8, 0xFE0F),
            "1f441-200d-1f5e8",
        )
    }

    @Test
    fun strayZwjAroundEmojiStaysText() {
        val text = s(0x1F600, 0x200D) + "x"
        val m = find(text)
        assertEquals(1, m.size)
        assertEquals(0, m[0].start)
        assertEquals(2, m[0].end) // the dangling ZWJ is not swallowed
    }

    // ---- flags and keycaps ------------------------------------------------------------

    @Test
    fun regionalIndicatorFlag() {
        assertSingleFullMatch(s(0x1F1FA, 0x1F1F8), "1f1fa-1f1f8")
    }

    @Test
    fun adjacentFlagsPairUpFromTheLeft() {
        val m = find(s(0x1F1FA, 0x1F1F8, 0x1F1EF, 0x1F1F5))
        assertEquals(2, m.size)
        assertEquals("1f1fa-1f1f8", m[0].fileKey)
        assertEquals("1f1ef-1f1f5", m[1].fileKey)
    }

    @Test
    fun englandSubdivisionFlag() {
        assertSingleFullMatch(
            s(0x1F3F4, 0xE0067, 0xE0062, 0xE0065, 0xE006E, 0xE0067, 0xE007F),
            "1f3f4-e0067-e0062-e0065-e006e-e0067-e007f",
        )
    }

    @Test
    fun keycapsWithAndWithoutFe0f() {
        assertSingleFullMatch(s('1'.code, 0xFE0F, 0x20E3), "31-20e3")
        assertSingleFullMatch(s('#'.code, 0xFE0F, 0x20E3), "23-20e3")
        assertSingleFullMatch(s('*'.code, 0x20E3), "2a-20e3")
        // the digit in "10" is plain text even right next to a keycap
        val m = find("10" + s('5'.code, 0xFE0F, 0x20E3))
        assertEquals(1, m.size)
        assertEquals(2, m[0].start)
    }

    // ---- graceful fallback ------------------------------------------------------------

    @Test
    fun emojiWithoutArtworkIsLeftAsTextNotDropped() {
        val tiny = EmojiLookup(listOf("1f600"))
        val text = s(0x1F600, 0x1F601)
        val m = EmojiSegmenter.findEmoji(text, tiny)
        assertEquals(1, m.size) // only the one that has an image
        assertEquals(0, m[0].start)
        assertEquals(2, m[0].end)
    }

    @Test
    fun unsupportedSkinToneFallsBackToBasePlusSwatch() {
        val tiny = EmojiLookup(listOf("1f44d", "1f3fd"))
        val m = EmojiSegmenter.findEmoji(s(0x1F44D, 0x1F3FD), tiny)
        assertEquals(2, m.size)
        assertEquals("1f44d", m[0].fileKey)
        assertEquals("1f3fd", m[1].fileKey)
        assertEquals(2, m[1].start)
    }

    @Test
    fun unsupportedZwjChainBacksOffToLongestKnownPrefix() {
        val tiny = EmojiLookup(listOf("1f468", "1f469", "1f467", "1f468-200d-1f469"))
        val m = EmojiSegmenter.findEmoji(s(0x1F468, 0x200D, 0x1F469, 0x200D, 0x1F467), tiny)
        assertEquals(2, m.size)
        assertEquals("1f468-200d-1f469", m[0].fileKey)
        assertEquals(5, m[0].end) // man (2 UTF-16 units) + ZWJ (1) + woman (2)
        assertEquals("1f467", m[1].fileKey)
        assertEquals(6, m[1].start) // the dangling ZWJ at index 5 is left as text
    }

    @Test
    fun malformedInputNeverThrows() {
        val broken = "\uD83D" + "x" + "\uDE00" + s(0x1F600) + "\uD83D"
        find(broken) // lone surrogates, must not throw
        find(s(0x200D))
        find(s(0xFE0F))
        find(s(0x1F3F4, 0xE0067)) // tag flag with no cancel tag
        find(s(0x1F1FA)) // lone regional indicator
    }

    @Test
    fun matchesAreSortedNonOverlappingAndInsideTheText() {
        val text = "a" + s(0x1F600) + s(0x1F468, 0x200D, 0x1F469) + "b" + s(0x1F1FA, 0x1F1F8) + s('7'.code, 0xFE0F, 0x20E3)
        val m = find(text)
        var cursor = 0
        for (x in m) {
            assertTrue(x.start >= cursor)
            assertTrue(x.end > x.start)
            assertTrue(x.end <= text.length)
            cursor = x.end
        }
        assertTrue(m.size >= 4)
    }

    // ---- jumbo-emoji detection (message-style view) -----------------------------------

    @Test
    fun emojiOnlyDetectsShortEmojiMessages() {
        assertTrue(EmojiSegmenter.isEmojiOnly(s(0x1F600), realLookup))
        assertTrue(EmojiSegmenter.isEmojiOnly(s(0x1F600, 0x20, 0x1F44D, 0x1F3FD), realLookup))
        assertTrue(EmojiSegmenter.isEmojiOnly(s(0x1F468, 0x200D, 0x1F469, 0x200D, 0x1F467), realLookup))
    }

    @Test
    fun emojiOnlyRejectsTextAndLongRuns() {
        assertFalse(EmojiSegmenter.isEmojiOnly("", realLookup))
        assertFalse(EmojiSegmenter.isEmojiOnly("hi " + s(0x1F600), realLookup))
        assertFalse(EmojiSegmenter.isEmojiOnly("42", realLookup))
        assertFalse(EmojiSegmenter.isEmojiOnly(s(0xA9), realLookup)) // plain (c) is text
        // four emoji is over the default limit of three
        assertFalse(EmojiSegmenter.isEmojiOnly(s(0x1F600, 0x1F600, 0x1F600, 0x1F600), realLookup))
        assertTrue(EmojiSegmenter.isEmojiOnly(s(0x1F600, 0x1F600, 0x1F600, 0x1F600), realLookup, maxEmoji = 4))
    }

    // ---- the whole shipped asset set --------------------------------------------------

    @Test
    fun everyShippedImageIsReachableFromARealisticInputString() {
        val keys = File("src/main/assets/emoji/index.txt").readLines().map { it.trim() }.filter { it.isNotEmpty() }
        assertTrue("expected the full Twemoji set", keys.size > 3500)
        val failures = ArrayList<String>()
        for (key in keys) {
            val parts = key.split('-').map { it.toInt(16) }.toMutableList()
            // A keyboard emits text-default single symbols with FE0F; do the same here.
            val isSingle = parts.size == 1
            if (isSingle && !EmojiData.isEmojiPresentation(parts[0])) parts.add(1, 0xFE0F)
            val text = s(*parts.toIntArray())
            val m = find(text)
            val ok = m.size == 1 && m[0].start == 0 && m[0].end == text.length &&
                EmojiLookup.stripVs16(m[0].fileKey) == EmojiLookup.stripVs16(key)
            if (!ok) failures.add("$key -> ${m.map { "${it.start}-${it.end}:${it.fileKey}" }}")
        }
        assertTrue("unreachable images (${failures.size}): ${failures.take(10)}", failures.isEmpty())
    }

    @Test
    fun everyTextDefaultSingleSymbolStaysTextWithoutFe0f() {
        val keys = File("src/main/assets/emoji/index.txt").readLines().map { it.trim() }.filter { it.isNotEmpty() }
        val wronglyReplaced = ArrayList<String>()
        for (key in keys) {
            if ('-' in key) continue
            val cp = key.toInt(16)
            if (EmojiData.isEmojiPresentation(cp)) continue
            if (cp in 0x1F3FB..0x1F3FF) continue // skin-tone swatches are Emoji_Presentation anyway
            if (find(s(cp)).isNotEmpty()) wronglyReplaced.add(key)
        }
        assertTrue("text symbols wrongly replaced: ${wronglyReplaced.take(10)}", wronglyReplaced.isEmpty())
    }

    @Test
    fun lookupIgnoresVariationSelectorsOnBothSides() {
        val l = EmojiLookup(listOf("2764-fe0f-200d-1f525", "2764"))
        assertNotNull(l.fileKeyFor("2764-200d-1f525"))
        assertEquals("2764-fe0f-200d-1f525", l.fileKeyFor("2764-200d-1f525"))
        assertEquals("2764", l.fileKeyFor("2764"))
        assertEquals(2, l.size)
    }

    // ---- emojiOnlyFileKeys: what the processed-notification feature relies on ----
    @Test
    fun emojiOnlyKeysForSingleAndMultiple() {
        assertEquals(listOf("1f44d"), EmojiSegmenter.emojiOnlyFileKeys(s(0x1F44D), realLookup))
        assertEquals(2, EmojiSegmenter.emojiOnlyFileKeys(s(0x1F44D, 0x20, 0x1F602), realLookup)!!.size)
    }

    @Test
    fun emojiOnlyKeysNullForTextOrTooMany() {
        assertEquals(null, EmojiSegmenter.emojiOnlyFileKeys("hi " + s(0x1F44D), realLookup))
        assertEquals(null, EmojiSegmenter.emojiOnlyFileKeys(s(0x1F44D, 0x1F44D, 0x1F44D, 0x1F44D), realLookup))
        assertEquals(null, EmojiSegmenter.emojiOnlyFileKeys("", realLookup))
        assertEquals(null, EmojiSegmenter.emojiOnlyFileKeys("12345", realLookup))
    }
}
