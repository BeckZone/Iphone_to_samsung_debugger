package app.pigeonbridge.android.background

enum class SurfacedVia { NONE, PROCESSED_NOTIFICATION }

/** Everything the status/diagnostics UI needs, as plain data. */
data class ProcessingStatus(
    val backgroundProcessingOn: Boolean,
    val notificationAccessGranted: Boolean,
    val listenerObserved: Boolean,
    val lastMessageEventMillis: Long?,
    val lastProcessedMillis: Long?,
    val lastEmojiCount: Int?,
    val lastRenderingMethod: String?,
    val lastSurfacedVia: SurfacedVia?,
)

/**
 * Turns status data into honest sentences. The rule it exists to enforce: never say or imply the
 * Samsung/Google Messages screen was changed. Android does not allow that, so the wording always
 * says where the result actually appears.
 */
object ProcessingStatusFormatter {
    const val ANDROID_LIMIT_LINE =
        "Processed automatically, but Android does not permit another app to modify the original Messages UI."

    const val SURFACED_INTO_MESSAGES_UI =
        "No. Android does not allow another app to change the Samsung/Google Messages screen. " +
            "Results appear only in PigeonBridge's own notification and chat view."

    fun headline(status: ProcessingStatus): String = when {
        !status.backgroundProcessingOn ->
            "Background processing is OFF. Nothing is being processed."
        !status.notificationAccessGranted ->
            "Notification access is not granted, so Android is not sending PigeonBridge any messages. Turn it on to start."
        !status.listenerObserved ->
            "Notification access is granted, but Android has not connected PigeonBridge's listener yet."
        status.lastMessageEventMillis == null ->
            "Ready. Waiting for the first message from a supported messaging app."
        status.lastProcessedMillis == null ->
            "A message notification arrived, but it had no readable text to process."
        else -> ANDROID_LIMIT_LINE + when (status.lastSurfacedVia) {
            SurfacedVia.PROCESSED_NOTIFICATION -> " The result was shown in a separate PigeonBridge notification."
            else -> " The result is viewable in PigeonBridge's chat view."
        }
    }
}

/** Plain-English versions of the short failure reasons the notification listener records. */
object FailureExplainer {
    fun explain(reason: String?): String? {
        if (reason.isNullOrBlank()) return null
        return when {
            // Checked first: it also appears inside the longer "present but not readable" reasons.
            reason.contains("SecurityException") ->
                "Android refused PigeonBridge permission to open the attachment (the messaging app did not grant access)."
            reason.contains("present but not readable") ->
                "A link to the attachment was in the notification, but Android did not let PigeonBridge read it."
            reason.contains("openInputStream returned null") ->
                "The messaging app's file provider returned nothing for that attachment."
            reason.contains("Bitmap decode failed") ->
                "The attachment was opened, but it is not an image Android could decode."
            reason.contains("AttachmentInspector.inspect threw") ->
                "PigeonBridge could not read the attachment's details."
            reason.contains("could not be cached") ->
                "A preview image was found but could not be saved to PigeonBridge's private cache."
            else -> "Unexpected problem: $reason"
        }
    }
}
