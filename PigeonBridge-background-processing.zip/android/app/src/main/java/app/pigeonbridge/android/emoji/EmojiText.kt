package app.pigeonbridge.android.emoji

import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.text.InlineTextContent
import androidx.compose.foundation.text.appendInlineContent
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.Placeholder
import androidx.compose.ui.text.PlaceholderVerticalAlign
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.em
import app.pigeonbridge.android.background.BackgroundSettings

/**
 * Drop-in replacement for Material3 [Text] that draws emoji with PigeonBridge's bundled
 * emoji artwork instead of the phone's system emoji font. Automatic; can be switched off in Background Message Processing settings.
 *
 * What stays exactly as it was:
 *  - the string. The text handed to Compose still contains the ORIGINAL Unicode characters
 *    (each emoji is an inline image whose alternate text is the original emoji), so
 *    accessibility, text selection/copy, and anything the caller does with [text] keep
 *    working with the real characters. Nothing is converted, normalized or stripped.
 *  - normal text. Strings with no emoji, or with the "alternate emoji artwork" setting off, take the plain `Text` path unchanged.
 *  - failure behaviour. If an image cannot be loaded, the system's own emoji glyph is drawn.
 *
 * Scope: this only affects text drawn by PigeonBridge itself. It cannot change how Samsung
 * Messages, the system keyboard, notifications shown by Android, or any other app draw emoji.
 */
@Composable
fun EmojiText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified,
    fontWeight: FontWeight? = null,
    fontFamily: FontFamily? = null,
    textAlign: TextAlign? = null,
    maxLines: Int = Int.MAX_VALUE,
    overflow: TextOverflow = TextOverflow.Clip,
    style: TextStyle = LocalTextStyle.current,
) {
    val context = LocalContext.current
    val artworkOn = BackgroundSettings.alternateEmojiArtwork
    val rendered = remember(text, artworkOn) { if (artworkOn) EmojiRendering.build(context, text) else null }

    if (rendered == null) {
        Text(
            text = text,
            modifier = modifier,
            color = color,
            fontSize = fontSize,
            fontWeight = fontWeight,
            fontFamily = fontFamily,
            textAlign = textAlign,
            maxLines = maxLines,
            overflow = overflow,
            style = style,
        )
    } else {
        Text(
            text = rendered.annotated,
            modifier = modifier,
            color = color,
            fontSize = fontSize,
            fontWeight = fontWeight,
            fontFamily = fontFamily,
            textAlign = textAlign,
            maxLines = maxLines,
            overflow = overflow,
            inlineContent = rendered.inlineContent,
            style = style,
        )
    }
}

/** Builds the annotated string + inline images for a piece of text; null if it has no emoji. */
internal object EmojiRendering {
    class Result(
        val annotated: AnnotatedString,
        val inlineContent: Map<String, InlineTextContent>,
    )

    fun build(context: Context, text: String): Result? {
        val lookup = EmojiAssets.lookup(context) ?: return null
        val matches = EmojiSegmenter.findEmoji(text, lookup)
        if (matches.isEmpty()) return null

        val inline = LinkedHashMap<String, InlineTextContent>()
        val annotated = buildAnnotatedString {
            var cursor = 0
            for (match in matches) {
                if (match.start > cursor) append(text.substring(cursor, match.start))
                val id = match.fileKey
                // The alternate text IS the original emoji, so the Unicode is preserved.
                appendInlineContent(id, text.substring(match.start, match.end))
                if (!inline.containsKey(id)) {
                    inline[id] = InlineTextContent(
                        Placeholder(
                            width = 1.2.em,
                            height = 1.2.em,
                            placeholderVerticalAlign = PlaceholderVerticalAlign.TextCenter,
                        ),
                    ) { original -> EmojiImage(id, original) }
                }
                cursor = match.end
            }
            if (cursor < text.length) append(text.substring(cursor))
        }
        return Result(annotated, inline)
    }
}

@Composable
private fun EmojiImage(fileKey: String, original: String) {
    val context = LocalContext.current
    val bitmap = remember(fileKey) { EmojiAssets.bitmap(context, fileKey) }
    if (bitmap != null) {
        Image(
            bitmap = bitmap,
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            filterQuality = FilterQuality.High,
        )
    } else {
        // Image missing or undecodable: show the system's own glyph rather than losing the emoji.
        Text(original)
    }
}
