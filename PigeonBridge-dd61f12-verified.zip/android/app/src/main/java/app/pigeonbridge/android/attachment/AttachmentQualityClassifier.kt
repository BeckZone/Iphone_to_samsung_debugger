package app.pigeonbridge.android.attachment

enum class QualityClass {
    FULL_LARGE,
    SMALL,
    UNKNOWN,
}

data class QualityResult(val quality: QualityClass, val reason: String)

/**
 * A deliberately simple, factual quality label based only on the dimensions
 * PigeonBridge actually decoded — never a claim about whether this is "the
 * original" (spec Part 11: "Do not call something 'original' unless we
 * actually know that" — this project has no way to know that, since Android
 * only ever hands us the one Uri the sending app chose to share).
 */
object AttachmentQualityClassifier {

    /** Below this on both axes, "SMALL" — matches a plausible low-res preview/thumbnail scale. */
    private const val SMALL_THRESHOLD = 400

    fun classify(widthPx: Int, heightPx: Int): QualityResult {
        if (widthPx <= 0 || heightPx <= 0) {
            return QualityResult(QualityClass.UNKNOWN, "dimensions could not be determined")
        }
        val maxDim = maxOf(widthPx, heightPx)
        return if (maxDim < SMALL_THRESHOLD) {
            QualityResult(QualityClass.SMALL, "${widthPx} × ${heightPx}")
        } else {
            QualityResult(QualityClass.FULL_LARGE, "${widthPx} × ${heightPx}")
        }
    }
}
