package app.pigeonbridge.android.background

import app.pigeonbridge.android.messages.FeedMessage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ProcessedNotificationPlannerTest {

    private val on = BackgroundSettingsSnapshot(processedNotifications = true)
    private val keys = listOf("1f44d")

    private fun msg(key: String, sender: String = "Sam", text: String = "x") =
        FeedMessage(key, "com.samsung.android.messaging", sender, text, 1L)

    private fun skip(r: PlanResult): SkipReason = (r as PlanResult.Skip).reason

    @Test
    fun postsForEmojiOnlyWhenEnabled() {
        val r = ProcessedNotificationPlanner().plan(msg("a", text = "thumbs"), keys, on, 10_000)
        val plan = (r as PlanResult.Post).plan
        assertEquals("thumbs", plan.text) // original text untouched
        assertEquals(keys, plan.emojiFileKeys)
        assertTrue(plan.title.contains("PigeonBridge")) // never impersonates Messages
    }

    @Test
    fun offByDefault() =
        assertEquals(
            SkipReason.PROCESSED_NOTIFICATIONS_OFF,
            skip(ProcessedNotificationPlanner().plan(msg("a"), keys, BackgroundSettingsSnapshot(), 0)),
        )

    @Test
    fun backgroundOffWins() =
        assertEquals(
            SkipReason.BACKGROUND_PROCESSING_OFF,
            skip(ProcessedNotificationPlanner().plan(msg("a"), keys, on.copy(backgroundProcessing = false), 0)),
        )

    @Test
    fun ordinaryTextIsSkipped() {
        val p = ProcessedNotificationPlanner()
        assertEquals(SkipReason.NOT_EMOJI_ONLY, skip(p.plan(msg("a"), null, on, 0)))
        assertEquals(SkipReason.NOT_EMOJI_ONLY, skip(p.plan(msg("b"), emptyList(), on, 0)))
    }

    @Test
    fun duplicateIsSkipped() {
        val p = ProcessedNotificationPlanner()
        assertTrue(p.plan(msg("a"), keys, on, 0) is PlanResult.Post)
        assertEquals(SkipReason.DUPLICATE, skip(p.plan(msg("a"), keys, on, 100_000)))
    }

    @Test
    fun burstIsRateLimitedThenAllowed() {
        val p = ProcessedNotificationPlanner(minIntervalMillis = 3000)
        assertTrue(p.plan(msg("a"), keys, on, 10_000) is PlanResult.Post)
        assertEquals(SkipReason.RATE_LIMITED, skip(p.plan(msg("b"), keys, on, 11_000)))
        assertTrue(p.plan(msg("c"), keys, on, 13_000) is PlanResult.Post)
    }

    @Test
    fun sameSenderReusesIdSoItReplacesInsteadOfStacking() {
        val p = ProcessedNotificationPlanner(minIntervalMillis = 0)
        val a = (p.plan(msg("a", "Sam"), keys, on, 1) as PlanResult.Post).plan.notificationId
        val b = (p.plan(msg("b", "Sam"), keys, on, 2) as PlanResult.Post).plan.notificationId
        assertEquals(a, b)
        assertTrue(a in 4300..4300 + 63)
    }

    @Test
    fun memoryIsBounded() {
        val p = ProcessedNotificationPlanner(minIntervalMillis = 0, maxRemembered = 5)
        for (i in 0 until 50) p.plan(msg("k$i"), keys, on, i.toLong())
        // Oldest keys were forgotten (bounded), newest are still remembered.
        assertEquals(SkipReason.DUPLICATE, skip(p.plan(msg("k49"), keys, on, 100)))
        assertTrue(p.plan(msg("k0"), keys, on, 101) is PlanResult.Post)
    }
}
