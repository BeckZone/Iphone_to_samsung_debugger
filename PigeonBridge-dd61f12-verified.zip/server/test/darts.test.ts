import { test } from "node:test";
import assert from "node:assert/strict";
import { darts } from "@pigeonbridge/shared";

test("starting score is 501 for both players", () => {
  const board = darts.createInitialDartsBoard();
  assert.equal(board.scores.player1, 501);
  assert.equal(board.scores.player2, 501);
});

test("a normal scoring turn subtracts correctly", () => {
  const board = darts.createInitialDartsBoard();
  const next = darts.applyDartsMove(board, "player1", {
    throws: [
      { segment: 20, multiplier: 3 }, // 60
      { segment: 20, multiplier: 3 }, // 60
      { segment: 20, multiplier: 3 }, // 60
    ],
  });
  assert.equal(next.scores.player1, 501 - 180);
  assert.equal(next.scores.player2, 501); // untouched
});

test("going below zero busts the whole turn", () => {
  const board = darts.createInitialDartsBoard();
  board.scores.player1 = 20;
  const next = darts.applyDartsMove(board, "player1", {
    throws: [{ segment: 20, multiplier: 3 }], // 60 > 20 -> bust
  });
  assert.equal(next.scores.player1, 20, "score reverts on bust");
});

test("landing on exactly 1 is a bust (can't finish on 1)", () => {
  const board = darts.createInitialDartsBoard();
  board.scores.player1 = 21;
  const next = darts.applyDartsMove(board, "player1", {
    throws: [{ segment: 20, multiplier: 1 }], // 21-20=1 -> bust
  });
  assert.equal(next.scores.player1, 21);
});

test("checkout requires a double; single finish busts", () => {
  const board = darts.createInitialDartsBoard();
  board.scores.player1 = 20;
  const bustAttempt = darts.applyDartsMove(board, "player1", {
    throws: [{ segment: 20, multiplier: 1 }], // exact 0 but single, not double -> bust
  });
  assert.equal(bustAttempt.scores.player1, 20);

  const goodCheckout = darts.applyDartsMove(board, "player1", {
    throws: [{ segment: 10, multiplier: 2 }], // double 10 = 20, exact and a double
  });
  assert.equal(goodCheckout.scores.player1, 0);
  assert.equal(darts.dartsWinner(goodCheckout), "player1");
});

test("bullseye (50) counts as a double for checkout purposes", () => {
  const board = darts.createInitialDartsBoard();
  board.scores.player1 = 50;
  const next = darts.applyDartsMove(board, "player1", {
    throws: [{ segment: 25, multiplier: 2 }], // bullseye = 50
  });
  assert.equal(next.scores.player1, 0);
});

test("invalid throw is rejected", () => {
  const board = darts.createInitialDartsBoard();
  assert.throws(() => darts.applyDartsMove(board, "player1", { throws: [{ segment: 25, multiplier: 3 } as any] }));
  assert.throws(() => darts.applyDartsMove(board, "player1", { throws: [{ segment: 21, multiplier: 1 } as any] }));
});
