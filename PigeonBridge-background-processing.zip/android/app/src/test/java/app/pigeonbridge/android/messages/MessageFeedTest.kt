package app.pigeonbridge.android.messages

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Plain JVM tests for the in-memory message store behind the message-style screen. */
class MessageFeedTest {

    private fun msg(key: String, text: String, time: Long, sender: String = "Sam") =
        FeedMessage(key = key, packageName = "com.samsung.android.messaging", sender = sender, text = text, timeMillis = time)

    @Test
    fun addsNewMessagesAndReportsCount() {
        val feed = MessageFeed()
        assertEquals(2, feed.add(listOf(msg("a", "hi", 1), msg("b", "yo", 2))))
        assertEquals(2, feed.snapshot().size)
    }

    @Test
    fun redeliveredMessagesAreNotDuplicated() {
        // Android re-sends earlier messages inside each later notification for a conversation.
        val feed = MessageFeed()
        feed.add(listOf(msg("a", "hi", 1)))
        val added = feed.add(listOf(msg("a", "hi", 1), msg("b", "new", 2)))
        assertEquals(1, added)
        assertEquals(listOf("hi", "new"), feed.snapshot().map { it.text })
    }

    @Test
    fun messagesAreOrderedOldestToNewestAndTiesKeepArrivalOrder() {
        val feed = MessageFeed()
        feed.add(listOf(msg("c", "third", 30), msg("a", "first", 10), msg("b1", "second-a", 20), msg("b2", "second-b", 20)))
        assertEquals(listOf("first", "second-a", "second-b", "third"), feed.snapshot().map { it.text })
    }

    @Test
    fun blankTextIsIgnored() {
        val feed = MessageFeed()
        assertEquals(0, feed.add(listOf(msg("a", "   ", 1), msg("b", "", 2))))
        assertTrue(feed.snapshot().isEmpty())
    }

    @Test
    fun originalTextIsKeptExactlyIncludingEmojiCharacters() {
        val feed = MessageFeed()
        val family = "👨‍👩‍👧 ok ❤️"
        feed.add(listOf(msg("a", family, 1)))
        assertEquals(family, feed.snapshot().single().text)
    }

    @Test
    fun oldestMessagesAreDroppedPastTheCap() {
        val feed = MessageFeed(maxMessages = 3)
        feed.add((1..5).map { msg("k$it", "m$it", it.toLong()) })
        assertEquals(listOf("m3", "m4", "m5"), feed.snapshot().map { it.text })
    }

    @Test
    fun clearedAndEvictedMessagesDoNotComeBackWhenRedelivered() {
        val feed = MessageFeed(maxMessages = 2)
        feed.add(listOf(msg("a", "one", 1), msg("b", "two", 2), msg("c", "three", 3)))
        // "one" was evicted by the cap; a later notification re-delivers it.
        assertEquals(0, feed.add(listOf(msg("a", "one", 1))))
        feed.clear()
        assertTrue(feed.snapshot().isEmpty())
        // After Clear, re-delivered old messages must not reappear either.
        assertEquals(0, feed.add(listOf(msg("b", "two", 2), msg("c", "three", 3))))
        assertTrue(feed.snapshot().isEmpty())
        // A genuinely new message still shows up.
        assertEquals(1, feed.add(listOf(msg("d", "four", 4))))
    }

    @Test
    fun listenersFireOnlyWhenSomethingChanged() {
        val feed = MessageFeed()
        var calls = 0
        feed.addChangeListener { calls++ }
        feed.add(listOf(msg("a", "hi", 1)))
        assertEquals(1, calls)
        feed.add(listOf(msg("a", "hi", 1))) // duplicate: no change
        assertEquals(1, calls)
        feed.clear()
        assertEquals(2, calls)
        feed.clear() // already empty: no change
        assertEquals(2, calls)
    }

    @Test
    fun removedListenerIsNotCalledAgain() {
        val feed = MessageFeed()
        var calls = 0
        val remove = feed.addChangeListener { calls++ }
        feed.add(listOf(msg("a", "hi", 1)))
        remove()
        feed.add(listOf(msg("b", "yo", 2)))
        assertEquals(1, calls)
    }

    @Test
    fun aThrowingListenerCannotBreakDeliveryOrOtherListeners() {
        val feed = MessageFeed()
        var goodCalls = 0
        feed.addChangeListener { throw IllegalStateException("boom") }
        feed.addChangeListener { goodCalls++ }
        assertEquals(1, feed.add(listOf(msg("a", "hi", 1))))
        assertEquals(1, goodCalls)
        assertEquals(1, feed.snapshot().size)
    }

    @Test
    fun snapshotIsACopy() {
        val feed = MessageFeed()
        feed.add(listOf(msg("a", "hi", 1)))
        val snap = feed.snapshot()
        feed.add(listOf(msg("b", "yo", 2)))
        assertEquals(1, snap.size)
        assertFalse(snap === feed.snapshot())
    }
}

/** addAndGetNew: what the background pipeline uses so it only processes genuinely new messages. */
class MessageFeedNewOnlyTest {
    private fun msg(key: String, text: String = "t", time: Long = 1) =
        FeedMessage(key, "com.google.android.apps.messaging", "Sam", text, time)

    @Test
    fun returnsOnlyNewOnes() {
        val feed = MessageFeed()
        assertEquals(listOf("a"), feed.addAndGetNew(listOf(msg("a"))).map { it.key })
        assertEquals(listOf("b"), feed.addAndGetNew(listOf(msg("a"), msg("b"))).map { it.key })
    }

    @Test
    fun redeliveryReturnsNothing() {
        val feed = MessageFeed()
        feed.addAndGetNew(listOf(msg("a")))
        assertTrue(feed.addAndGetNew(listOf(msg("a"))).isEmpty())
    }

    @Test
    fun blankTextIsNotNew() = assertTrue(MessageFeed().addAndGetNew(listOf(msg("a", text = "  "))).isEmpty())

    @Test
    fun clearedMessagesAreNotReprocessed() {
        val feed = MessageFeed()
        feed.addAndGetNew(listOf(msg("a")))
        feed.clear()
        assertTrue(feed.addAndGetNew(listOf(msg("a"))).isEmpty())
    }
}
