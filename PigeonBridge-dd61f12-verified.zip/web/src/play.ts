import type {
  ClientMessage,
  ServerMessage,
  PublicGameSession,
  PlayerSlot,
} from "@pigeonbridge/shared";
import type { CheckersBoard, CheckersMove } from "@pigeonbridge/shared/dist/games/checkers";
import type { DartsBoard, DartThrow, DartMultiplier } from "@pigeonbridge/shared/dist/games/darts";
import { legalMovesFor } from "@pigeonbridge/shared/dist/games/checkers";
import type { ChessBoard } from "@pigeonbridge/shared/dist/games/chess";
import { legalMovesFrom as chessLegalDestinations } from "@pigeonbridge/shared/dist/games/chess";
import type { BasketballBoard } from "@pigeonbridge/shared/dist/games/basketball";
import type { CupPongBoard } from "@pigeonbridge/shared/dist/games/cuppong";
import { CUP_LAYOUT } from "@pigeonbridge/shared/dist/games/cuppong";
import type { EightBallBoard } from "@pigeonbridge/shared/dist/games/eightball";
import { TABLE_W, TABLE_H, BALL_R } from "@pigeonbridge/shared/dist/games/eightball";

const NICK_KEY = "pigeonbridge_nickname";

const params = new URLSearchParams(window.location.search);
const gameId = (params.get("gameId") || "").toUpperCase();
const nickname = params.get("nickname") || safeGetStoredNickname() || "";

const boardArea = document.getElementById("boardArea")!;
const turnBanner = document.getElementById("turnBanner")!;
const statusBanner = document.getElementById("statusBanner")!;
const p1Info = document.getElementById("p1Info")!;
const p2Info = document.getElementById("p2Info")!;
const leaveBtn = document.getElementById("leaveBtn") as HTMLButtonElement;
const rematchBtn = document.getElementById("rematchBtn") as HTMLButtonElement;

if (!gameId || !nickname) {
  document.body.innerHTML = `<div class="not-implemented">Missing game code or nickname. <a href="/">Go home</a></div>`;
  throw new Error("missing params");
}
try {
  localStorage.setItem(NICK_KEY, nickname);
} catch {}

function safeGetStoredNickname(): string | null {
  try {
    return localStorage.getItem(NICK_KEY);
  } catch {
    return null;
  }
}

let mySlot: PlayerSlot | null = null;
let currentSession: PublicGameSession | null = null;
let selectedCheckersCell: { row: number; col: number } | null = null;
let dartTurnThrows: DartThrow[] = [];
let dartMultiplier: DartMultiplier = 1;

const wsProtocol = window.location.protocol === "https:" ? "wss" : "ws";
const ws = new WebSocket(`${wsProtocol}://${window.location.host}/ws`);

ws.addEventListener("open", () => {
  send({ type: "join", gameId, nickname, platform: "web" });
});

ws.addEventListener("message", (ev) => {
  const msg: ServerMessage = JSON.parse(ev.data);
  handleServerMessage(msg);
});

ws.addEventListener("close", () => {
  statusBanner.textContent = "Disconnected. Trying to reconnect…";
  setTimeout(() => window.location.reload(), 2000);
});

ws.addEventListener("error", () => {
  statusBanner.textContent = "Connection error.";
});

function send(msg: ClientMessage) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(msg));
}

function handleServerMessage(msg: ServerMessage) {
  switch (msg.type) {
    case "joined":
      mySlot = msg.session.yourSlot;
      renderSession(msg.session);
      break;
    case "opponent_joined":
    case "state_update":
    case "rematch_started":
      dartTurnThrows = [];
      selectedCheckersCell = null;
      renderSession(msg.session);
      break;
    case "game_over":
      renderSession(msg.session);
      showGameOver(msg.session);
      break;
    case "opponent_left":
      statusBanner.textContent = "Your opponent left the game.";
      break;
    case "opponent_disconnected":
      statusBanner.textContent = `Opponent disconnected — waiting up to ${Math.round(msg.graceMs / 1000)}s for them to reconnect…`;
      break;
    case "opponent_reconnected":
      statusBanner.textContent = "Opponent reconnected.";
      break;
    case "rematch_offered":
      if (msg.bySlot !== mySlot) statusBanner.textContent = "Opponent wants a rematch — tap REMATCH to accept.";
      break;
    case "error":
      statusBanner.textContent = `⚠️ ${msg.message}`;
      break;
  }
}

function renderSession(session: PublicGameSession) {
  currentSession = session;
  const p1 = session.player1;
  const p2 = session.player2;
  p1Info.innerHTML = `<div class="name">${p1 ? escapeHtml(p1.nickname) : "Waiting…"}</div>`;
  p2Info.innerHTML = `<div class="name">${p2 ? escapeHtml(p2.nickname) : "Waiting…"}</div>`;
  p1Info.classList.toggle("active", session.currentTurn === "player1" && session.status === "in_progress");
  p2Info.classList.toggle("active", session.currentTurn === "player2" && session.status === "in_progress");

  if (session.status === "waiting_for_opponent") {
    turnBanner.textContent = "Waiting for opponent to join…";
    turnBanner.classList.remove("your-turn");
  } else if (session.status === "in_progress") {
    const yourTurn = session.currentTurn === mySlot;
    turnBanner.textContent = yourTurn ? "Your turn" : "Opponent's turn";
    turnBanner.classList.toggle("your-turn", yourTurn);
    rematchBtn.style.display = "none";
  } else {
    rematchBtn.style.display = "block";
  }

  if (session.gameType === "checkers") renderCheckers(session);
  else if (session.gameType === "darts") renderDarts(session);
  else if (session.gameType === "chess") renderChess(session);
  else if (session.gameType === "basketball") renderBasketball(session);
  else if (session.gameType === "cup_pong") renderCupPong(session);
  else if (session.gameType === "eight_ball_pool") renderEightBall(session);
  else {
    const unknownType = session.gameType as string;
    boardArea.innerHTML = `<div class="not-implemented">🚧 ${unknownType.replace(
      "_",
      " "
    )} isn't playable yet in this MVP.<br/>Checkers and Darts are fully working — try one of those!</div>`;
  }
}

function escapeHtml(s: string) {
  const d = document.createElement("div");
  d.textContent = s;
  return d.innerHTML;
}

// ---------------- Checkers ----------------

function renderCheckers(session: PublicGameSession) {
  const board = session.board as CheckersBoard;
  const myTurn = session.currentTurn === mySlot && session.status === "in_progress";
  const legal = myTurn && mySlot ? legalMovesFor(board, mySlot) : [];
  const legalTargets = selectedCheckersCell
    ? legal.filter((m) => m.fromRow === selectedCheckersCell!.row && m.fromCol === selectedCheckersCell!.col)
    : [];

  const grid = document.createElement("div");
  grid.className = "board-checkers";
  // player2 (black) view is flipped so "their" side is at the bottom, matching how they physically see it
  const flip = mySlot === "player2";

  for (let displayRow = 0; displayRow < 8; displayRow++) {
    for (let displayCol = 0; displayCol < 8; displayCol++) {
      const row = flip ? 7 - displayRow : displayRow;
      const col = flip ? 7 - displayCol : displayCol;
      const sq = document.createElement("div");
      const dark = (row + col) % 2 === 1;
      sq.className = "sq " + (dark ? "dark" : "light");
      const isSelected = !!selectedCheckersCell && selectedCheckersCell.row === row && selectedCheckersCell.col === col;
      if (isSelected) sq.classList.add("selected");
      const isLegalTarget = legalTargets.some((m) => m.toRow === row && m.toCol === col);
      if (isLegalTarget) sq.classList.add("legal-target");

      const cell = board[row][col];
      if (cell !== 0) {
        const piece = document.createElement("div");
        const isRedPiece = cell === 1 || cell === 2;
        piece.className = "piece " + (isRedPiece ? "red" : "black");
        if (cell === 2 || cell === 4) piece.innerHTML = `<div class="king-mark">♛</div>`;
        sq.appendChild(piece);
      }

      if (dark && myTurn) {
        sq.addEventListener("click", () => onCheckersSquareClick(row, col, legal));
      }
      grid.appendChild(sq);
    }
  }
  boardArea.innerHTML = "";
  boardArea.appendChild(grid);
}

function onCheckersSquareClick(row: number, col: number, legal: CheckersMove[]) {
  if (!currentSession || !mySlot) return;
  const board = currentSession.board as CheckersBoard;
  const cell = board[row][col];
  const mine = mySlot === "player1" ? cell === 1 || cell === 2 : cell === 3 || cell === 4;

  if (selectedCheckersCell) {
    const move = legal.find(
      (m) => m.fromRow === selectedCheckersCell!.row && m.fromCol === selectedCheckersCell!.col && m.toRow === row && m.toCol === col
    );
    if (move) {
      send({ type: "make_move", gameId, move });
      selectedCheckersCell = null;
      return;
    }
  }
  selectedCheckersCell = mine ? { row, col } : null;
  renderSession(currentSession);
}

// ---------------- Darts ----------------

function renderDarts(session: PublicGameSession) {
  const board = session.board as DartsBoard;
  const myTurn = session.currentTurn === mySlot && session.status === "in_progress";

  const panel = document.createElement("div");
  panel.className = "darts-panel";

  const scores = document.createElement("div");
  scores.className = "darts-scores";
  scores.innerHTML = `
    <div><div class="darts-score">${board.scores.player1}</div><div class="darts-score-label">${escapeHtml(
    session.player1?.nickname || "P1"
  )}</div></div>
    <div><div class="darts-score">${board.scores.player2}</div><div class="darts-score-label">${escapeHtml(
    session.player2?.nickname || "P2"
  )}</div></div>
  `;
  panel.appendChild(scores);

  const throwRow = document.createElement("div");
  throwRow.className = "throw-row";
  for (let i = 0; i < 3; i++) {
    const slot = document.createElement("div");
    slot.className = "throw-slot";
    const t = dartTurnThrows[i];
    slot.textContent = t ? describeThrow(t) : "-";
    throwRow.appendChild(slot);
  }
  panel.appendChild(throwRow);

  if (myTurn) {
    const multRow = document.createElement("div");
    multRow.className = "mult-row";
    ([1, 2, 3] as DartMultiplier[]).forEach((m) => {
      const b = document.createElement("button");
      b.textContent = m === 1 ? "Single" : m === 2 ? "Double" : "Triple";
      if (m === dartMultiplier) b.classList.add("active");
      b.addEventListener("click", () => {
        dartMultiplier = m;
        renderDarts(session);
      });
      multRow.appendChild(b);
    });
    panel.appendChild(multRow);

    const numGrid = document.createElement("div");
    numGrid.className = "dart-controls";
    for (let n = 1; n <= 20; n++) {
      const b = document.createElement("button");
      b.textContent = String(n);
      b.disabled = dartTurnThrows.length >= 3;
      b.addEventListener("click", () => addThrow({ segment: n, multiplier: dartMultiplier }));
      numGrid.appendChild(b);
    }
    const bullBtn = document.createElement("button");
    bullBtn.textContent = dartMultiplier === 2 ? "Bull 50" : "Bull 25";
    bullBtn.disabled = dartTurnThrows.length >= 3 || dartMultiplier === 3;
    bullBtn.addEventListener("click", () => addThrow({ segment: 25, multiplier: dartMultiplier === 2 ? 2 : 1 }));
    numGrid.appendChild(bullBtn);
    panel.appendChild(numGrid);

    const actions = document.createElement("div");
    actions.style.display = "flex";
    actions.style.gap = "8px";
    const undoBtn = document.createElement("button");
    undoBtn.className = "btn btn-secondary";
    undoBtn.style.flex = "1";
    undoBtn.textContent = "UNDO";
    undoBtn.disabled = dartTurnThrows.length === 0;
    undoBtn.addEventListener("click", () => {
      dartTurnThrows.pop();
      renderDarts(session);
    });
    const submitBtn = document.createElement("button");
    submitBtn.className = "btn btn-primary";
    submitBtn.style.flex = "1";
    submitBtn.textContent = "SUBMIT TURN";
    submitBtn.disabled = dartTurnThrows.length === 0;
    submitBtn.addEventListener("click", () => {
      send({ type: "make_move", gameId, move: { throws: dartTurnThrows } });
    });
    actions.appendChild(undoBtn);
    actions.appendChild(submitBtn);
    panel.appendChild(actions);
  } else {
    const waiting = document.createElement("p");
    waiting.style.color = "var(--muted)";
    waiting.textContent = "Waiting for opponent's throw…";
    panel.appendChild(waiting);
  }

  boardArea.innerHTML = "";
  boardArea.appendChild(panel);
}

function addThrow(t: DartThrow) {
  if (dartTurnThrows.length >= 3) return;
  dartTurnThrows.push(t);
  if (currentSession) renderDarts(currentSession);
}

function describeThrow(t: DartThrow): string {
  const label = t.segment === 25 ? "Bull" : String(t.segment);
  const prefix = t.multiplier === 3 ? "T" : t.multiplier === 2 ? "D" : "";
  return prefix + label;
}

// ---------------- Controls ----------------

leaveBtn.addEventListener("click", () => {
  send({ type: "leave", gameId });
  window.location.href = "/";
});

rematchBtn.addEventListener("click", () => {
  send({ type: "request_rematch", gameId });
  rematchBtn.textContent = "Waiting for opponent…";
  rematchBtn.disabled = true;
  setTimeout(() => {
    rematchBtn.disabled = false;
    rematchBtn.textContent = "REMATCH";
  }, 5000);
});

function showGameOver(session: PublicGameSession) {
  if (session.status === "draw") {
    statusBanner.textContent = "It's a draw!";
  } else if (session.status === "player1_won" || session.status === "player2_won") {
    const winnerSlot: PlayerSlot = session.status === "player1_won" ? "player1" : "player2";
    const iWon = winnerSlot === mySlot;
    statusBanner.textContent = iWon ? "🎉 You won!" : "You lost — good game.";
  } else if (session.status === "abandoned") {
    statusBanner.textContent = "Game ended.";
  }
}

// ---------------- Chess ----------------

const CHESS_FILES = ["a", "b", "c", "d", "e", "f", "g", "h"];
const CHESS_UNICODE: Record<string, string> = {
  wp: "♙", wn: "♘", wb: "♗", wr: "♖", wq: "♕", wk: "♔",
  bp: "♟", bn: "♞", bb: "♝", br: "♜", bq: "♛", bk: "♚",
};
let selectedChessSquare: string | null = null;

function fenBoard(fen: string): (string | null)[][] {
  const rows = fen.split(" ")[0].split("/");
  return rows.map((row) => {
    const cells: (string | null)[] = [];
    for (const ch of row) {
      if (/\d/.test(ch)) {
        for (let i = 0; i < Number(ch); i++) cells.push(null);
      } else {
        const color = ch === ch.toUpperCase() ? "w" : "b";
        cells.push(color + ch.toLowerCase());
      }
    }
    return cells;
  });
}

function renderChess(session: PublicGameSession) {
  const board = session.board as ChessBoard;
  const myTurn = mySlot && session.currentTurn === mySlot && session.status === "in_progress";
  const myColor = mySlot === "player1" ? "w" : "b";
  const grid = fenBoard(board.fen); // grid[0] = rank 8 (top, Black's back rank) ... grid[7] = rank 1
  const flip = mySlot === "player2";
  const legalTargets = selectedChessSquare && myTurn ? chessLegalDestinations(board, selectedChessSquare) : [];

  const container = document.createElement("div");
  container.className = "board-checkers"; // reuse the same 8x8 grid styling

  for (let displayRow = 0; displayRow < 8; displayRow++) {
    for (let displayCol = 0; displayCol < 8; displayCol++) {
      const rank = flip ? displayRow : displayRow; // grid index already top-to-bottom = rank8..rank1
      const file = flip ? 7 - displayCol : displayCol;
      const gridRow = flip ? 7 - rank : rank;
      const square = CHESS_FILES[file] + String(8 - gridRow);
      const piece = grid[gridRow][file];

      const sq = document.createElement("div");
      const dark = (gridRow + file) % 2 === 1;
      sq.className = "sq " + (dark ? "dark" : "light");
      if (selectedChessSquare === square) sq.classList.add("selected");
      if (legalTargets.includes(square)) sq.classList.add("legal-target");
      if (board.lastMove && (board.lastMove.from === square || board.lastMove.to === square)) {
        sq.style.boxShadow = "inset 0 0 0 3px rgba(250,204,21,0.6)";
      }

      if (piece) {
        const span = document.createElement("div");
        span.textContent = CHESS_UNICODE[piece] || "?";
        span.style.fontSize = "min(7vw, 34px)";
        span.style.lineHeight = "1";
        span.style.color = piece[0] === "w" ? "#f5f3ff" : "#111827";
        span.style.textShadow = piece[0] === "w" ? "0 1px 2px rgba(0,0,0,0.6)" : "none";
        sq.appendChild(span);
      }

      if (myTurn) {
        sq.addEventListener("click", () => onChessSquareClick(square, piece, myColor));
      }
      container.appendChild(sq);
    }
  }
  boardArea.innerHTML = "";
  boardArea.appendChild(container);
}

function onChessSquareClick(square: string, piece: string | null, myColor: string) {
  if (!currentSession) return;
  const board = currentSession.board as ChessBoard;

  if (selectedChessSquare) {
    const targets = chessLegalDestinations(board, selectedChessSquare);
    if (targets.includes(square)) {
      // Auto-queen on promotion; a full "choose your piece" picker is a
      // nice-to-have, but queen covers the overwhelming majority of games.
      const isPawnToLastRank =
        (selectedChessSquare[1] === "7" && square[1] === "8") || (selectedChessSquare[1] === "2" && square[1] === "1");
      send({
        type: "make_move",
        gameId,
        move: isPawnToLastRank ? { from: selectedChessSquare, to: square, promotion: "q" } : { from: selectedChessSquare, to: square },
      });
      selectedChessSquare = null;
      return;
    }
  }
  selectedChessSquare = piece && piece[0] === myColor ? square : null;
  renderSession(currentSession);
}

// ---------------- Shared drag-to-shoot gesture ----------------

/** Attaches a drag gesture to a canvas: drag start->end vector becomes (angleDeg, power 0-100, dx normalized). */
function attachDragShoot(
  canvas: HTMLCanvasElement,
  onShoot: (angleDeg: number, power: number, normalizedDx: number) => void,
  onDrag?: (angleDeg: number, power: number, normalizedDx: number) => void,
) {
  let dragStart: { x: number; y: number } | null = null;
  const maxDrag = Math.min(canvas.width, canvas.height) * 0.6;

  function pos(ev: PointerEvent): { x: number; y: number } {
    const rect = canvas.getBoundingClientRect();
    return { x: ev.clientX - rect.left, y: ev.clientY - rect.top };
  }

  function compute(start: { x: number; y: number }, end: { x: number; y: number }) {
    const dx = end.x - start.x;
    const dy = end.y - start.y;
    const dist = Math.min(Math.hypot(dx, dy), maxDrag);
    const power = Math.round((dist / maxDrag) * 100);
    // Dragging DOWN/AWAY from the target (like pulling a slingshot back) fires
    // UP/FORWARD — angle is measured from the vector opposite the drag.
    const angleRad = Math.atan2(-dy, -dx);
    let angleDeg = (angleRad * 180) / Math.PI;
    if (angleDeg < 0) angleDeg += 360;
    const normalizedDx = Math.max(-1, Math.min(1, dx / maxDrag));
    return { angleDeg, power, normalizedDx };
  }

  canvas.addEventListener("pointerdown", (ev) => {
    dragStart = pos(ev);
    canvas.setPointerCapture(ev.pointerId);
  });
  canvas.addEventListener("pointermove", (ev) => {
    if (!dragStart) return;
    const { angleDeg, power, normalizedDx } = compute(dragStart, pos(ev));
    onDrag?.(angleDeg, power, normalizedDx);
  });
  canvas.addEventListener("pointerup", (ev) => {
    if (!dragStart) return;
    const { angleDeg, power, normalizedDx } = compute(dragStart, pos(ev));
    dragStart = null;
    if (power > 5) onShoot(angleDeg, power, normalizedDx);
  });
  canvas.addEventListener("pointercancel", () => {
    dragStart = null;
  });
}

// ---------------- Basketball ----------------

function renderBasketball(session: PublicGameSession) {
  const board = session.board as BasketballBoard;
  const myTurn = session.currentTurn === mySlot && session.status === "in_progress";

  const wrap = document.createElement("div");
  wrap.style.textAlign = "center";

  const scoreLine = document.createElement("div");
  scoreLine.style.marginBottom = "8px";
  scoreLine.innerHTML = `<b>${escapeHtml(session.player1?.nickname || "P1")}</b>: ${board.scores.player1}/${board.shotsTaken.player1}
    &nbsp;·&nbsp;
    <b>${escapeHtml(session.player2?.nickname || "P2")}</b>: ${board.scores.player2}/${board.shotsTaken.player2}
    &nbsp;(${board.rounds} shots each)`;
  wrap.appendChild(scoreLine);

  const canvas = document.createElement("canvas");
  canvas.width = 320;
  canvas.height = 320;
  canvas.style.width = "min(92vw, 320px)";
  canvas.style.touchAction = "none";
  canvas.style.background = "#0c2340";
  canvas.style.borderRadius = "16px";
  wrap.appendChild(canvas);

  const hint = document.createElement("p");
  hint.style.color = "var(--muted)";
  hint.style.fontSize = "13px";
  hint.textContent = myTurn
    ? board.lastShot
      ? board.lastShot.made
        ? "🏀 Nice shot! Drag up from the ball to shoot again."
        : "Missed — drag up from the ball to shoot again."
      : "Drag up from the ball to aim, release to shoot."
    : "Waiting for opponent's shot…";
  wrap.appendChild(hint);

  boardArea.innerHTML = "";
  boardArea.appendChild(wrap);

  const ctx = canvas.getContext("2d")!;
  const ballStart = { x: 60, y: 260 };
  let aim: { angleDeg: number; power: number } | null = null;

  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    // hoop
    ctx.strokeStyle = "#e5e7eb";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(230, 60);
    ctx.lineTo(230, 240);
    ctx.stroke();
    ctx.fillStyle = "#ef4444";
    ctx.fillRect(230, 55, 40, 6);
    ctx.strokeStyle = "#fb923c";
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.ellipse(250, 61, 20, 5, 0, 0, Math.PI * 2);
    ctx.stroke();
    // ball
    ctx.fillStyle = "#f97316";
    ctx.beginPath();
    ctx.arc(ballStart.x, ballStart.y, 12, 0, Math.PI * 2);
    ctx.fill();
    // aim line
    if (aim) {
      const rad = (aim.angleDeg * Math.PI) / 180;
      const len = (aim.power / 100) * 140;
      ctx.strokeStyle = "rgba(124,58,237,0.8)";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(ballStart.x, ballStart.y);
      ctx.lineTo(ballStart.x + Math.cos(rad) * len, ballStart.y - Math.sin(rad) * len);
      ctx.stroke();
    }
  }
  draw();

  if (myTurn) {
    attachDragShoot(
      canvas,
      (angleDeg, power) => {
        send({ type: "make_move", gameId, move: { angleDeg, power } });
      },
      (angleDeg, power) => {
        aim = { angleDeg, power };
        draw();
      },
    );
  }
}

// ---------------- Cup Pong ----------------

function renderCupPong(session: PublicGameSession) {
  const board = session.board as CupPongBoard;
  const myTurn = session.currentTurn === mySlot && session.status === "in_progress";
  const myCupsKey = mySlot === "player1" ? "player1Cups" : "player2Cups";
  const targetCupsKey = mySlot === "player1" ? "player2Cups" : "player1Cups";

  const wrap = document.createElement("div");
  wrap.style.textAlign = "center";
  const label = document.createElement("p");
  label.style.color = "var(--muted)";
  label.style.fontSize = "13px";
  label.textContent = myTurn ? "Drag to aim at their cups, release to throw." : "Waiting for opponent's throw…";
  wrap.appendChild(label);

  const canvas = document.createElement("canvas");
  canvas.width = 320;
  canvas.height = 300;
  canvas.style.width = "min(92vw, 320px)";
  canvas.style.touchAction = "none";
  canvas.style.background = "linear-gradient(#7c2d12,#78350f)";
  canvas.style.borderRadius = "16px";
  wrap.appendChild(canvas);
  boardArea.innerHTML = "";
  boardArea.appendChild(wrap);

  const ctx = canvas.getContext("2d")!;
  const throwerY = 260;
  let lastLandingX: number | null = board.lastThrow ? board.lastThrow.landingX : null;

  function xToCanvas(x: number) {
    return canvas.width / 2 + x * (canvas.width / 2 - 24);
  }

  function draw(aimX: number | null) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    // opponent's cups (far side, top) — what I'm throwing at
    const remaining = (board as any)[targetCupsKey] as number[];
    for (const cup of CUP_LAYOUT) {
      const cx = xToCanvas(cup.x);
      const standing = remaining.includes(cup.id);
      ctx.fillStyle = standing ? "#ef4444" : "rgba(255,255,255,0.15)";
      ctx.beginPath();
      ctx.arc(cx, 50, 13, 0, Math.PI * 2);
      ctx.fill();
    }
    // my cups (near side, bottom)
    const mine = (board as any)[myCupsKey] as number[];
    for (const cup of CUP_LAYOUT) {
      const cx = xToCanvas(cup.x);
      const standing = mine.includes(cup.id);
      ctx.fillStyle = standing ? "#3b82f6" : "rgba(255,255,255,0.1)";
      ctx.beginPath();
      ctx.arc(cx, throwerY + 15, 10, 0, Math.PI * 2);
      ctx.fill();
    }
    if (aimX !== null) {
      ctx.strokeStyle = "rgba(124,58,237,0.85)";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(canvas.width / 2, throwerY);
      ctx.lineTo(xToCanvas(aimX), 60);
      ctx.stroke();
    }
    if (lastLandingX !== null) {
      ctx.fillStyle = "rgba(255,255,255,0.6)";
      ctx.beginPath();
      ctx.arc(xToCanvas(lastLandingX), 55, 4, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  draw(null);

  if (myTurn) {
    attachDragShoot(
      canvas,
      (angleDeg, power, normalizedDx) => {
        send({
          type: "make_move",
          gameId,
          move: { aimOffset: normalizedDx, angleDeg: Math.max(10, Math.min(80, angleDeg)), power },
        });
      },
      (_angleDeg, _power, normalizedDx) => draw(normalizedDx),
    );
  }
}

// ---------------- Eight-Ball Pool ----------------

function renderEightBall(session: PublicGameSession) {
  const board = session.board as EightBallBoard;
  const myTurn = session.currentTurn === mySlot && session.status === "in_progress";
  const iHaveBallInHand = board.ballInHandFor === mySlot;
  const mySuit = mySlot ? board.assignedSuit[mySlot] : undefined;

  const wrap = document.createElement("div");
  wrap.style.textAlign = "center";

  const info = document.createElement("p");
  info.style.color = "var(--muted)";
  info.style.fontSize = "13px";
  info.textContent = !myTurn
    ? "Waiting for opponent's shot…"
    : iHaveBallInHand
    ? "Ball in hand — tap the table to place the cue ball, then drag to shoot."
    : `Drag from the cue ball to aim, release to shoot.${mySuit ? ` You're ${mySuit}.` : " Table is open."}`;
  wrap.appendChild(info);

  if (board.lastShot?.foulReason) {
    const foul = document.createElement("p");
    foul.style.color = "#fbbf24";
    foul.style.fontSize = "13px";
    foul.textContent = `⚠️ ${board.lastShot.foulReason}`;
    wrap.appendChild(foul);
  }

  const scale = 1.5;
  const canvas = document.createElement("canvas");
  canvas.width = TABLE_W * scale;
  canvas.height = TABLE_H * scale;
  canvas.style.width = "min(92vw, 420px)";
  canvas.style.touchAction = "none";
  canvas.style.background = "#15803d";
  canvas.style.borderRadius = "10px";
  canvas.style.border = "8px solid #7c4a2d";
  wrap.appendChild(canvas);
  boardArea.innerHTML = "";
  boardArea.appendChild(wrap);

  const ctx = canvas.getContext("2d")!;
  let placingCue: { x: number; y: number } | null = null;
  let aim: { angleDeg: number; power: number } | null = null;

  function ballColor(id: number): string {
    if (id === 0) return "#f9fafb";
    if (id === 8) return "#111827";
    if (id <= 7) return ["#facc15", "#3b82f6", "#ef4444", "#a855f7", "#f97316", "#16a34a", "#7c2d12"][id - 1];
    return ["#facc15", "#3b82f6", "#ef4444", "#a855f7", "#f97316", "#16a34a", "#7c2d12"][id - 9];
  }

  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    // pockets
    ctx.fillStyle = "#0b0b0b";
    const pockets = [
      [0, 0], [TABLE_W / 2, 0], [TABLE_W, 0],
      [0, TABLE_H], [TABLE_W / 2, TABLE_H], [TABLE_W, TABLE_H],
    ];
    for (const [px, py] of pockets) {
      ctx.beginPath();
      ctx.arc(px * scale, py * scale, 6 * scale, 0, Math.PI * 2);
      ctx.fill();
    }
    // balls
    for (const b of board.balls) {
      if (b.pocketed) continue;
      const bx = placingCue && b.id === 0 ? placingCue.x : b.x;
      const by = placingCue && b.id === 0 ? placingCue.y : b.y;
      ctx.fillStyle = ballColor(b.id);
      ctx.beginPath();
      ctx.arc(bx * scale, by * scale, BALL_R * scale, 0, Math.PI * 2);
      ctx.fill();
      if (b.id !== 0) {
        ctx.strokeStyle = "rgba(255,255,255,0.7)";
        ctx.lineWidth = 1;
        ctx.stroke();
        if (b.id > 8) {
          ctx.fillStyle = "#fff";
          ctx.beginPath();
          ctx.arc(bx * scale, by * scale, BALL_R * scale * 0.5, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    }
    if (aim) {
      const cue = board.balls.find((b) => b.id === 0);
      if (cue) {
        const rad = (aim.angleDeg * Math.PI) / 180;
        const len = (aim.power / 100) * 60;
        ctx.strokeStyle = "rgba(255,255,255,0.85)";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(cue.x * scale, cue.y * scale);
        ctx.lineTo((cue.x + Math.cos(rad) * len) * scale, (cue.y - Math.sin(rad) * len) * scale);
        ctx.stroke();
      }
    }
  }
  draw();

  if (myTurn && iHaveBallInHand) {
    canvas.addEventListener("pointerdown", (ev) => {
      const rect = canvas.getBoundingClientRect();
      const x = ((ev.clientX - rect.left) / rect.width) * TABLE_W;
      const y = ((ev.clientY - rect.top) / rect.height) * TABLE_H;
      placingCue = { x, y };
      draw();
    });
    const confirmBtn = document.createElement("button");
    confirmBtn.className = "btn btn-primary";
    confirmBtn.style.marginTop = "10px";
    confirmBtn.textContent = "CONFIRM PLACEMENT & AIM";
    confirmBtn.addEventListener("click", () => {
      if (!placingCue) return alert("Tap the table to place the cue ball first.");
      const cue = board.balls.find((b) => b.id === 0)!;
      cue.x = placingCue.x;
      cue.y = placingCue.y;
      confirmBtn.remove();
      attachDragShoot(
        canvas,
        (angleDeg, power) => {
          send({
            type: "make_move",
            gameId,
            move: { angleDeg, power, placeCueAt: placingCue },
          });
        },
        (angleDeg, power) => {
          aim = { angleDeg, power };
          draw();
        },
      );
    });
    wrap.appendChild(confirmBtn);
  } else if (myTurn) {
    attachDragShoot(
      canvas,
      (angleDeg, power) => {
        send({ type: "make_move", gameId, move: { angleDeg, power } });
      },
      (angleDeg, power) => {
        aim = { angleDeg, power };
        draw();
      },
    );
  }
}
