import { test } from "node:test";
import assert from "node:assert/strict";
import { eightball } from "@pigeonbridge/shared";
import { applyMove, createInitialBoard } from "../src/game/engine";

function boardWithBalls(overrides: Partial<eightball.Ball>[]): eightball.EightBallBoard {
  const base = createInitialBoard("eight_ball_pool") as eightball.EightBallBoard;
  const balls = base.balls.map((b) => {
    const o = overrides.find((x) => x.id === b.id);
    return o ? { ...b, ...o } : b;
  });
  return { ...base, balls };
}

// Verified geometry (see scratch testing in dev): a ball sitting just outside
// a corner pocket's capture radius, with the cue lined up directly behind it
// on the pocket line, reliably drops it in across a range of shot power —
// this exercises the *real* physics simulation (collision + pocket capture),
// it's just aimed at a shot we know the geometry supports rather than a
// generic break, so the win/turn-continuation logic actually gets exercised.
const POCKET = { x: 0, y: 100 };
const TARGET_BALL = { x: 4.2, y: 96 };
const dist = Math.hypot(TARGET_BALL.x - POCKET.x, TARGET_BALL.y - POCKET.y);
const dirX = (TARGET_BALL.x - POCKET.x) / dist;
const dirY = (TARGET_BALL.y - POCKET.y) / dist;
const CUE_POS = { x: TARGET_BALL.x + dirX * 6, y: TARGET_BALL.y + dirY * 6 };
const SHOT_ANGLE = (Math.atan2(POCKET.y - CUE_POS.y, POCKET.x - CUE_POS.x) * 180) / Math.PI;
const SHOT_POWER = 15;

function farAwayBalls(excludeIds: number[]): Partial<eightball.Ball>[] {
  return [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
    .filter((id) => !excludeIds.includes(id))
    .map((id) => ({ id, x: 190, y: 5 + id * 2, vx: 0, vy: 0, pocketed: false }));
}

test("break shot: no foul when cue legally contacts the rack, no suit assigned yet on an open table", () => {
  const board = createInitialBoard("eight_ball_pool") as eightball.EightBallBoard;
  const result = applyMove("eight_ball_pool", board, "player1", { angleDeg: 0, power: 95 });
  const b = result.board as eightball.EightBallBoard;
  assert.equal(b.lastShot?.foul, false);
  assert.equal(b.ballInHandFor, null);
});

test("no-contact shot (cue hits nothing) is a foul and grants opponent ball-in-hand", () => {
  const board = boardWithBalls([{ id: 0, x: 10, y: 10, vx: 0, vy: 0, pocketed: false }]);
  const result = applyMove("eight_ball_pool", board, "player1", { angleDeg: 90, power: 1 });
  const b = result.board as eightball.EightBallBoard;
  assert.equal(b.lastShot?.foul, true);
  assert.equal(b.ballInHandFor, "player2");
  assert.equal(result.nextTurn, "player2");
});

test("scratch (cue pocketed) is a foul and grants opponent ball-in-hand", () => {
  const board = boardWithBalls([{ id: 0, x: 3, y: 3, vx: 0, vy: 0, pocketed: false }]);
  const result = applyMove("eight_ball_pool", board, "player1", { angleDeg: 225, power: 20 });
  const b = result.board as eightball.EightBallBoard;
  assert.equal(b.lastShot?.scratched, true);
  assert.equal(b.lastShot?.foul, true);
  assert.equal(b.ballInHandFor, "player2");
  assert.equal(result.nextTurn, "player2");
});

test("ball-in-hand: the player who has it can place the cue ball; the other player cannot move", () => {
  const scratched = boardWithBalls([{ id: 0, x: 3, y: 3, vx: 0, vy: 0, pocketed: false }]);
  const afterScratch = applyMove("eight_ball_pool", scratched, "player1", { angleDeg: 225, power: 20 })
    .board as eightball.EightBallBoard;
  assert.equal(afterScratch.ballInHandFor, "player2");

  assert.throws(() => applyMove("eight_ball_pool", afterScratch, "player1", { angleDeg: 0, power: 50 }));

  const placed = applyMove("eight_ball_pool", afterScratch, "player2", {
    angleDeg: 0,
    power: 10,
    placeCueAt: { x: 100, y: 50 },
  }).board as eightball.EightBallBoard;
  const cue = placed.balls.find((b) => b.id === 0)!;
  assert.equal(cue.pocketed, false);
});

test("legally pocketing your own group's ball on an open table assigns your suit and keeps your turn", () => {
  const board = boardWithBalls([
    { id: 0, x: CUE_POS.x, y: CUE_POS.y, vx: 0, vy: 0, pocketed: false },
    { id: 1, x: TARGET_BALL.x, y: TARGET_BALL.y, vx: 0, vy: 0, pocketed: false },
    ...farAwayBalls([0, 1]),
  ]);
  const result = applyMove("eight_ball_pool", board, "player1", { angleDeg: SHOT_ANGLE, power: SHOT_POWER });
  const b = result.board as eightball.EightBallBoard;
  const ball1 = b.balls.find((x) => x.id === 1)!;

  assert.equal(ball1.pocketed, true, "the verified geometry should reliably pocket ball 1");
  assert.equal(b.assignedSuit.player1, "solids");
  assert.equal(b.assignedSuit.player2, "stripes");
  assert.equal(result.nextTurn, "player1", "pocketing your own ball with no foul keeps your turn");
  assert.equal(b.lastShot?.foul, false);
});

test("pocketing the OPPONENT's suit ball does not extend your turn", () => {
  // Ball 9 (a stripe) sits at the same verified pocket geometry; player1 has
  // already been assigned "solids", so potting a stripe is not their own group.
  const board = boardWithBalls([
    { id: 0, x: CUE_POS.x, y: CUE_POS.y, vx: 0, vy: 0, pocketed: false },
    { id: 9, x: TARGET_BALL.x, y: TARGET_BALL.y, vx: 0, vy: 0, pocketed: false },
    ...farAwayBalls([0, 9]),
  ]);
  const preAssigned = { ...board, assignedSuit: { player1: "solids" as const, player2: "stripes" as const } };
  const result = applyMove("eight_ball_pool", preAssigned, "player1", { angleDeg: SHOT_ANGLE, power: SHOT_POWER });
  const b = result.board as eightball.EightBallBoard;
  const ball9 = b.balls.find((x) => x.id === 9)!;

  assert.equal(ball9.pocketed, true);
  // Contacting and pocketing the opponent's suit first-contact is a foul
  // (wrong suit hit first) under this engine's rules, so ball-in-hand passes.
  assert.equal(b.lastShot?.foul, true);
  assert.equal(result.nextTurn, "player2");
});

test("potting the 8-ball before clearing your suit is an instant loss for the shooter", () => {
  const board = boardWithBalls([
    { id: 0, x: CUE_POS.x, y: CUE_POS.y, vx: 0, vy: 0, pocketed: false },
    { id: 8, x: TARGET_BALL.x, y: TARGET_BALL.y, vx: 0, vy: 0, pocketed: false },
    ...farAwayBalls([0, 8]),
  ]);
  const preAssigned = { ...board, assignedSuit: { player1: "solids" as const, player2: "stripes" as const } };
  const result = applyMove("eight_ball_pool", preAssigned, "player1", { angleDeg: SHOT_ANGLE, power: SHOT_POWER });
  const b = result.board as eightball.EightBallBoard;
  const eight = b.balls.find((x) => x.id === 8)!;

  assert.equal(eight.pocketed, true);
  assert.equal(result.winner, "player2", "shooter loses for potting the 8-ball before clearing their suit");
});

test("legally potting the 8-ball after clearing your suit wins the game", () => {
  // All of player1's solids (1-7) start already pocketed; only the 8-ball is left for them.
  const board = boardWithBalls([
    { id: 0, x: CUE_POS.x, y: CUE_POS.y, vx: 0, vy: 0, pocketed: false },
    { id: 8, x: TARGET_BALL.x, y: TARGET_BALL.y, vx: 0, vy: 0, pocketed: false },
    ...[1, 2, 3, 4, 5, 6, 7].map((id) => ({ id, x: 190, y: 5 + id * 2, vx: 0, vy: 0, pocketed: true })),
    ...[9, 10, 11, 12, 13, 14, 15].map((id) => ({ id, x: 195, y: 5 + id * 2, vx: 0, vy: 0, pocketed: false })),
  ]);
  const preAssigned = { ...board, assignedSuit: { player1: "solids" as const, player2: "stripes" as const } };
  const result = applyMove("eight_ball_pool", preAssigned, "player1", { angleDeg: SHOT_ANGLE, power: SHOT_POWER });
  const b = result.board as eightball.EightBallBoard;
  const eight = b.balls.find((x) => x.id === 8)!;

  assert.equal(eight.pocketed, true);
  assert.equal(result.winner, "player1");
});
