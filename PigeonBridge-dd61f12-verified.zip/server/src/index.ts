import express from "express";
import cors from "cors";
import http from "http";
import path from "path";
import { rateLimit } from "express-rate-limit";
import pinoHttp from "pino-http";
import { WebSocketServer } from "ws";
import { gamesRouter } from "./routes/games";
import { inviteRouter } from "./routes/invite";
import { attachWebSocketServer } from "./ws/handler";
import { sessionStore } from "./game/sessionStore";
import { logger } from "./logger";
import { GAME_ABANDON_TIMEOUT_MS } from "@pigeonbridge/shared";

const app = express();
app.use(cors());
app.use(express.json());

// Structured request logging (method, path, status, latency) — replaces
// scattered console.log calls; ships as JSON lines in production so it's
// pipeable into any log aggregator, pretty-printed locally (see logger.ts).
app.use(
  pinoHttp({
    logger,
    autoLogging: { ignore: (req: any) => req.url === "/api/health" },
  }),
);

// Rate limit game creation specifically — this is the one endpoint that
// costs server memory per call (creates a session) and is the most obvious
// abuse target (spamming session creation). WebSocket messages have their
// own separate per-connection rate limit (see ws/handler.ts).
const createGameLimiter = rateLimit({
  windowMs: 60_000,
  limit: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { code: "rate_limited", message: "Too many games created — try again in a minute." },
});
app.use("/api/games", (req, res, next) => {
  if (req.method === "POST") return createGameLimiter(req, res, next);
  next();
});

// Dynamic invite pages (/g/:gameId) must be registered before the static
// fallback below so they take priority over any similarly-named static file.
app.use(inviteRouter);
app.use("/api", gamesRouter);

// Serve the built web SPA (index.html = home/create, play.html = game screen,
// home.js/play.js = bundles). In production this could just as easily be a
// separate static host/CDN in front of the same API — single-process here
// keeps the MVP simple to run and deploy as one thing.
const webDist = path.join(__dirname, "..", "..", "web", "dist");
app.use(express.static(path.join(__dirname, "..", "public"))); // serves /.well-known/assetlinks.json
app.use(express.static(webDist));
app.get("/play", (_req, res) => res.sendFile(path.join(webDist, "play.html")));
app.get("/", (_req, res) => res.sendFile(path.join(webDist, "index.html")));

// 404 for anything under /api that didn't match a route above.
app.use("/api", (_req, res) => {
  res.status(404).json({ code: "not_found", message: "No such API route" });
});

// Centralized error handler — catches anything thrown or passed to next(err)
// by the routes above and returns a clean JSON error instead of leaking a
// stack trace to the client. Must be registered last, and must keep all 4
// params (err, req, res, next) for Express to recognize it as an error handler.
// eslint-disable-next-line @typescript-eslint/no-unused-vars
app.use((err: any, req: express.Request, res: express.Response, _next: express.NextFunction) => {
  logger.error({ err, path: req.path }, "Unhandled request error");
  res.status(500).json({ code: "server_error", message: "Something went wrong" });
});

const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: "/ws" });
attachWebSocketServer(wss);

// Sweep abandoned sessions periodically so memory doesn't grow unbounded.
setInterval(() => sessionStore.sweepAbandoned(), Math.min(GAME_ABANDON_TIMEOUT_MS, 5 * 60 * 1000));

const PORT = process.env.PORT ? Number(process.env.PORT) : 3001;
server.listen(PORT, () => {
  logger.info(`PigeonBridge server listening on :${PORT} (REST /api, WS /ws)`);
});

process.on("unhandledRejection", (reason) => {
  logger.error({ reason }, "Unhandled promise rejection");
});
process.on("uncaughtException", (err) => {
  logger.fatal({ err }, "Uncaught exception — exiting");
  process.exit(1);
});

export { app, server };
