import { Chess } from "chess.js";
import { PlayerSlot } from "../models";

// player1 always plays White, player2 always plays Black — fixed at game
// creation (see sessionStore.create), matching how every other game in this
// project assigns player1/player2 to a fixed side.
export interface ChessBoard {
  fen: string; // authoritative position, Forsyth-Edwards Notation
  pgn: string; // move history, useful for a client-side move log / replay
  lastMove: { from: string; to: string } | null; // for highlighting on clients
}

export interface ChessMove {
  from: string; // e.g. "e2"
  to: string; // e.g. "e4"
  promotion?: "q" | "r" | "b" | "n"; // required when a pawn move reaches the last rank
}

export function createInitialChessBoard(): ChessBoard {
  const chess = new Chess();
  return { fen: chess.fen(), pgn: "", lastMove: null };
}

function slotToColor(slot: PlayerSlot): "w" | "b" {
  return slot === "player1" ? "w" : "b";
}

export function legalMovesFrom(board: ChessBoard, square: string): string[] {
  const chess = new Chess(board.fen);
  return chess.moves({ square: square as any, verbose: true }).map((m: any) => m.to);
}

/** All legal moves for the side to move, as {from, to, promotion?} — used by clients to highlight legal targets. */
export function allLegalMoves(board: ChessBoard): ChessMove[] {
  const chess = new Chess(board.fen);
  return chess.moves({ verbose: true }).map((m: any) => ({
    from: m.from,
    to: m.to,
    promotion: m.promotion,
  }));
}

/**
 * Validates and applies a move. Throws on illegal move (wrong turn is checked
 * by the caller before this — see server/src/game/engine.ts — since that
 * needs the session's currentTurn, not just chess.js's internal turn).
 */
export function applyChessMove(board: ChessBoard, slot: PlayerSlot, move: ChessMove): ChessBoard {
  const chess = new Chess(board.fen);
  if (chess.turn() !== slotToColor(slot)) {
    throw new Error("It's not your color's turn");
  }
  let result;
  try {
    result = chess.move({ from: move.from, to: move.to, promotion: move.promotion });
  } catch {
    result = null;
  }
  if (!result) throw new Error("Illegal move");

  return {
    fen: chess.fen(),
    pgn: chess.pgn(),
    lastMove: { from: move.from, to: move.to },
  };
}

export type ChessOutcome =
  | { over: false }
  | { over: true; winner: PlayerSlot | "draw"; reason: "checkmate" | "stalemate" | "draw" };

export function chessOutcome(board: ChessBoard): ChessOutcome {
  const chess = new Chess(board.fen);
  if (chess.isCheckmate()) {
    // The side that JUST moved delivered mate, so the side to move now (chess.turn()) lost.
    const winner: PlayerSlot = chess.turn() === "w" ? "player2" : "player1";
    return { over: true, winner, reason: "checkmate" };
  }
  if (chess.isStalemate()) return { over: true, winner: "draw", reason: "stalemate" };
  if (chess.isDraw()) return { over: true, winner: "draw", reason: "draw" }; // 50-move, insufficient material, threefold repetition
  return { over: false };
}

export function isInCheck(board: ChessBoard): boolean {
  return new Chess(board.fen).isCheck();
}
