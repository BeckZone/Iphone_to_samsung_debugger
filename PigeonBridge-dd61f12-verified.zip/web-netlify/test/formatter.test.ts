import { test } from "node:test";
import assert from "node:assert/strict";
import { formatReport, type DiagnosticReport } from "../src/formatter.ts";

function sampleReport(overrides: Partial<DiagnosticReport> = {}): DiagnosticReport {
  return {
    fileName: "sticker.png",
    mimeReported: "image/png",
    mimeDetectedFromBytes: "image/png",
    fileExtension: "png",
    sizeBytes: 82431,
    lastModifiedMillis: null,
    widthPx: 512,
    heightPx: 512,
    hasAlpha: true,
    bitDepthDescription: "RGBA, 8-bit/channel",
    isAnimated: false,
    frameCount: 1,
    previewSuspected: true,
    previewReasons: ["dimensions are small"],
    classification: "LIKELY_STICKER",
    classificationSignals: [
      { name: "alpha", stickerPoints: 1, photoPoints: 0, detail: "has alpha channel (+1 sticker)" },
      { name: "mime", stickerPoints: 1, photoPoints: 0, detail: "sticker-typical MIME image/png (+1 sticker)" },
    ],
    stickerScore: 7,
    photoScore: 0,
    decodeSucceeded: true,
    decodedWidthPx: 512,
    decodedHeightPx: 512,
    quality: "SMALL",
    qualityReason: "512 × 512",
    ...overrides,
  };
}

test("report includes file name and MIME", () => {
  const text = formatReport(sampleReport());
  assert.ok(text.includes("File name: sticker.png"));
  assert.ok(text.includes("MIME reported: image/png"));
});

test("flags a MIME disagreement", () => {
  const text = formatReport(sampleReport({ mimeDetectedFromBytes: "image/webp" }));
  assert.ok(text.includes("Reported and detected MIME disagree"));
});

test("does not flag agreement as a disagreement", () => {
  const text = formatReport(sampleReport());
  assert.ok(!text.includes("disagree"));
});

test("unavailable size is stated explicitly, not assumed", () => {
  const text = formatReport(sampleReport({ sizeBytes: -1 }));
  assert.ok(text.includes("Size unavailable"));
});

test("known size is formatted with a comma-grouped byte count", () => {
  const text = formatReport(sampleReport({ sizeBytes: 82431 }));
  assert.ok(text.includes("82,431 bytes"));
});

test("sticker classification and score are present", () => {
  const text = formatReport(sampleReport());
  assert.ok(text.includes("Sticker classification: LIKELY_STICKER"));
  assert.ok(text.includes("Sticker score: 7"));
});

test("quality never claims 'original'", () => {
  const text = formatReport(sampleReport({ quality: "SMALL" }));
  assert.ok(text.includes("Attachment quality: SMALL"));
  assert.ok(!text.includes("Original quality"));
});

test("report states the source is a local upload, not automatic message access", () => {
  const text = formatReport(sampleReport());
  assert.ok(text.includes("local file upload"));
});

test("scoring signals are listed individually", () => {
  const text = formatReport(sampleReport());
  assert.ok(text.includes("alpha: has alpha channel"));
  assert.ok(text.includes("mime: sticker-typical MIME image/png"));
});
