# Signing keys

## Dev keystore (checked in)

`pigeonbridge-release.keystore` was generated for this MVP so that release
builds are signed and `server/public/.well-known/assetlinks.json` (which
verifies Android App Links) has a real, matching SHA-256 certificate
fingerprint out of the box, with zero setup.

- Alias: `pigeonbridge`
- Store password / key password: `pigeonbridge123`
- Fingerprint (already in `assetlinks.json`):
  `58:50:C1:BC:3C:49:0B:DE:14:38:F5:33:07:CE:16:0B:1E:10:41:47:B4:B4:C6:53:F4:67:B4:B9:20:09:66:8D`

These credentials are intentionally public (they're in this file, in git).
`app/build.gradle.kts` uses them only as a last-resort fallback — see below —
never as the actual production signing secret.

## Where signing credentials actually come from

`app/build.gradle.kts` resolves each of the four signing values in this order:

1. **`android/local.properties`** (gitignored — never committed) — for a
   local release build with your own key, add:
   ```
   PIGEONBRIDGE_KEYSTORE_PATH=/absolute/path/to/your.keystore
   PIGEONBRIDGE_STORE_PASSWORD=...
   PIGEONBRIDGE_KEY_ALIAS=...
   PIGEONBRIDGE_KEY_PASSWORD=...
   ```
2. **Environment variables** of the same names — this is what
   `.github/workflows/android-build.yml` sets from **GitHub Actions secrets**
   (repo Settings > Secrets and variables > Actions) when they're configured.
3. **The dev keystore's own credentials above** — pure fallback, so a fresh
   clone still builds a signed (if not production-ready) APK with no setup.

## Before a real public release

1. Generate your own keystore and **do not commit it**:
   ```
   keytool -genkeypair -v -keystore your-release.keystore -alias yourAlias \
     -keyalg RSA -keysize 2048 -validity 10000
   ```
2. Either set the four `PIGEONBRIDGE_*` values in `android/local.properties`
   (local builds) or as GitHub Actions repo secrets (CI builds) — see above.
   The dev-keystore fallback is then never used.
3. Get your new key's fingerprint and update
   `server/public/.well-known/assetlinks.json` with it (App Links verification
   is tied to this exact fingerprint):
   ```
   keytool -list -v -keystore your-release.keystore -alias yourAlias
   ```
4. Re-deploy the server so the new `assetlinks.json` is live before shipping
   the new APK, or App Link verification will fail for users who update.
