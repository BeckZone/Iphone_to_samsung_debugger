package app.pigeonbridge.android.background

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ProcessingStatusTest {

    private fun status(
        on: Boolean = true, access: Boolean = true, observed: Boolean = true,
        event: Long? = 1L, processed: Long? = 2L, via: SurfacedVia? = SurfacedVia.NONE,
    ) = ProcessingStatus(on, access, observed, event, processed, 1, "Twemoji", via)

    private fun h(s: ProcessingStatus) = ProcessingStatusFormatter.headline(s)

    @Test fun offIsStated() = assertTrue(h(status(on = false)).contains("OFF"))
    @Test fun noAccessIsStated() = assertTrue(h(status(access = false)).contains("not granted"))
    @Test fun notConnectedIsStated() = assertTrue(h(status(observed = false)).contains("not connected") || h(status(observed = false)).contains("has not connected"))
    @Test fun waitingForFirstMessage() = assertTrue(h(status(event = null, processed = null)).startsWith("Ready"))
    @Test fun eventWithoutProcessingDoesNotClaimSuccess() {
        val t = h(status(processed = null))
        assertFalse(t.contains("Processed automatically"))
    }

    @Test
    fun successAlwaysCarriesTheAndroidLimit() {
        assertTrue(h(status()).startsWith(ProcessingStatusFormatter.ANDROID_LIMIT_LINE))
        assertTrue(h(status(via = SurfacedVia.PROCESSED_NOTIFICATION)).startsWith(ProcessingStatusFormatter.ANDROID_LIMIT_LINE))
        assertTrue(h(status(via = SurfacedVia.PROCESSED_NOTIFICATION)).contains("separate PigeonBridge notification"))
    }

    @Test
    fun neverClaimsMessagesUiWasChanged() {
        assertTrue(ProcessingStatusFormatter.SURFACED_INTO_MESSAGES_UI.startsWith("No."))
        assertEquals(
            "Processed automatically, but Android does not permit another app to modify the original Messages UI.",
            ProcessingStatusFormatter.ANDROID_LIMIT_LINE,
        )
    }

    // ---- processing failures -> plain English ----
    @Test fun nullAndBlankHaveNoExplanation() {
        assertNull(FailureExplainer.explain(null))
        assertNull(FailureExplainer.explain("  "))
    }

    @Test
    fun uriPermissionFailure() {
        val t = FailureExplainer.explain("Attachment URI present but not readable: SecurityException: Permission Denial")!!
        assertTrue(t.contains("refused"))
    }

    @Test fun notReadable() = assertTrue(FailureExplainer.explain("URI present but not readable")!!.contains("did not let"))
    @Test fun nullStream() = assertTrue(FailureExplainer.explain("openInputStream returned null")!!.contains("returned nothing"))
    @Test fun badBitmap() = assertTrue(FailureExplainer.explain("Bitmap decode failed")!!.contains("decode"))
    @Test fun unknownIsShownNotHidden() = assertTrue(FailureExplainer.explain("weird")!!.contains("weird"))
}
