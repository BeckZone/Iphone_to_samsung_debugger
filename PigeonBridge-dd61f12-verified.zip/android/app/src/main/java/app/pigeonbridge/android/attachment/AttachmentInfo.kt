package app.pigeonbridge.android.attachment

/**
 * Everything PigeonBridge could determine about an incoming shared
 * attachment (typically from Android's share sheet — see
 * MainActivity.extractSharedImage / ShareReceiverScreen) without decoding
 * the full bitmap into memory. Deliberately Android-framework-free (no Uri,
 * no Bitmap) so [StickerDetector]'s classification logic is a plain,
 * unit-testable function of these fields.
 */
data class AttachmentInfo(
    /** From ContentResolver.getType(uri), or null if the provider didn't report one. */
    val mimeType: String?,
    /** From OpenableColumns.DISPLAY_NAME, or null if unavailable. */
    val displayName: String?,
    /** From OpenableColumns.SIZE, in bytes. -1 if unknown/unreported. */
    val reportedSizeBytes: Long,
    /** Decoded image bounds (BitmapFactory.Options.outWidth/outHeight), in pixels. -1 if decode failed. */
    val widthPx: Int,
    val heightPx: Int,
    /** Whether a sampled decode found a non-opaque alpha channel. Null if we couldn't determine this (e.g. bounds decode failed). */
    val hasAlpha: Boolean?,
    /** EXIF orientation in degrees (0/90/180/270), 0 if none/not applicable (PNG/WebP usually carry no EXIF). */
    val exifRotationDegrees: Int,
    /**
     * Best-effort signal that Android (or the sending app) only exposed a
     * low-resolution/placeholder version rather than the real attachment.
     * This is a heuristic, not a guarantee — see AttachmentInspector for
     * exactly what trips it. When true, the UI must say so rather than
     * presenting the image as full quality (spec Part 10).
     */
    val isLikelyPreview: Boolean,
    /** True if we couldn't decode the image at all (corrupt/unsupported — test case #8). */
    val decodeFailed: Boolean,
    /** Which decode path handled bounds/alpha probing — for debug logging only, never shown to the user as a quality claim. */
    val decodePath: String,
)

enum class AttachmentClassification {
    LIKELY_STICKER,
    NORMAL_IMAGE,
    /** Decode failed or metadata was too sparse to classify either way (test case #8, corrupt/unsupported attachment). */
    UNKNOWN,
}

data class ClassificationResult(
    val classification: AttachmentClassification,
    /** Human-debuggable reasons behind the classification (debug logging only, see AttachmentDebugLog). */
    val signals: List<String>,
)
