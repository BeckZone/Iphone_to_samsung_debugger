import { test } from "node:test";
import assert from "node:assert/strict";
import { basketball, cuppong } from "@pigeonbridge/shared";

test("basketball: invalid power is rejected", () => {
  const board = basketball.createInitialBasketballBoard();
  assert.throws(() => basketball.applyBasketballMove(board, "player1", { angleDeg: 45, power: 150 }));
});

test("basketball: a bad shot (too flat/weak) reliably misses", () => {
  const board = basketball.createInitialBasketballBoard();
  const result = basketball.applyBasketballMove(board, "player1", { angleDeg: 10, power: 15 });
  assert.equal(result.lastShot?.made, false);
  assert.equal(result.scores.player1, 0);
});

test("basketball: shot count increments and game ends after both players finish their rounds", () => {
  let board = basketball.createInitialBasketballBoard();
  for (let i = 0; i < board.rounds; i++) {
    board = basketball.applyBasketballMove(board, "player1", { angleDeg: 10, power: 15 }); // deliberate misses
    board = basketball.applyBasketballMove(board, "player2", { angleDeg: 10, power: 15 });
  }
  assert.equal(board.shotsTaken.player1, board.rounds);
  assert.equal(board.shotsTaken.player2, board.rounds);
  const outcome = basketball.basketballOutcome(board);
  assert.equal(outcome, "draw"); // both missed everything -> 0-0 draw
});

test("basketball: can't shoot more than the allotted rounds", () => {
  let board = basketball.createInitialBasketballBoard();
  for (let i = 0; i < board.rounds; i++) {
    board = basketball.applyBasketballMove(board, "player1", { angleDeg: 10, power: 15 });
  }
  assert.throws(() => basketball.applyBasketballMove(board, "player1", { angleDeg: 10, power: 15 }));
});

test("cup pong: invalid aim offset is rejected", () => {
  const board = cuppong.createInitialCupPongBoard();
  assert.throws(() => cuppong.applyCupPongMove(board, "player1", { aimOffset: 5, angleDeg: 45, power: 50 }));
});

test("cup pong: starts with 6 cups per side and no winner", () => {
  const board = cuppong.createInitialCupPongBoard();
  assert.equal(board.player1Cups.length, 6);
  assert.equal(board.player2Cups.length, 6);
  assert.equal(cuppong.cupPongWinner(board), null);
});

test("cup pong: clearing all opponent cups declares a winner", () => {
  let board = cuppong.createInitialCupPongBoard();
  // Manually clear player2's cups (player1's target) to test win detection
  // in isolation from the landing-position physics.
  board = { ...board, player2Cups: [] };
  assert.equal(cuppong.cupPongWinner(board), "player1");
});
