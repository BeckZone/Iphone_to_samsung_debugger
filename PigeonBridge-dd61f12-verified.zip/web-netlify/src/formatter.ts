import type { AttachmentClassification, QualityClass, SignalScore } from "./classifier.ts";

export interface DiagnosticReport {
  fileName: string | null;
  mimeReported: string | null; // from the browser File.type
  mimeDetectedFromBytes: string | null; // from magic-byte sniffing, independent of File.type
  fileExtension: string | null;
  sizeBytes: number; // -1 if unavailable
  lastModifiedMillis: number | null;

  widthPx: number;
  heightPx: number;
  hasAlpha: boolean | null;
  bitDepthDescription: string | null;
  isAnimated: boolean | null;
  frameCount: number | null;

  previewSuspected: boolean;
  previewReasons: string[];

  classification: AttachmentClassification;
  classificationSignals: SignalScore[];
  stickerScore: number;
  photoScore: number;

  decodeSucceeded: boolean;
  decodedWidthPx: number | null;
  decodedHeightPx: number | null;

  quality: QualityClass;
  qualityReason: string;
}

function boolText(b: boolean | null): string {
  if (b === true) return "YES";
  if (b === false) return "NO";
  return "Unknown";
}

function qualityText(q: QualityClass): string {
  if (q === "FULL_LARGE") return "FULL / LARGE";
  if (q === "SMALL") return "SMALL";
  return "UNKNOWN";
}

function formatBytes(bytes: number): string {
  return bytes.toLocaleString("en-US");
}

function formatKbMb(bytes: number): string {
  const kb = bytes / 1024;
  if (kb >= 1024) return `${(kb / 1024).toFixed(2)} MB`;
  return `${kb.toFixed(1)} KB`;
}

/**
 * Plain-text report for the "Copy Diagnostic Report" button. Deliberately
 * excludes anything beyond this one file's technical metadata -- no message
 * content exists to leak in the browser version (the user picked/dropped a
 * file directly; there's no inbox to read), but this stays consistent with
 * the same privacy posture as the Android version's formatter.
 */
export function formatReport(report: DiagnosticReport): string {
  const lines: string[] = [];
  lines.push("PigeonBridge Attachment Diagnostic (web)");
  lines.push("");
  lines.push("Source: local file upload (browser File API) -- not read from Messages automatically");
  lines.push("");

  lines.push(`MIME reported: ${report.mimeReported ?? "Unknown"}`);
  lines.push(`MIME detected (from bytes): ${report.mimeDetectedFromBytes ?? "Unknown"}`);
  if (report.mimeReported && report.mimeDetectedFromBytes && report.mimeReported !== report.mimeDetectedFromBytes) {
    lines.push("  (!) Reported and detected MIME disagree");
  }
  lines.push(`File extension: ${report.fileExtension ?? "Unknown"}`);
  lines.push("");

  lines.push(`File name: ${report.fileName ?? "Unknown"}`);
  if (report.sizeBytes >= 0) {
    lines.push(`File size: ${formatBytes(report.sizeBytes)} bytes (${formatKbMb(report.sizeBytes)})`);
  } else {
    lines.push("File size: Size unavailable");
  }
  lines.push(`Last modified: ${report.lastModifiedMillis != null ? new Date(report.lastModifiedMillis).toISOString() : "Unknown"}`);
  lines.push("");

  if (report.widthPx > 0 && report.heightPx > 0) {
    lines.push(`Dimensions: ${report.widthPx} × ${report.heightPx}`);
    lines.push(`Aspect ratio: ${(report.widthPx / report.heightPx).toFixed(2)}`);
  } else {
    lines.push("Dimensions: Unknown");
    lines.push("Aspect ratio: Unknown");
  }
  lines.push(`Bit depth / color format: ${report.bitDepthDescription ?? "Unknown"}`);
  lines.push(`Alpha: ${boolText(report.hasAlpha)}`);
  lines.push(`Animated: ${boolText(report.isAnimated)}`);
  lines.push(`Frame count: ${report.frameCount != null ? String(report.frameCount) : "Unknown"}`);
  lines.push("");

  lines.push(`Preview suspected: ${report.previewSuspected ? "YES" : "NO"}`);
  if (report.previewReasons.length === 1) {
    lines.push(`Preview reason: ${report.previewReasons[0]}`);
  } else if (report.previewReasons.length > 1) {
    lines.push("Preview reasons:");
    report.previewReasons.forEach((r) => lines.push(`  - ${r}`));
  }
  lines.push("");

  lines.push(`Sticker classification: ${report.classification}`);
  lines.push(`Sticker score: ${report.stickerScore} (photo score: ${report.photoScore})`);
  lines.push("Scoring signals:");
  report.classificationSignals.forEach((s) => lines.push(`  - ${s.name}: ${s.detail}`));
  lines.push("");

  lines.push(`Bitmap decode: ${report.decodeSucceeded ? "SUCCESS" : "FAIL"}`);
  if (report.decodeSucceeded && report.decodedWidthPx != null && report.decodedHeightPx != null) {
    lines.push(`Decoded dimensions: ${report.decodedWidthPx} × ${report.decodedHeightPx}`);
  }
  lines.push("");

  lines.push(`Attachment quality: ${qualityText(report.quality)}`);
  lines.push(`Quality reason: ${report.qualityReason}`);

  return lines.join("\n");
}
