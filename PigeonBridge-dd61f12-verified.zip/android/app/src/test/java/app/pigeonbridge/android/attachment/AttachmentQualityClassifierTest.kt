package app.pigeonbridge.android.attachment

import org.junit.Assert.assertEquals
import org.junit.Test

class AttachmentQualityClassifierTest {

    @Test
    fun `large dimensions classify as FULL_LARGE`() {
        val result = AttachmentQualityClassifier.classify(1024, 1024)
        assertEquals(QualityClass.FULL_LARGE, result.quality)
    }

    @Test
    fun `small dimensions classify as SMALL`() {
        val result = AttachmentQualityClassifier.classify(128, 128)
        assertEquals(QualityClass.SMALL, result.quality)
    }

    @Test
    fun `dimension exactly at threshold classifies as FULL_LARGE`() {
        val result = AttachmentQualityClassifier.classify(400, 100)
        assertEquals(QualityClass.FULL_LARGE, result.quality)
    }

    @Test
    fun `one dimension large is enough for FULL_LARGE`() {
        // e.g. a wide banner sticker: 900x120 — large on one axis, still a real asset, not a tiny preview.
        val result = AttachmentQualityClassifier.classify(900, 120)
        assertEquals(QualityClass.FULL_LARGE, result.quality)
    }

    @Test
    fun `unknown dimensions classify as UNKNOWN, never guessed`() {
        assertEquals(QualityClass.UNKNOWN, AttachmentQualityClassifier.classify(-1, -1).quality)
        assertEquals(QualityClass.UNKNOWN, AttachmentQualityClassifier.classify(0, 0).quality)
    }

    @Test
    fun `reason states the actual dimensions, not a quality claim`() {
        val result = AttachmentQualityClassifier.classify(128, 128)
        assertEquals("128 × 128", result.reason)
    }
}
