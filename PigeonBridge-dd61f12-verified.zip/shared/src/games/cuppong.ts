import { PlayerSlot } from "../models";

// Real projectile simulation again (see basketball.ts for the same approach):
// aim + power determine an actual trajectory; we compute where the ball's
// arc intersects table height, then do circle-collision against the cup
// formation at that landing point — not a random hit/miss roll.
export const TABLE_LENGTH = 240;
export const CUP_RADIUS = 5;
const GRAVITY = 200;
const MAX_THROW_SPEED = 190;
const DT = 1 / 480;
const CUPS_PER_SIDE = 6;

export interface CupPongMove {
  aimOffset: number; // -1 (full left) .. 1 (full right), lateral aim across the table width
  angleDeg: number; // launch angle, sensible arc range ~30-70
  power: number; // 0-100
}

export interface CupPosition {
  id: number;
  x: number; // lateral position, -1..1 scale matching aimOffset
}

export interface CupPongBoard {
  // Each side's remaining cups are the OPPONENT's target: player1 throws at
  // player2Cups, player2 throws at player1Cups — mirrors real beer pong.
  player1Cups: number[]; // ids of player1's own cups still standing (player2's targets)
  player2Cups: number[]; // ids of player2's own cups still standing (player1's targets)
  lastThrow: { by: PlayerSlot; hitCupId: number | null; landingX: number } | null;
}

function initialCupLayout(): CupPosition[] {
  // Simple triangular layout collapsed onto the 1D lateral axis used for aim,
  // since the ball's lateral landing position is what aimOffset controls.
  // Row spread from -0.8 to 0.8 gives 6 distinct aim targets.
  return [-0.8, -0.5, -0.2, 0.2, 0.5, 0.8].map((x, i) => ({ id: i + 1, x }));
}

export const CUP_LAYOUT = initialCupLayout();

export function createInitialCupPongBoard(): CupPongBoard {
  const ids = CUP_LAYOUT.map((c) => c.id);
  return { player1Cups: [...ids], player2Cups: [...ids], lastThrow: null };
}

/** Returns the ball's lateral landing position (-1..1 scale) once it descends to table/cup height. */
function simulateLandingX(aimOffset: number, angleDeg: number, power: number): number {
  const rad = (angleDeg * Math.PI) / 180;
  const speed = (power / 100) * MAX_THROW_SPEED;
  let forwardDist = 0;
  let height = 0;
  let vForward = Math.cos(rad) * speed;
  let vUp = Math.sin(rad) * speed;
  let t = 0;

  while (t < 4) {
    t += DT;
    vUp -= GRAVITY * DT;
    forwardDist += vForward * DT;
    height += vUp * DT;
    if (height <= 0 && t > DT * 2) break; // ball has landed on the table plane
  }

  // Map how far it traveled forward, relative to the full table length, into
  // lateral drift around the player's aim: overshoot/undershoot an intended
  // throw drifts the landing spot toward center (harder to land a precise
  // long throw), modeled as aim accuracy scaling with how close forwardDist
  // is to the opponent's cup distance.
  const targetDist = TABLE_LENGTH * 0.82;
  const distanceError = (forwardDist - targetDist) / targetDist; // 0 = perfect distance
  const drift = distanceError * 0.6; // poor distance control pulls the shot off aim
  const landingX = Math.max(-1, Math.min(1, aimOffset + drift));
  return landingX;
}

export function applyCupPongMove(board: CupPongBoard, slot: PlayerSlot, move: CupPongMove): CupPongBoard {
  if (move.power < 0 || move.power > 100) throw new Error("Power must be 0-100");
  if (move.aimOffset < -1 || move.aimOffset > 1) throw new Error("Aim offset must be between -1 and 1");
  if (move.angleDeg < 10 || move.angleDeg > 80) throw new Error("Angle must be between 10 and 80 degrees");

  const targetCupsKey: keyof CupPongBoard = slot === "player1" ? "player2Cups" : "player1Cups";
  const remainingIds = board[targetCupsKey] as number[];
  if (remainingIds.length === 0) throw new Error("Opponent has no cups left");

  const landingX = simulateLandingX(move.aimOffset, move.angleDeg, move.power);

  let hitCupId: number | null = null;
  let bestDist = Infinity;
  for (const cup of CUP_LAYOUT) {
    if (!remainingIds.includes(cup.id)) continue;
    const d = Math.abs(cup.x - landingX);
    if (d <= CUP_RADIUS / 20 && d < bestDist) {
      bestDist = d;
      hitCupId = cup.id;
    }
  }

  const nextRemaining = hitCupId !== null ? remainingIds.filter((id) => id !== hitCupId) : remainingIds;

  return {
    ...board,
    [targetCupsKey]: nextRemaining,
    lastThrow: { by: slot, hitCupId, landingX },
  } as CupPongBoard;
}

export function cupPongWinner(board: CupPongBoard): PlayerSlot | null {
  if (board.player2Cups.length === 0) return "player1"; // player1 cleared player2's cups
  if (board.player1Cups.length === 0) return "player2";
  return null;
}
