package app.pigeonbridge.android.ui.screens

import app.pigeonbridge.android.emoji.EmojiText
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.pigeonbridge.android.data.GAME_DISPLAY_NAMES
import app.pigeonbridge.android.data.GAME_EMOJI
import app.pigeonbridge.android.data.GameType
import app.pigeonbridge.android.data.IMPLEMENTED_GAMES
import app.pigeonbridge.android.ui.GameViewModel
import app.pigeonbridge.android.ui.PrimaryButton
import app.pigeonbridge.android.ui.theme.PBPrimary
import app.pigeonbridge.android.ui.theme.PBSurfaceVariant

@Composable
fun CreateGameScreen(
    viewModel: GameViewModel,
    onGameCreated: (String) -> Unit,
    onBack: () -> Unit,
) {
    var selectedGame by remember { mutableStateOf<GameType?>(null) }
    var nickname by remember { mutableStateOf(viewModel.nickname) }
    var creating by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    Scaffold(topBar = { TopAppBar(title = { Text("Create Game") }) }) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.fillMaxWidth(),
            ) {
                items(GameType.entries) { gt ->
                    val implemented = IMPLEMENTED_GAMES.contains(gt)
                    val selected = selectedGame == gt
                    Column(
                        modifier = Modifier
                            .padding(6.dp)
                            .aspectRatio(1f)
                            .background(
                                if (selected) PBSurfaceVariant else PBSurfaceVariant.copy(alpha = 0.6f),
                                RoundedCornerShape(16.dp),
                            )
                            .border(
                                2.dp,
                                if (selected) PBPrimary else androidx.compose.ui.graphics.Color.Transparent,
                                RoundedCornerShape(16.dp),
                            )
                            .clickable(enabled = implemented) { selectedGame = gt }
                            .padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        EmojiText(GAME_EMOJI[gt] ?: "🎮", fontSize = 30.sp)
                        Text(
                            GAME_DISPLAY_NAMES[gt] ?: gt.wireValue,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        )
                        if (!implemented) Text("coming soon", fontSize = 10.sp)
                    }
                }
            }

            TextField(
                value = nickname,
                onValueChange = { nickname = it.take(20) },
                placeholder = { Text("Your nickname") },
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                colors = TextFieldDefaults.colors(),
            )

            error?.let { Text(it, color = androidx.compose.ui.graphics.Color(0xFFEF4444), modifier = Modifier.padding(top = 8.dp)) }

            Column(modifier = Modifier.padding(top = 20.dp)) {
                PrimaryButton(
                    text = if (creating) "Creating…" else "CREATE GAME",
                    enabled = selectedGame != null && nickname.isNotBlank() && !creating,
                ) {
                    val gt = selectedGame ?: return@PrimaryButton
                    creating = true
                    error = null
                    viewModel.createGame(gt.wireValue, nickname.trim()) { result ->
                        creating = false
                        if (result != null) onGameCreated(result.gameId) else error = "Couldn't create game — check your connection."
                    }
                }
            }
        }
    }
}
