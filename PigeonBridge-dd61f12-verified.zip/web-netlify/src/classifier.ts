// Mirrors android/app/src/main/java/app/pigeonbridge/android/attachment/StickerDetector.kt's
// scoring rules exactly (same signals, same thresholds, same points) so the
// web and Android diagnostic tools agree on the same input. Kept in sync by
// hand — there's no shared package between a Gradle/Kotlin project and this
// static site, so if you change one, change the other.

export type AttachmentClassification = "LIKELY_STICKER" | "NORMAL_IMAGE" | "UNKNOWN";

export interface SignalScore {
  name: string;
  stickerPoints: number;
  photoPoints: number;
  detail: string;
}

export interface DetailedClassification {
  classification: AttachmentClassification;
  stickerScore: number;
  photoScore: number;
  signals: SignalScore[];
}

export interface ClassifyInput {
  mimeType: string | null;
  displayName: string | null;
  widthPx: number; // -1 if unknown
  heightPx: number;
  hasAlpha: boolean | null;
  decodeFailed: boolean;
}

const STICKER_MAX_DIMENSION = 768;
const STICKER_TINY_DIMENSION = 300;

export function classifyDetailed(info: ClassifyInput): DetailedClassification {
  if (info.decodeFailed) {
    return {
      classification: "UNKNOWN",
      stickerScore: 0,
      photoScore: 0,
      signals: [{ name: "decode", stickerPoints: 0, photoPoints: 0, detail: "decode failed — corrupt or unsupported attachment" }],
    };
  }

  const signals: SignalScore[] = [];

  // Signal: alpha transparency.
  if (info.hasAlpha === true) {
    signals.push({ name: "alpha", stickerPoints: 1, photoPoints: 0, detail: "has alpha channel (+1 sticker)" });
  } else if (info.hasAlpha === false) {
    signals.push({ name: "alpha", stickerPoints: 0, photoPoints: 1, detail: "no alpha channel (+1 photo)" });
  } else {
    signals.push({ name: "alpha", stickerPoints: 0, photoPoints: 0, detail: "alpha undetermined" });
  }

  // Signal: MIME type.
  if (info.mimeType === "image/png" || info.mimeType === "image/webp" || info.mimeType === "image/gif") {
    signals.push({ name: "mime", stickerPoints: 1, photoPoints: 0, detail: `sticker-typical MIME ${info.mimeType} (+1 sticker)` });
  } else if (info.mimeType === "image/jpeg") {
    signals.push({ name: "mime", stickerPoints: 0, photoPoints: 2, detail: "JPEG has no transparency/animation support (+2 photo)" });
  } else {
    signals.push({ name: "mime", stickerPoints: 0, photoPoints: 0, detail: `MIME ${info.mimeType ?? "Unknown"} not decisive` });
  }

  // Signal: dimensions.
  const maxDim = Math.max(info.widthPx, info.heightPx);
  if (info.widthPx >= 1 && info.widthPx <= STICKER_TINY_DIMENSION && info.heightPx >= 1 && info.heightPx <= STICKER_TINY_DIMENSION) {
    signals.push({ name: "dimension", stickerPoints: 2, photoPoints: 0, detail: `tiny dimensions ${info.widthPx}x${info.heightPx} (+2 sticker)` });
  } else if (maxDim >= 1 && maxDim <= STICKER_MAX_DIMENSION) {
    signals.push({ name: "dimension", stickerPoints: 1, photoPoints: 0, detail: `small dimensions ${info.widthPx}x${info.heightPx} (+1 sticker)` });
  } else if (maxDim > STICKER_MAX_DIMENSION) {
    signals.push({ name: "dimension", stickerPoints: 0, photoPoints: 2, detail: `large dimensions ${info.widthPx}x${info.heightPx}, larger than a typical sticker (+2 photo)` });
  } else {
    signals.push({ name: "dimension", stickerPoints: 0, photoPoints: 0, detail: "dimensions unknown" });
  }

  // Signal: aspect ratio (only evaluated at sticker-scale dimensions).
  if (maxDim >= 1 && maxDim <= STICKER_MAX_DIMENSION && info.widthPx > 0 && info.heightPx > 0) {
    const ratio = info.widthPx / info.heightPx;
    const looksLikeStandardPhotoRatio = (ratio >= 0.6 && ratio <= 0.85) || (ratio >= 1.2 && ratio <= 1.8);
    if (!looksLikeStandardPhotoRatio) {
      signals.push({ name: "aspect_ratio", stickerPoints: 1, photoPoints: 0, detail: `non-photo-like aspect ratio ${ratio.toFixed(2)} (+1 sticker)` });
    } else {
      signals.push({ name: "aspect_ratio", stickerPoints: 0, photoPoints: 0, detail: `standard photo-like aspect ratio ${ratio.toFixed(2)}` });
    }
  } else {
    signals.push({ name: "aspect_ratio", stickerPoints: 0, photoPoints: 0, detail: "not evaluated (dimensions not sticker-scale or unknown)" });
  }

  // Signal: filename hint.
  const name = (info.displayName ?? "").toLowerCase();
  if (name.includes("sticker")) {
    signals.push({ name: "filename", stickerPoints: 1, photoPoints: 0, detail: "filename mentions 'sticker' (+1 sticker)" });
  } else {
    signals.push({ name: "filename", stickerPoints: 0, photoPoints: 0, detail: "no filename hint" });
  }

  const stickerScore = signals.reduce((sum, s) => sum + s.stickerPoints, 0);
  const photoScore = signals.reduce((sum, s) => sum + s.photoPoints, 0);
  let classification: AttachmentClassification;
  if (stickerScore >= 3 && stickerScore > photoScore) classification = "LIKELY_STICKER";
  else if (photoScore > stickerScore) classification = "NORMAL_IMAGE";
  else classification = "UNKNOWN";

  return { classification, stickerScore, photoScore, signals };
}

// ---- Quality classification — mirrors AttachmentQualityClassifier.kt exactly ----

export type QualityClass = "FULL_LARGE" | "SMALL" | "UNKNOWN";

export interface QualityResult {
  quality: QualityClass;
  reason: string;
}

const SMALL_THRESHOLD = 400;

export function classifyQuality(widthPx: number, heightPx: number): QualityResult {
  if (widthPx <= 0 || heightPx <= 0) {
    return { quality: "UNKNOWN", reason: "dimensions could not be determined" };
  }
  const maxDim = Math.max(widthPx, heightPx);
  if (maxDim < SMALL_THRESHOLD) {
    return { quality: "SMALL", reason: `${widthPx} × ${heightPx}` };
  }
  return { quality: "FULL_LARGE", reason: `${widthPx} × ${heightPx}` };
}
