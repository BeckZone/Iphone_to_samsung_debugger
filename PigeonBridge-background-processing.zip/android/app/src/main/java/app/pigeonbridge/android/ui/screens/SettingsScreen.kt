package app.pigeonbridge.android.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import app.pigeonbridge.android.ui.GameViewModel
import app.pigeonbridge.android.ui.PrimaryButton
import app.pigeonbridge.android.ui.SecondaryButton

@Composable
fun SettingsScreen(
    viewModel: GameViewModel,
    onBack: () -> Unit,
    onOpenMonitoring: () -> Unit,
    onOpenMessages: () -> Unit,
    onOpenBackgroundProcessing: () -> Unit,
) {
    var nickname by remember { mutableStateOf(viewModel.nickname) }

    Scaffold(topBar = { TopAppBar(title = { Text("Settings") }) }) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
            Text("Nickname")
            TextField(
                value = nickname,
                onValueChange = { nickname = it.take(20) },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 20.dp),
            )
            PrimaryButton("SAVE") {
                viewModel.nickname = nickname.trim()
                onBack()
            }
            Column(modifier = Modifier.padding(top = 24.dp)) {
                SecondaryButton("Background Message Processing") { onOpenBackgroundProcessing() }
                Column(modifier = Modifier.padding(top = 10.dp)) {
                    SecondaryButton("Background Monitoring") { onOpenMonitoring() }
                }
                Column(modifier = Modifier.padding(top = 10.dp)) {
                    SecondaryButton("Messages (chat view)") { onOpenMessages() }
                }
            }
        }
    }
}
