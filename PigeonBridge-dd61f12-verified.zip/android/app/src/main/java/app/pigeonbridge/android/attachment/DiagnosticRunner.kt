package app.pigeonbridge.android.attachment

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Process
import android.provider.DocumentsContract

/**
 * Diagnostic Mode's data-gathering layer. Deliberately does NOT reimplement
 * anything [AttachmentInspector], [StickerDetector], or
 * [AttachmentBitmapDecoder] already do — it calls them and adds only the
 * extra probes those don't already cover (URI parts, byte-sniffed MIME,
 * animation/frame count, readability tests, permission state, alternate
 * representations). This is read-only: it never writes, recompresses,
 * upscales, or uploads anything, and never touches a Uri other than the one
 * it's given.
 */
object DiagnosticRunner {

    data class DiagnosticResult(
        val report: DiagnosticReport,
        /** Kept separate from [DiagnosticReport] (which is framework-free) purely for on-screen preview; never re-encoded or persisted. */
        val decodedBitmap: Bitmap?,
    )

    fun run(context: Context, uri: Uri): DiagnosticResult {
        // ---- Reuse existing pipeline, unmodified ----
        val info = AttachmentInspector.inspect(context, uri)
        val detailed = StickerDetector.classifyDetailed(info)

        // ---- Test A: can we open the stream at all? ----
        val uriReadable = try {
            context.contentResolver.openInputStream(uri)?.use { true } ?: false
        } catch (t: Throwable) {
            false
        }

        // ---- Test B: can we actually read bytes from it? ----
        val streamReadable = if (!uriReadable) false else try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val buf = ByteArray(16)
                stream.read(buf) > 0
            } ?: false
        } catch (t: Throwable) {
            false
        }

        // ---- Test C: does the EXISTING decoder succeed? (also gives us the preview bitmap for Part 10) ----
        val decoded = if (streamReadable) {
            try {
                AttachmentBitmapDecoder.decode(context, uri, info)
            } catch (t: Throwable) {
                null
            }
        } else null

        // ---- MIME detected from magic bytes, independent of ContentResolver.getType() ----
        val mimeFromBytes = detectMimeFromMagicBytes(context, uri)

        // ---- File extension, from display name only (no guessing beyond that) ----
        val extension = info.displayName?.substringAfterLast('.', "")?.takeIf { it.isNotBlank() }

        // ---- Last-modified, where the provider exposes it ----
        val lastModified = queryLastModified(context, uri)

        // ---- Bit depth / color format, from a fresh bounds-only decode (no pixel data, cheap) ----
        val bitDepth = probeBitDepth(context, uri)

        // ---- Animation + frame count (API 28+ only — see class doc on the honest platform limitation) ----
        val animation = probeAnimation(context, uri, info.mimeType)

        // ---- URI permission state ----
        val readGranted = try {
            context.checkUriPermission(uri, Process.myPid(), Process.myUid(), Intent.FLAG_GRANT_READ_URI_PERMISSION) ==
                PackageManager.PERMISSION_GRANTED
        } catch (t: Throwable) {
            null
        }
        val persistable = try {
            context.contentResolver.persistedUriPermissions.any { it.uri == uri && it.isReadPermission }
        } catch (t: Throwable) {
            false
        }

        // ---- Alternate representations: inspect only what the provider already exposes, never invent a different Uri ----
        val alternateSummary = probeAlternateRepresentations(context, uri)

        val quality = AttachmentQualityClassifier.classify(info.widthPx, info.heightPx)

        val report = DiagnosticReport(
            uriString = uri.toString(),
            uriScheme = uri.scheme,
            uriAuthority = uri.authority,
            uriPath = uri.path,
            mimeReported = info.mimeType,
            mimeDetectedFromBytes = mimeFromBytes,
            fileExtension = extension,
            displayName = info.displayName,
            reportedSizeBytes = info.reportedSizeBytes,
            lastModifiedMillis = lastModified,
            widthPx = info.widthPx,
            heightPx = info.heightPx,
            hasAlpha = info.hasAlpha,
            exifOrientationRaw = if (info.exifRotationDegrees != 0 || info.mimeType == "image/jpeg" || info.mimeType == "image/heic") info.exifRotationDegrees else null,
            bitDepthDescription = bitDepth,
            isAnimated = animation.isAnimated,
            frameCount = animation.frameCount,
            previewSuspected = info.isLikelyPreview,
            previewReasons = explainPreviewSuspicion(info),
            classification = detailed.classification,
            classificationSignals = detailed.signals,
            stickerScore = detailed.stickerScore,
            photoScore = detailed.photoScore,
            uriReadable = uriReadable,
            streamReadable = streamReadable,
            bitmapDecodeSucceeded = decoded != null,
            decodedWidthPx = decoded?.bitmap?.width,
            decodedHeightPx = decoded?.bitmap?.height,
            readPermissionGranted = readGranted,
            persistablePermissionGranted = persistable,
            grantedVia = "ACTION_SEND share intent (this screen is only ever reached with a Uri received that way)",
            alternateRepresentationSummary = alternateSummary,
            quality = quality.quality,
            qualityReason = quality.reason,
        )

        return DiagnosticResult(report, decoded?.bitmap)
    }

    /**
     * Re-derives WHY [AttachmentInfo.isLikelyPreview] is true, using the
     * same conditions AttachmentInspector's (private) looksLikePreview
     * already applied — this mirrors those two checks for display purposes
     * only; it does not change or re-run detection, just explains the
     * boolean AttachmentInspector already computed.
     */
    private fun explainPreviewSuspicion(info: AttachmentInfo): List<String> {
        if (!info.isLikelyPreview) return emptyList()
        val reasons = mutableListOf<String>()
        if (info.widthPx in 1..64 || info.heightPx in 1..64) {
            reasons += "image dimensions are unusually small (${info.widthPx}x${info.heightPx})"
        }
        if (info.mimeType == "image/jpeg" && info.reportedSizeBytes in 1..3_000 && (info.widthPx > 128 || info.heightPx > 128)) {
            reasons += "suspiciously small JPEG (${info.reportedSizeBytes} bytes for ${info.widthPx}x${info.heightPx})"
        }
        if (reasons.isEmpty()) reasons += "flagged as likely preview"
        return reasons
    }

    private fun detectMimeFromMagicBytes(context: Context, uri: Uri): String? {
        return try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val header = ByteArray(16)
                val read = stream.read(header)
                if (read < 4) return null
                when {
                    header[0] == 0x89.toByte() && header[1] == 0x50.toByte() && header[2] == 0x4E.toByte() && header[3] == 0x47.toByte() -> "image/png"
                    header[0] == 0xFF.toByte() && header[1] == 0xD8.toByte() && header[2] == 0xFF.toByte() -> "image/jpeg"
                    read >= 12 && String(header, 0, 4, Charsets.US_ASCII) == "RIFF" && String(header, 8, 4, Charsets.US_ASCII) == "WEBP" -> "image/webp"
                    read >= 6 && (String(header, 0, 6, Charsets.US_ASCII) == "GIF87a" || String(header, 0, 6, Charsets.US_ASCII) == "GIF89a") -> "image/gif"
                    read >= 12 && String(header, 4, 4, Charsets.US_ASCII) == "ftyp" -> "image/heic"
                    else -> null
                }
            }
        } catch (t: Throwable) {
            null
        }
    }

    private fun queryLastModified(context: Context, uri: Uri): Long? {
        return try {
            val projection = arrayOf(DocumentsContract.Document.COLUMN_LAST_MODIFIED)
            context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
                val idx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED)
                if (idx >= 0 && cursor.moveToFirst() && !cursor.isNull(idx)) cursor.getLong(idx) else null
            }
        } catch (t: Throwable) {
            null
        }
    }

    private fun probeBitDepth(context: Context, uri: Uri): String? {
        return try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeStream(stream, null, opts)
                val config = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) opts.outConfig else null
                when (config) {
                    Bitmap.Config.ARGB_8888 -> "ARGB_8888 (32-bit)"
                    Bitmap.Config.RGB_565 -> "RGB_565 (16-bit)"
                    Bitmap.Config.ALPHA_8 -> "ALPHA_8 (8-bit)"
                    Bitmap.Config.RGBA_F16 -> "RGBA_F16 (64-bit)"
                    else -> null
                }
            }
        } catch (t: Throwable) {
            null
        }
    }

    private data class AnimationInfo(val isAnimated: Boolean?, val frameCount: Int?)

    private fun probeAnimation(context: Context, uri: Uri, mimeType: String?): AnimationInfo {
        // PNG/JPEG/HEIC don't support animation at all — no need to probe, and honestly certain either way.
        if (mimeType != null && mimeType != "image/gif" && mimeType != "image/webp") {
            return AnimationInfo(isAnimated = false, frameCount = if (mimeType.isNotBlank()) 1 else null)
        }
        // Animated WebP/GIF detection needs android.graphics.ImageDecoder, API 28+.
        // Below that there's no general platform API to determine this without a
        // heavier third-party decoder — honestly "Unknown" rather than guessing.
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            return AnimationInfo(isAnimated = null, frameCount = null)
        }
        return try {
            val source = ImageDecoder.createSource(context.contentResolver, uri)
            var isAnimated = false
            var frames: Int? = null
            val drawable = ImageDecoder.decodeDrawable(source) { decoder, _, _ ->
                decoder.isDecodeAsAlphaMaskAllowed = false
            }
            if (drawable is android.graphics.drawable.AnimatedImageDrawable) {
                isAnimated = true
                frames = try {
                    drawable.javaClass.getMethod("getNumberOfFrames").invoke(drawable) as? Int
                } catch (t: Throwable) {
                    null // not a stable public method on every OS version — best-effort only
                }
            }
            AnimationInfo(isAnimated = isAnimated, frameCount = frames)
        } catch (t: Throwable) {
            AnimationInfo(isAnimated = null, frameCount = null)
        }
    }

    /**
     * Reports only what the provider legitimately exposes about this exact
     * Uri — never a different/invented Uri. Checks: is this a
     * DocumentsContract document at all, does it advertise thumbnail
     * support via its FLAGS column, and what columns does the provider's
     * cursor expose beyond the basic OpenableColumns we already queried.
     */
    private fun probeAlternateRepresentations(context: Context, uri: Uri): String {
        val notes = mutableListOf<String>()
        try {
            val isDoc = DocumentsContract.isDocumentUri(context, uri)
            if (isDoc) {
                context.contentResolver.query(uri, arrayOf(DocumentsContract.Document.COLUMN_FLAGS), null, null, null)?.use { cursor ->
                    val idx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_FLAGS)
                    if (idx >= 0 && cursor.moveToFirst() && !cursor.isNull(idx)) {
                        val flags = cursor.getInt(idx)
                        if (flags and DocumentsContract.Document.FLAG_SUPPORTS_THUMBNAIL != 0) {
                            notes += "provider advertises FLAG_SUPPORTS_THUMBNAIL (a separate, smaller thumbnail may exist — does not imply a larger original is also available)"
                        }
                    }
                }
            }
            // Enumerate whatever columns the provider's cursor actually has, without
            // assuming any particular one means "higher quality available".
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val extraColumns = cursor.columnNames.filter {
                    it != android.provider.OpenableColumns.DISPLAY_NAME && it != android.provider.OpenableColumns.SIZE
                }
                if (extraColumns.isNotEmpty()) {
                    notes += "provider also exposes columns: ${extraColumns.joinToString(", ")}"
                }
            }
        } catch (t: Throwable) {
            // fall through to the default "none exposed" message below
        }
        return if (notes.isEmpty()) {
            "No alternate/full-quality representation exposed by provider."
        } else {
            notes.joinToString(" | ")
        }
    }
}
