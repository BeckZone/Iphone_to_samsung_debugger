package app.pigeonbridge.android.background

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.os.Build
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import app.pigeonbridge.android.MainActivity
import app.pigeonbridge.android.emoji.EmojiAssets

/**
 * Posts PigeonBridge's own notification showing an emoji-only message with PigeonBridge's
 * emoji artwork. This is the closest legitimate thing to "showing the processed result
 * without opening the app": the system draws a notification Android lets any app post.
 *
 * Rules it follows (see [ProcessedNotificationPlanner] for the decision side):
 *  - it is a SEPARATE notification titled "PigeonBridge: ...", never presented as Messages;
 *  - the messaging app's own notification is left alone (this class never cancels anything
 *    that it did not post itself);
 *  - silent, low-importance channel, so it never makes a sound or pops up over what you are doing;
 *  - not posted at all without the notification permission.
 */
object ProcessedEmojiNotifier {
    const val CHANNEL_ID = "pigeonbridge_processed_messages"
    private const val SIZE = 144

    /** @return true only if Android accepted the notification. */
    fun post(context: Context, plan: ProcessedNotificationPlan): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED
            ) return false
            if (!NotificationManagerCompat.from(context).areNotificationsEnabled()) return false

            ensureChannel(context)
            val picture = composite(context, plan.emojiFileKeys) ?: return false

            val open = PendingIntent.getActivity(
                context, 0,
                Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setContentTitle(plan.title)
                .setContentText(plan.text)
                .setSmallIcon(android.R.drawable.ic_menu_gallery)
                .setLargeIcon(picture)
                .setStyle(NotificationCompat.BigPictureStyle().bigPicture(picture).bigLargeIcon(null as Bitmap?))
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOnlyAlertOnce(true)
                .setSilent(true)
                .setAutoCancel(true)
                .setContentIntent(open)
                .build()
            NotificationManagerCompat.from(context).notify(plan.notificationId, notification)
            true
        } catch (_: Exception) {
            false // posting is best-effort; the diagnostics already recorded the message
        }
    }

    /** Draws the emoji images side by side into one bitmap. Null if no image could be loaded. */
    private fun composite(context: Context, fileKeys: List<String>): Bitmap? {
        val images = fileKeys.mapNotNull { EmojiAssets.bitmap(context, it)?.asAndroidBitmap() }
        if (images.isEmpty()) return null
        val out = Bitmap.createBitmap(SIZE * images.size, SIZE, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        images.forEachIndexed { i, bmp ->
            canvas.drawBitmap(bmp, null, Rect(i * SIZE, 0, (i + 1) * SIZE, SIZE), null)
        }
        return out
    }

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(CHANNEL_ID) == null) {
            val channel = NotificationChannel(CHANNEL_ID, "PigeonBridge emoji previews", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Optional: a silent PigeonBridge notification showing emoji-only messages with PigeonBridge's emoji artwork."
                setSound(null, null)
            }
            manager.createNotificationChannel(channel)
        }
    }
}
