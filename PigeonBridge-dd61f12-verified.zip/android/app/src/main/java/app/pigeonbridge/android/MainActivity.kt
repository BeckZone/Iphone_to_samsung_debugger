package app.pigeonbridge.android

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import app.pigeonbridge.android.ui.PigeonBridgeNavHost
import app.pigeonbridge.android.ui.theme.PigeonBridgeTheme

/**
 * Single-activity app (launchMode="singleTask" in the manifest) so that a
 * fresh App Link tap while the app is already open reuses this instance via
 * onNewIntent rather than stacking a second one.
 */
class MainActivity : ComponentActivity() {

    companion object {
        /** See PigeonBridgeNotificationListener -- launched when the user taps a "PigeonBridge processed a sticker" result notification. */
        const val ACTION_OPEN_PROCESSED_ATTACHMENT = "app.pigeonbridge.android.ACTION_OPEN_PROCESSED_ATTACHMENT"
    }

    // Holds the most recently received deep-link game id / shared-image uri
    // so Compose can react to it even when the intent arrives via
    // onNewIntent (app already running).
    private var pendingDeepLinkGameId: String? = null
    private var pendingSharedImageUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pendingDeepLinkGameId = extractGameId(intent)
        pendingSharedImageUri = extractSharedImage(intent) ?: extractProcessedAttachmentUri(intent)

        setContent {
            PigeonBridgeTheme {
                val navController = rememberNavController()
                currentNavController = navController
                LaunchedEffect(pendingDeepLinkGameId, pendingSharedImageUri) {
                    pendingDeepLinkGameId?.let { navigateToInvite(navController, it) }
                    pendingSharedImageUri?.let { navigateToShareReceiver(navController, it) }
                }
                PigeonBridgeNavHost(navController = navController)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        extractGameId(intent)?.let { gameId ->
            currentNavController?.let { navigateToInvite(it, gameId) }
        }
        (extractSharedImage(intent) ?: extractProcessedAttachmentUri(intent))?.let { uri ->
            currentNavController?.let { navigateToShareReceiver(it, uri) }
        }
    }

    // Simple holder so onNewIntent can reach the live NavController created in
    // onCreate's setContent block above.
    private var currentNavController: NavHostController? = null

    private fun navigateToInvite(navController: NavHostController, gameId: String) {
        navController.navigate("invite/$gameId")
    }

    private fun navigateToShareReceiver(navController: NavHostController, uri: Uri) {
        navController.navigate("share-receiver/${Uri.encode(uri.toString())}")
    }

    /**
     * Handles both verified App Link paths:
     *   https://pigeonbridge.app/g/{gameId}      (V2)
     *   https://pigeonbridge.app/join/{gameId}   (V1, kept for old invites)
     * and the pigeonbridge://g/{gameId} custom-scheme fallback.
     */
    private fun extractGameId(intent: Intent?): String? {
        val data: Uri = intent?.data ?: return null
        val segments = data.pathSegments
        if (data.scheme == "pigeonbridge" && data.host == "g") {
            return segments.firstOrNull()?.uppercase()
        }
        if (data.host == "pigeonbridge.app") {
            val idx = when {
                segments.getOrNull(0) == "g" -> 1
                segments.getOrNull(0) == "join" -> 1
                else -> return null
            }
            return segments.getOrNull(idx)?.uppercase()
        }
        return null
    }

    /**
     * Part 8 / Option C: the user tapped "PigeonBridge" in the share sheet
     * for an image — typically a GamePigeon attachment that arrived as a
     * picture. See ShareReceiverScreen for why we don't claim to identify
     * the game from this image (Part 9's documented limitation).
     */
    private fun extractSharedImage(intent: Intent?): Uri? {
        if (intent?.action != Intent.ACTION_SEND) return null
        if (intent.type?.startsWith("image/") != true) return null
        @Suppress("DEPRECATION")
        return intent.getParcelableExtra(Intent.EXTRA_STREAM) as? Uri
    }

    /**
     * See PigeonBridgeNotificationListener.postResultNotification -- the Uri it carries is our
     * own cached-or-verified attachment Uri, already safe to hand straight to ShareReceiverScreen's
     * existing pipeline (which handles decode failures gracefully rather than crashing regardless).
     *
     * Defense in depth: MainActivity is android:exported="true" (required for the launcher/App
     * Link/share intent-filters), so in principle another app could send this action with an
     * arbitrary Uri. Requiring a "content" scheme here doesn't grant that Uri any new access --
     * AttachmentInspector still only succeeds if this app was ALREADY independently granted read
     * access to it -- but it does reject obviously-wrong input before it ever reaches the pipeline.
     */
    private fun extractProcessedAttachmentUri(intent: Intent?): Uri? {
        if (intent?.action != ACTION_OPEN_PROCESSED_ATTACHMENT) return null
        val uri = intent.data ?: return null
        if (uri.scheme != "content") return null
        return uri
    }
}
