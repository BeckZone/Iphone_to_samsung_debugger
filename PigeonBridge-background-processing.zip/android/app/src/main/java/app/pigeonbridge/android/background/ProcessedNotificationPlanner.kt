package app.pigeonbridge.android.background

import app.pigeonbridge.android.messages.FeedMessage

enum class SkipReason {
    BACKGROUND_PROCESSING_OFF,
    PROCESSED_NOTIFICATIONS_OFF,
    NOT_EMOJI_ONLY,
    DUPLICATE,
    RATE_LIMITED,
}

/** What to show in a PigeonBridge-owned notification for an emoji-only message. */
data class ProcessedNotificationPlan(
    val notificationId: Int,
    val title: String,
    /** The ORIGINAL message text, unchanged. */
    val text: String,
    /** Image file keys (from the emoji asset index) to draw, in message order. */
    val emojiFileKeys: List<String>,
    val sender: String,
)

sealed class PlanResult {
    data class Post(val plan: ProcessedNotificationPlan) : PlanResult()
    data class Skip(val reason: SkipReason) : PlanResult()
}

/**
 * Decides whether an incoming message earns a separate PigeonBridge notification.
 *
 * Deliberately conservative, because the brief is "avoid notification spam":
 *  - only when the user switched it on (default off);
 *  - only for emoji-only messages (the case where a rendered image adds something);
 *  - never twice for the same message;
 *  - at most one per [minIntervalMillis], so a burst of emoji cannot flood the shade.
 *
 * It never decides to hide or cancel the messaging app's own notification: this class has no
 * way to express that, by design. The title always says "PigeonBridge" so the notification can
 * not be mistaken for one from Samsung/Google Messages.
 *
 * Pure Kotlin so the rules can be unit-tested.
 */
class ProcessedNotificationPlanner(
    private val minIntervalMillis: Long = 3_000L,
    private val maxRemembered: Int = 200,
) {
    private val lock = Any()
    private val seen = LinkedHashSet<String>()
    private var lastPostMillis: Long? = null

    fun plan(
        message: FeedMessage,
        emojiFileKeys: List<String>?,
        settings: BackgroundSettingsSnapshot,
        nowMillis: Long,
    ): PlanResult {
        if (!settings.backgroundProcessing) return PlanResult.Skip(SkipReason.BACKGROUND_PROCESSING_OFF)
        if (!settings.processedNotifications) return PlanResult.Skip(SkipReason.PROCESSED_NOTIFICATIONS_OFF)
        if (emojiFileKeys.isNullOrEmpty()) return PlanResult.Skip(SkipReason.NOT_EMOJI_ONLY)

        synchronized(lock) {
            if (!seen.add(message.key)) return PlanResult.Skip(SkipReason.DUPLICATE)
            while (seen.size > maxRemembered) {
                val oldest = seen.iterator()
                oldest.next()
                oldest.remove()
            }
            val last = lastPostMillis
            if (last != null && nowMillis - last < minIntervalMillis) {
                return PlanResult.Skip(SkipReason.RATE_LIMITED)
            }
            lastPostMillis = nowMillis
        }

        return PlanResult.Post(
            ProcessedNotificationPlan(
                // A small fixed range of ids per sender: a new emoji from the same person
                // replaces their previous one instead of stacking up.
                notificationId = BASE_NOTIFICATION_ID + (message.sender.hashCode() and 0x3F),
                title = "PigeonBridge: emoji from ${message.sender}",
                text = message.text,
                emojiFileKeys = emojiFileKeys,
                sender = message.sender,
            ),
        )
    }

    companion object {
        const val BASE_NOTIFICATION_ID = 4300
    }
}
