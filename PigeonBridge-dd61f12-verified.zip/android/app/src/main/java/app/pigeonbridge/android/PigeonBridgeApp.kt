package app.pigeonbridge.android

import android.app.Application
import android.content.Context
import android.os.Build
import coil.ImageLoader
import coil.decode.GifDecoder
import coil.decode.ImageDecoderDecoder

class PigeonBridgeApp : Application() {
    companion object {
        lateinit var instance: PigeonBridgeApp
            private set
    }

    /**
     * Shared Coil ImageLoader used to display recovered attachments
     * (StickerViewerScreen / ShareReceiverScreen). Registers animated
     * decoders so a genuinely animated WebP/GIF sticker actually animates
     * rather than showing a static first frame — API 28+ uses the
     * platform's ImageDecoder (handles animated WebP + GIF), older devices
     * fall back to Coil's own GifDecoder (GIF only; animated WebP has no
     * general decode path pre-API 28, so those fall back to a static first
     * frame there — an honest platform limitation, not a bug).
     */
    val imageLoader: ImageLoader by lazy {
        ImageLoader.Builder(this)
            .components {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    add(ImageDecoderDecoder.Factory())
                } else {
                    add(GifDecoder.Factory())
                }
            }
            .build()
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    fun prefs() = getSharedPreferences("pigeonbridge", Context.MODE_PRIVATE)
}
