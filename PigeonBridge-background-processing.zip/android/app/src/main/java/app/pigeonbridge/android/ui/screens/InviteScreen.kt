package app.pigeonbridge.android.ui.screens

import app.pigeonbridge.android.emoji.EmojiText
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.pigeonbridge.android.data.GamePeekDto
import app.pigeonbridge.android.ui.GameViewModel
import app.pigeonbridge.android.ui.PigeonCard
import app.pigeonbridge.android.ui.PrimaryButton
import app.pigeonbridge.android.ui.SecondaryButton
import kotlinx.coroutines.delay

/**
 * Two roles land here:
 *  - The HOST, right after CreateGameScreen — shows the share/copy card and
 *    polls until an opponent joins, then auto-advances to GameScreen.
 *  - A JOINER arriving via an App Link tap (MainActivity -> "invite/{gameId}")
 *    — shows "{host} invited you to play {game}" + a PLAY button, matching
 *    the spec's "Jacob invited you to play! [PLAY]" mockup.
 */
@Composable
fun InviteScreen(
    gameId: String,
    viewModel: GameViewModel,
    onPlay: () -> Unit,
    onBackToHome: () -> Unit,
) {
    val context = LocalContext.current
    var peek by remember { mutableStateOf<GamePeekDto?>(null) }
    var loadError by remember { mutableStateOf(false) }
    val isHost = viewModel.createResult.let { flow -> flow.value?.gameId == gameId }

    LaunchedEffect(gameId) {
        viewModel.peekGame(gameId) { result ->
            peek = result
            loadError = result == null
        }
    }

    // Host-side poll: flip straight to the game screen once someone joins,
    // mirroring web/src/home.ts's pollForOpponent.
    LaunchedEffect(gameId, isHost) {
        if (!isHost) return@LaunchedEffect
        while (true) {
            delay(2000)
            viewModel.peekGame(gameId) { result ->
                peek = result
                if (result?.hasSecondPlayer == true) onPlay()
            }
        }
    }

    Scaffold { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            when {
                loadError -> {
                    PigeonCard {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("🎮 PigeonBridge", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                            Text("This invite link has expired or is invalid.", modifier = Modifier.padding(vertical = 12.dp))
                            SecondaryButton("Back to home", onClick = onBackToHome)
                        }
                    }
                }
                peek == null -> Text("Loading…")
                isHost -> HostWaitingCard(gameId, peek!!, viewModel, context)
                else -> JoinerInviteCard(gameId, peek!!, viewModel, onPlay)
            }
        }
    }
}

@Composable
private fun HostWaitingCard(gameId: String, peek: GamePeekDto, viewModel: GameViewModel, context: Context) {
    val shareText = viewModel.createResult.value?.shareText
        ?: "🎮 Let's play ${peek.displayName}!\n\nTap here to play:\nhttps://pigeonbridge.app/g/$gameId"
    val joinUrl = viewModel.createResult.value?.joinUrl ?: "https://pigeonbridge.app/g/$gameId"

    PigeonCard {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            EmojiText(peek.displayName, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text("Waiting for opponent…", modifier = Modifier.padding(top = 4.dp, bottom = 16.dp))

            PrimaryButton("SEND INVITE") {
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, shareText)
                }
                context.startActivity(Intent.createChooser(intent, "Send PigeonBridge invite"))
            }
            Column(modifier = Modifier.padding(top = 10.dp)) {
                SecondaryButton("COPY LINK") {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("PigeonBridge invite", joinUrl))
                }
            }
            Text(
                "Invite code: $gameId",
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                modifier = Modifier.padding(top = 18.dp),
            )
        }
    }
}

@Composable
private fun JoinerInviteCard(gameId: String, peek: GamePeekDto, viewModel: GameViewModel, onPlay: () -> Unit) {
    var nickname by remember { mutableStateOf(viewModel.nickname) }

    PigeonCard {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            EmojiText(peek.displayName, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            EmojiText(
                "${peek.hostNickname ?: "Someone"} invited you to play!",
                modifier = Modifier.padding(top = 4.dp, bottom = 16.dp),
            )
            androidx.compose.material3.TextField(
                value = nickname,
                onValueChange = { nickname = it.take(20) },
                placeholder = { Text("Your nickname") },
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            )
            PrimaryButton("PLAY", enabled = nickname.isNotBlank()) {
                onPlay()
            }
        }
    }
}
