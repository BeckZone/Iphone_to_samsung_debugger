package app.pigeonbridge.android.ui.screens

import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.pigeonbridge.android.PigeonBridgeApp
import app.pigeonbridge.android.attachment.AttachmentBitmapDecoder
import app.pigeonbridge.android.attachment.AttachmentClassification
import app.pigeonbridge.android.attachment.AttachmentInfo
import app.pigeonbridge.android.attachment.AttachmentInspector
import app.pigeonbridge.android.attachment.ClassificationResult
import app.pigeonbridge.android.attachment.StickerDetector
import app.pigeonbridge.android.ui.PigeonCard
import app.pigeonbridge.android.ui.PrimaryButton
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Reached when the user taps "PigeonBridge" in Android's share sheet for an
 * image — originally built as the Option C fallback for a GamePigeon
 * attachment that rendered as a picture on Android instead of an
 * interactive game (see the GamePigeon-fallback branch below, which is
 * UNCHANGED from that original behavior).
 *
 * This screen now also runs a lightweight local pipeline
 * (AttachmentInspector -> StickerDetector) to tell the difference between
 * three cases, per the newer sticker-recovery spec:
 *  - LIKELY_STICKER: shows the dedicated sticker viewer (recovered image +
 *    quality/format metadata) below.
 *  - NORMAL_IMAGE or UNKNOWN (includes "couldn't tell, might be a GamePigeon
 *    board screenshot"): falls through to the EXACT original GamePigeon
 *    fallback content — unchanged, so nothing that worked before regressed.
 *    We do NOT attempt to detect a GamePigeon game from the image itself;
 *    that remains out of scope for the same reason as before (no game ID,
 *    player identity, or session state can be recovered from a picture, and
 *    guessing risks exactly the false-positive detection the spec
 *    prohibits).
 */
@Composable
fun ShareReceiverScreen(
    imageUri: String,
    onCreateGame: () -> Unit,
    onBackToHome: () -> Unit,
    onOpenDiagnostics: () -> Unit,
) {
    val context = LocalContext.current
    val uri = remember(imageUri) { Uri.parse(imageUri) }

    var info by remember { mutableStateOf<AttachmentInfo?>(null) }
    var classification by remember { mutableStateOf<ClassificationResult?>(null) }

    LaunchedEffect(imageUri) {
        val inspected = withContext(Dispatchers.IO) { AttachmentInspector.inspect(context, uri) }
        info = inspected
        classification = StickerDetector.classify(inspected)
    }

    val currentInfo = info
    val currentClassification = classification

    Scaffold(topBar = { TopAppBar(title = { Text("Shared image") }) }) { padding ->
        when {
            currentInfo == null || currentClassification == null -> {
                Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            currentClassification.classification == AttachmentClassification.LIKELY_STICKER -> {
                StickerViewerContent(
                    padding = padding,
                    uri = uri,
                    info = currentInfo,
                    onBackToHome = onBackToHome,
                    onOpenDiagnostics = onOpenDiagnostics,
                )
            }
            else -> {
                // Unchanged from the original implementation — see the class doc above.
                GamePigeonFallbackContent(
                    padding = padding,
                    uri = uri,
                    onCreateGame = onCreateGame,
                    onBackToHome = onBackToHome,
                    onOpenDiagnostics = onOpenDiagnostics,
                )
            }
        }
    }
}

// ---------------- New: sticker viewer ----------------

@Composable
private fun StickerViewerContent(
    padding: androidx.compose.foundation.layout.PaddingValues,
    uri: Uri,
    info: AttachmentInfo,
    onBackToHome: () -> Unit,
    onOpenDiagnostics: () -> Unit,
) {
    val context = LocalContext.current
    val animatable = info.mimeType == "image/gif" || info.mimeType == "image/webp"

    // Static formats get our own quality-preserving decode (see
    // AttachmentBitmapDecoder) so the on-screen dimensions provably match
    // what the metadata panel below claims. Animated formats go through
    // Coil (with the app's animation-capable ImageLoader) instead, since a
    // one-shot BitmapFactory decode would freeze them on frame one.
    var decodedBitmap by remember(uri) { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(null) }
    var decodeAttempted by remember(uri) { mutableStateOf(false) }

    LaunchedEffect(uri, animatable) {
        if (animatable) return@LaunchedEffect
        val result = withContext(Dispatchers.IO) { AttachmentBitmapDecoder.decode(context, uri, info) }
        decodedBitmap = result?.bitmap?.asImageBitmap()
        decodeAttempted = true
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        PigeonCard {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                        .clip(RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    if (animatable) {
                        AsyncImage(
                            model = uri,
                            imageLoader = PigeonBridgeApp.instance.imageLoader,
                            contentDescription = "Recovered sticker",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize(),
                        )
                    } else {
                        val bmp = decodedBitmap
                        if (bmp != null) {
                            Image(
                                bitmap = bmp,
                                contentDescription = "Recovered sticker",
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.fillMaxSize(),
                            )
                        } else if (decodeAttempted) {
                            Text("Couldn't decode this image", fontSize = 13.sp)
                        } else {
                            CircularProgressIndicator()
                        }
                    }
                }

                Text(
                    "Sticker recovered",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    modifier = Modifier.padding(top = 16.dp, bottom = 4.dp),
                )

                if (info.isLikelyPreview) {
                    Text(
                        "Only a low-resolution version was provided by the messaging system — this is the best quality available.",
                        fontSize = 13.sp,
                        color = androidx.compose.ui.graphics.Color(0xFFFBBF24),
                        modifier = Modifier.padding(bottom = 10.dp),
                    )
                }

                StickerMetadataRow("Dimensions", if (info.widthPx > 0) "${info.widthPx} × ${info.heightPx}px" else "Unknown")
                StickerMetadataRow("Format", info.mimeType ?: "Unknown")
                StickerMetadataRow("Transparency", if (info.hasAlpha == true) "Yes" else if (info.hasAlpha == false) "No" else "Unknown")
                StickerMetadataRow(
                    "Quality",
                    if (info.isLikelyPreview) "Preview / fallback only" else "Original attachment as received",
                )

                Column(modifier = Modifier.padding(top = 16.dp)) {
                    PrimaryButton("DONE") { onBackToHome() }
                }
                if (app.pigeonbridge.android.BuildConfig.DEBUG) {
                    androidx.compose.material3.TextButton(onClick = onOpenDiagnostics, modifier = Modifier.padding(top = 4.dp)) {
                        Text("🛠 View Diagnostics (debug build)", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun StickerMetadataRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween,
    ) {
        Text(label, fontSize = 13.sp, color = androidx.compose.ui.graphics.Color(0xFFA8A3C7))
        Text(value, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

// ---------------- Unchanged: original GamePigeon-image fallback ----------------

@Composable
private fun GamePigeonFallbackContent(
    padding: androidx.compose.foundation.layout.PaddingValues,
    uri: Uri,
    onCreateGame: () -> Unit,
    onBackToHome: () -> Unit,
    onOpenDiagnostics: () -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        PigeonCard {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                AsyncImage(
                    model = uri,
                    contentDescription = "Shared image",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(12.dp)),
                )
                Text(
                    "We can't tell which game this is",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    modifier = Modifier.padding(top = 16.dp),
                )
                Text(
                    "This looks like a GamePigeon image sent from an iPhone. Android can't open Apple's " +
                        "GamePigeon attachments directly, and a picture alone doesn't carry a game ID or " +
                        "session we could join — so we can't start or join a match from it.",
                    fontSize = 14.sp,
                    modifier = Modifier.padding(top = 8.dp, bottom = 18.dp),
                )
                Text(
                    "Ask your friend to send a PigeonBridge invite instead — or start one yourself and send it to them:",
                    fontSize = 13.sp,
                    modifier = Modifier.padding(bottom = 14.dp),
                )
                PrimaryButton("CREATE INVITE") { onCreateGame() }
            }
        }
        TextButton(onClick = onBackToHome) {
            Text("Back to home")
        }
        if (app.pigeonbridge.android.BuildConfig.DEBUG) {
            TextButton(onClick = onOpenDiagnostics) {
                Text("🛠 View Diagnostics (debug build)", fontSize = 12.sp)
            }
        }
    }
}
