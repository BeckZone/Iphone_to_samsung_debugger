import { test } from "node:test";
import assert from "node:assert/strict";
import { classifyDetailed, classifyQuality } from "../src/classifier.ts";

// Mirrors the Android StickerDetectorTest.kt cases -- the two
// implementations should agree since they share the same scoring rules.

test("normal JPEG classifies as normal image", () => {
  const r = classifyDetailed({ mimeType: "image/jpeg", displayName: null, widthPx: 3024, heightPx: 4032, hasAlpha: false, decodeFailed: false });
  assert.equal(r.classification, "NORMAL_IMAGE");
});

test("large opaque PNG screenshot is not classified as a sticker", () => {
  const r = classifyDetailed({ mimeType: "image/png", displayName: null, widthPx: 1080, heightPx: 2400, hasAlpha: false, decodeFailed: false });
  assert.equal(r.classification, "NORMAL_IMAGE");
});

test("small transparent PNG classifies as sticker", () => {
  const r = classifyDetailed({ mimeType: "image/png", displayName: null, widthPx: 200, heightPx: 200, hasAlpha: true, decodeFailed: false });
  assert.equal(r.classification, "LIKELY_STICKER");
});

test("small transparent WebP classifies as sticker", () => {
  const r = classifyDetailed({ mimeType: "image/webp", displayName: null, widthPx: 320, heightPx: 320, hasAlpha: true, decodeFailed: false });
  assert.equal(r.classification, "LIKELY_STICKER");
});

test("HEIC photo classifies as normal image", () => {
  const r = classifyDetailed({ mimeType: "image/heic", displayName: null, widthPx: 4032, heightPx: 3024, hasAlpha: false, decodeFailed: false });
  assert.equal(r.classification, "NORMAL_IMAGE");
});

test("large transparent PNG is never automatically a sticker", () => {
  const r = classifyDetailed({ mimeType: "image/png", displayName: null, widthPx: 2000, heightPx: 3000, hasAlpha: true, decodeFailed: false });
  assert.notEqual(r.classification, "LIKELY_STICKER");
});

test("decode failure classifies as unknown", () => {
  const r = classifyDetailed({ mimeType: null, displayName: null, widthPx: -1, heightPx: -1, hasAlpha: null, decodeFailed: true });
  assert.equal(r.classification, "UNKNOWN");
});

test("very large image classifies as normal image", () => {
  const r = classifyDetailed({ mimeType: "image/jpeg", displayName: null, widthPx: 6000, heightPx: 4000, hasAlpha: false, decodeFailed: false });
  assert.equal(r.classification, "NORMAL_IMAGE");
});

test("filename hint tips an ambiguous small opaque image toward sticker", () => {
  const r = classifyDetailed({ mimeType: "image/png", displayName: "imessage_sticker_042.png", widthPx: 128, heightPx: 128, hasAlpha: false, decodeFailed: false });
  assert.equal(r.classification, "LIKELY_STICKER");
});

test("animated GIF sticker classifies as sticker", () => {
  const r = classifyDetailed({ mimeType: "image/gif", displayName: null, widthPx: 240, heightPx: 240, hasAlpha: true, decodeFailed: false });
  assert.equal(r.classification, "LIKELY_STICKER");
});

test("score totals equal the sum of individual signal points", () => {
  const r = classifyDetailed({ mimeType: "image/webp", displayName: null, widthPx: 320, heightPx: 320, hasAlpha: true, decodeFailed: false });
  assert.equal(r.stickerScore, r.signals.reduce((s, sig) => s + sig.stickerPoints, 0));
  assert.equal(r.photoScore, r.signals.reduce((s, sig) => s + sig.photoPoints, 0));
});

// ---- Quality classifier ----

test("large dimensions classify as FULL_LARGE", () => {
  assert.equal(classifyQuality(1024, 1024).quality, "FULL_LARGE");
});

test("small dimensions classify as SMALL", () => {
  assert.equal(classifyQuality(128, 128).quality, "SMALL");
});

test("unknown dimensions classify as UNKNOWN, never guessed", () => {
  assert.equal(classifyQuality(-1, -1).quality, "UNKNOWN");
  assert.equal(classifyQuality(0, 0).quality, "UNKNOWN");
});

test("quality reason states actual dimensions, not a quality claim", () => {
  assert.equal(classifyQuality(128, 128).reason, "128 × 128");
});
