import { Router } from "express";
import { GAME_DISPLAY_NAMES, GAME_EMOJI, GameType } from "@pigeonbridge/shared";
import { sessionStore } from "../game/sessionStore";

const PUBLIC_BASE_URL = process.env.PUBLIC_BASE_URL || "https://pigeonbridge.app";
// Must match the applicationId in android/app/build.gradle.kts so the
// intent:// fallback below can hand off to the installed app correctly.
const ANDROID_PACKAGE = process.env.ANDROID_PACKAGE || "app.pigeonbridge.android";

export const inviteRouter = Router();

function escapeHtml(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

inviteRouter.get("/g/:gameId", (req, res) => {
  const gameId = req.params.gameId.toUpperCase();
  const session = sessionStore.get(gameId);

  if (!session) {
    res.status(404).send(renderPage({
      title: "Game not found — PigeonBridge",
      description: "This invitation has expired or doesn't exist.",
      ogImage: `${PUBLIC_BASE_URL}/api/og-image/generic.svg`,
      bodyHtml: `<div class="card"><h1>🎮 PigeonBridge</h1><p>This invite link has expired or is invalid.</p>
        <a class="btn" href="${PUBLIC_BASE_URL}">Start a new game</a></div>`,
      gameId,
      androidPackage: ANDROID_PACKAGE,
      skipAppLink: true,
    }));
    return;
  }

  const displayName = GAME_DISPLAY_NAMES[session.gameType];
  const emoji = GAME_EMOJI[session.gameType];
  const inviter = session.player1?.nickname ?? "Someone";
  const gameFull = !!(session.player1 && session.player2);

  const title = `${emoji} ${displayName} — PigeonBridge`;
  const description = gameFull
    ? `${inviter}'s ${displayName} game is already full.`
    : `${inviter} invited you to play ${displayName}.`;

  const bodyHtml = `
    <div class="card">
      <div class="emoji">${emoji}</div>
      <h1>${escapeHtml(displayName)}</h1>
      <p class="subtitle">${escapeHtml(inviter)} invited you to play!</p>
      ${
        gameFull
          ? `<p class="notice">This game already has two players.</p>`
          : `
        <input id="nickname" class="input" type="text" maxlength="20" placeholder="Your nickname" />
        <button id="playBtn" class="btn btn-primary">PLAY</button>
        <p id="statusMsg" class="status"></p>
      `
      }
    </div>
  `;

  res.send(
    renderPage({
      title,
      description,
      ogImage: `${PUBLIC_BASE_URL}/api/og-image/${session.gameType}.svg`,
      bodyHtml,
      gameId,
      androidPackage: ANDROID_PACKAGE,
      skipAppLink: gameFull,
      gameType: session.gameType,
    })
  );
});

/**
 * Simple generated SVG "card" per game type, used as the OG preview image.
 * SVG og:image support varies by messaging client — this is a clean, working
 * fallback that needs no image pipeline; swapping in designed PNGs later is a
 * drop-in change (just point ogImage at a static asset instead).
 */
inviteRouter.get("/api/og-image/:name", (req, res) => {
  const name = req.params.name.replace(/\.svg$/, "") as GameType | "generic";
  const emoji = name === "generic" ? "🎮" : GAME_EMOJI[name as GameType] ?? "🎮";
  const label = name === "generic" ? "PigeonBridge" : GAME_DISPLAY_NAMES[name as GameType] ?? "PigeonBridge";
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630">
    <defs>
      <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="#6d28d9"/>
        <stop offset="100%" stop-color="#2563eb"/>
      </linearGradient>
    </defs>
    <rect width="1200" height="630" fill="url(#bg)"/>
    <text x="600" y="300" font-size="180" text-anchor="middle" dominant-baseline="middle">${emoji}</text>
    <text x="600" y="460" font-size="64" font-family="sans-serif" font-weight="700" fill="white" text-anchor="middle">${escapeHtml(
      label
    )}</text>
    <text x="600" y="540" font-size="34" font-family="sans-serif" fill="#e0e7ff" text-anchor="middle">PigeonBridge</text>
  </svg>`;
  res.setHeader("Content-Type", "image/svg+xml");
  res.setHeader("Cache-Control", "public, max-age=3600");
  res.send(svg);
});

interface RenderOpts {
  title: string;
  description: string;
  ogImage: string;
  bodyHtml: string;
  gameId: string;
  androidPackage: string;
  skipAppLink?: boolean;
  gameType?: GameType;
}

function renderPage(opts: RenderOpts): string {
  const pageUrl = `${PUBLIC_BASE_URL}/g/${opts.gameId}`;
  // If PigeonBridge is installed, App Links (verified https intent-filter) should
  // open the app directly on tap with no interstitial — that's configured via
  // assetlinks.json + AndroidManifest.xml intent-filter (autoVerify="true"), not
  // JS. This intent:// fallback only fires for browsers/situations where the
  // verified App Link didn't take over (e.g. app link verification not yet
  // completed, or the user is in an in-app browser) — belt-and-suspenders, not
  // the primary mechanism.
  const intentFallback = opts.skipAppLink
    ? ""
    : `
    <script>
      (function () {
        var ua = navigator.userAgent || "";
        var isAndroid = /Android/i.test(ua);
        if (!isAndroid) return;
        var intentUrl = "intent://g/${opts.gameId}#Intent;scheme=https;package=${opts.androidPackage};S.browser_fallback_url=${encodeURIComponent(
          pageUrl
        )};end";
        // Give the verified App Link a chance first; only fall back to the
        // explicit intent:// if we're still here shortly after load (meaning
        // the OS didn't already hand off to the app).
        var attempted = false;
        window.addEventListener("blur", function () { attempted = true; });
        setTimeout(function () {
          if (!attempted) window.location.href = intentUrl;
        }, 400);
      })();
    </script>`;

  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
<title>${escapeHtml(opts.title)}</title>
<meta name="description" content="${escapeHtml(opts.description)}" />

<meta property="og:type" content="website" />
<meta property="og:title" content="${escapeHtml(opts.title)}" />
<meta property="og:description" content="${escapeHtml(opts.description)}" />
<meta property="og:image" content="${opts.ogImage}" />
<meta property="og:url" content="${pageUrl}" />
<meta property="og:site_name" content="PigeonBridge" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="${escapeHtml(opts.title)}" />
<meta name="twitter:description" content="${escapeHtml(opts.description)}" />
<meta name="twitter:image" content="${opts.ogImage}" />

<link rel="icon" href="data:,">
<style>
  :root {
    color-scheme: dark;
    --bg: #0f0b1e;
    --card: #1a1530;
    --primary: #7c3aed;
    --primary2: #4f46e5;
    --text: #f5f3ff;
    --muted: #a8a3c7;
  }
  * { box-sizing: border-box; }
  html, body { height: 100%; }
  body {
    margin: 0;
    background: radial-gradient(circle at top, #2a2150 0%, var(--bg) 65%);
    color: var(--text);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: env(safe-area-inset-top, 16px) 16px env(safe-area-inset-bottom, 16px);
  }
  .card {
    background: var(--card);
    border-radius: 24px;
    padding: 36px 28px;
    max-width: 400px;
    width: 100%;
    text-align: center;
    box-shadow: 0 20px 60px rgba(0,0,0,0.4);
  }
  .emoji { font-size: 64px; line-height: 1; margin-bottom: 8px; }
  h1 { font-size: 26px; margin: 8px 0 4px; }
  .subtitle { color: var(--muted); margin: 0 0 24px; font-size: 16px; }
  .input {
    width: 100%;
    padding: 14px 16px;
    border-radius: 14px;
    border: 1px solid #3a3360;
    background: #15102a;
    color: var(--text);
    font-size: 16px;
    margin-bottom: 12px;
  }
  .btn {
    display: block;
    width: 100%;
    padding: 16px;
    border-radius: 14px;
    border: none;
    font-size: 18px;
    font-weight: 700;
    letter-spacing: 0.02em;
    cursor: pointer;
    text-decoration: none;
    box-sizing: border-box;
  }
  .btn-primary {
    background: linear-gradient(135deg, var(--primary), var(--primary2));
    color: white;
  }
  .btn-primary:active { transform: scale(0.98); }
  .btn:not(.btn-primary) { background: #2a2450; color: var(--text); }
  .status { min-height: 20px; color: var(--muted); font-size: 14px; margin-top: 12px; }
  .notice { color: #fbbf24; }
</style>
</head>
<body>
${opts.bodyHtml}
${intentFallback}
<script>
(function () {
  var playBtn = document.getElementById("playBtn");
  if (!playBtn) return;
  var gameId = "${opts.gameId}";
  var statusEl = document.getElementById("statusMsg");
  var nickInput = document.getElementById("nickname");
  var STORAGE_KEY = "pigeonbridge_nickname";
  try {
    var saved = localStorage.getItem(STORAGE_KEY);
    if (saved) nickInput.value = saved;
  } catch (e) {}

  playBtn.addEventListener("click", function () {
    var nickname = (nickInput.value || "").trim();
    if (!nickname) { statusEl.textContent = "Enter a nickname to join."; return; }
    try { localStorage.setItem(STORAGE_KEY, nickname); } catch (e) {}
    statusEl.textContent = "Connecting...";
    // Hands off to the SPA game screen, which owns the WebSocket connection
    // and per-game board rendering (see web/src/play.ts).
    window.location.href = "/play?gameId=" + encodeURIComponent(gameId) + "&nickname=" + encodeURIComponent(nickname);
  });
})();
</script>
</body>
</html>`;
}
