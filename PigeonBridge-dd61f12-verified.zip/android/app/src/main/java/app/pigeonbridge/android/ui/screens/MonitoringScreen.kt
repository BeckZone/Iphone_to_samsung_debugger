package app.pigeonbridge.android.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.pigeonbridge.android.monitoring.DefaultSmsRoleHelper
import app.pigeonbridge.android.monitoring.MonitoringState
import app.pigeonbridge.android.ui.PigeonCard
import app.pigeonbridge.android.ui.PrimaryButton
import app.pigeonbridge.android.ui.SecondaryButton
import app.pigeonbridge.android.ui.theme.PBAccent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * The status/control screen. Every ON/OFF and every "Last ..." value here
 * reflects a REAL, queried system/app state each time this screen appears
 * (or after "Run Notification Test"/role-request return) -- never assumed.
 */
@Composable
fun MonitoringScreen(onBack: () -> Unit, onOpenNotificationTest: (() -> Unit)? = null) {
    val context = LocalContext.current
    var refreshTick by remember { mutableStateOf(0) }
    var monitoringEnabled by remember { mutableStateOf(MonitoringState.monitoringEnabled) }

    val notificationAccessGranted = remember(refreshTick) { MonitoringState.notificationAccessGranted(context) }
    val listenerActive = remember(refreshTick) { MonitoringState.listenerServiceActive() }
    val smsRoleSupported = remember { DefaultSmsRoleHelper.isSupported(context) }
    val smsRoleHeld = remember(refreshTick) { DefaultSmsRoleHelper.isRoleHeld(context) }
    val lastEvent = remember(refreshTick) { MonitoringState.lastAttachmentEvent() }

    val smsRoleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        refreshTick++
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Background Monitoring") }) }) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
            PigeonCard {
                Column {
                    Text("MONITORING STATUS", fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp))
                    StatusRow("Notification access", if (notificationAccessGranted) "Enabled" else "Disabled", notificationAccessGranted)
                    StatusRow("Listener service state", if (listenerActive) "Active" else "Not observed", listenerActive)
                    StatusRow(
                        "Last relevant notification",
                        lastEvent?.notificationTimestampMillis?.let { formatTimestamp(it) } ?: "None yet",
                        lastEvent != null,
                    )
                    StatusRow("Last package", lastEvent?.messagingPackage ?: "None yet", lastEvent != null)
                    StatusRow(
                        "Last extraction result",
                        lastEvent?.let { if (it.extractionSucceeded) "Success" else "Failure" } ?: "N/A",
                        lastEvent?.extractionSucceeded == true,
                    )
                    StatusRow(
                        "Last attachment result",
                        lastEvent?.let {
                            when {
                                !it.attachmentExposed -> "Not exposed"
                                it.attachmentUriAvailable -> "Readable"
                                else -> "Unreadable / preview only"
                            }
                        } ?: "N/A",
                        lastEvent?.attachmentUriAvailable == true,
                    )
                    StatusRow(
                        "Last processing result",
                        lastEvent?.let { if (it.extractionSucceeded) "Processed" else "Not processed" } ?: "N/A",
                        lastEvent?.extractionSucceeded == true,
                    )
                    StatusRow("Default SMS role", if (smsRoleHeld) "Enabled" else "Disabled", smsRoleHeld)
                }
            }

            Column(modifier = Modifier.padding(top = 16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(if (monitoringEnabled) "Disable Monitoring" else "Enable Monitoring", fontSize = 15.sp)
                    Switch(
                        checked = monitoringEnabled,
                        onCheckedChange = {
                            monitoringEnabled = it
                            MonitoringState.monitoringEnabled = it
                        },
                    )
                }
            }

            Column(modifier = Modifier.padding(top = 16.dp)) {
                SecondaryButton("Open Notification Access Settings") {
                    context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                }
                Text(
                    "Required so PigeonBridge can see when a messaging notification arrives -- this is a system-level grant, not a PigeonBridge permission. PigeonBridge only reads notifications from Samsung/Google Messages, never any other app.",
                    fontSize = 12.sp,
                    color = Color(0xFFA8A3C7),
                    modifier = Modifier.padding(top = 6.dp, bottom = 16.dp),
                )
            }

            if (smsRoleSupported) {
                Column {
                    SecondaryButton(if (smsRoleHeld) "SMS role already held" else "Request SMS Role") {
                        DefaultSmsRoleHelper.createRequestIntent(context)?.let { smsRoleLauncher.launch(it) }
                        MonitoringState.smsRoleRequestedOnce = true
                    }
                    Text(
                        "This only affects standard SMS/MMS -- it does NOT guarantee access to RCS stickers, and replaces Samsung Messages as your default texting app. PigeonBridge does not implement a full SMS app, so your device may report this isn't available. See Diagnostics for details.",
                        fontSize = 12.sp,
                        color = Color(0xFFFBBF24),
                        modifier = Modifier.padding(top = 6.dp, bottom = 16.dp),
                    )
                }
            }

            onOpenNotificationTest?.let {
                Column(modifier = Modifier.padding(bottom = 10.dp)) {
                    SecondaryButton("Run Notification Test") { it() }
                }
            }

            Column(modifier = Modifier.padding(bottom = 10.dp)) {
                SecondaryButton("Clear Monitoring History") {
                    MonitoringState.clearMonitoringHistory()
                    refreshTick++
                }
                Text(
                    "Clears only PigeonBridge's own diagnostic history -- never touches messages, notifications, or files belonging to any other app.",
                    fontSize = 11.sp,
                    color = Color(0xFFA8A3C7),
                    modifier = Modifier.padding(top = 4.dp),
                )
            }

            Column(modifier = Modifier.padding(top = 8.dp)) {
                PrimaryButton("BACK") { onBack() }
            }
        }
    }
}

@Composable
private fun StatusRow(label: String, value: String, positive: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween,
    ) {
        Text(label, fontSize = 13.sp)
        Text(
            value,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = if (positive) PBAccent else Color(0xFFA8A3C7),
        )
    }
}

private fun formatTimestamp(millis: Long): String {
    return try {
        SimpleDateFormat("MMM d, HH:mm:ss", Locale.US).format(Date(millis))
    } catch (_: Exception) {
        millis.toString()
    }
}
