// Central constants shared by server, web, and (conceptually) the Android client.
// Android can't import this TS file directly, but its Kotlin GameType/constants
// mirror these 1:1 (see android/.../data/Models.kt) — keep both in sync by hand.

export const GAME_TYPES = [
  "checkers",
  "darts",
  "chess",
  "cup_pong",
  "basketball",
  "eight_ball_pool",
] as const;

export type GameType = (typeof GAME_TYPES)[number];

// Games with a full server-authoritative rules engine wired up in Phase 1.
// The rest are registered (show up in "choose game", have a lobby/session)
// but the game screen shows a "not implemented yet" state instead of a board.
// Games with a full server-authoritative rules engine wired up.
// All six are implemented — see shared/src/games/*.ts.
export const IMPLEMENTED_GAMES: readonly GameType[] = [
  "checkers",
  "darts",
  "chess",
  "cup_pong",
  "basketball",
  "eight_ball_pool",
];

export const GAME_DISPLAY_NAMES: Record<GameType, string> = {
  checkers: "Checkers",
  darts: "Darts",
  chess: "Chess",
  cup_pong: "Cup Pong",
  basketball: "Basketball",
  eight_ball_pool: "8-Ball Pool",
};

export const GAME_ID_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no 0/O/1/I
export const GAME_ID_LENGTH = 6;

export const MAX_NICKNAME_LENGTH = 20;
export const MIN_NICKNAME_LENGTH = 1;

export const GAME_ABANDON_TIMEOUT_MS = 30 * 60 * 1000; // 30 min no activity -> expire
export const RECONNECT_GRACE_MS = 2 * 60 * 1000; // player has 2 min to reconnect before forfeit

export const WS_RATE_LIMIT_MESSAGES_PER_10S = 40;

// WebSocket message type discriminators (client<->server)
export const WS_CLIENT_MSG = {
  JOIN: "join",
  MAKE_MOVE: "make_move",
  REQUEST_REMATCH: "request_rematch",
  LEAVE: "leave",
  PING: "ping",
} as const;

export const WS_SERVER_MSG = {
  JOINED: "joined",
  STATE_UPDATE: "state_update",
  OPPONENT_JOINED: "opponent_joined",
  OPPONENT_LEFT: "opponent_left",
  OPPONENT_DISCONNECTED: "opponent_disconnected",
  OPPONENT_RECONNECTED: "opponent_reconnected",
  REMATCH_OFFERED: "rematch_offered",
  REMATCH_STARTED: "rematch_started",
  GAME_OVER: "game_over",
  ERROR: "error",
  PONG: "pong",
} as const;
