package app.pigeonbridge.android.attachment

import android.content.ContentResolver
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import androidx.exifinterface.media.ExifInterface

/**
 * Reads what Android's ContentResolver can legitimately tell us about a
 * shared attachment Uri — no root, no private-API access, only documented
 * ContentResolver/BitmapFactory/ExifInterface APIs against a Uri the OS
 * already granted this app read access to (via the ACTION_SEND intent's
 * URI permission grant — see MainActivity.extractSharedImage).
 *
 * Every step here operates on Uris Android exposes through
 * `content://...` and opens them via ContentResolver.openInputStream, each
 * wrapped in `use { }` so the stream is always closed, including on an
 * exception — that's the full extent of "safe stream handling" this needs,
 * since we don't own the underlying file descriptor's lifecycle beyond
 * this call.
 */
object AttachmentInspector {

    /** Small-image decode budget: enough for essentially any real sticker without loading a full-size photo into memory just to check alpha. */
    private const val ALPHA_PROBE_MAX_DIMENSION = 512

    fun inspect(context: Context, uri: Uri): AttachmentInfo {
        val resolver = context.contentResolver

        val (displayName, reportedSize) = queryOpenableMetadata(resolver, uri)
        val mimeType = resolveMimeType(resolver, uri, displayName)

        val bounds = decodeBounds(resolver, uri)
        val exifRotation = readExifOrientation(resolver, uri, mimeType)
        val hasAlpha = if (bounds.decodeFailed) null else probeAlpha(resolver, uri, bounds.width, bounds.height)

        val decodeFailed = bounds.decodeFailed
        val isLikelyPreview = !decodeFailed && looksLikePreview(
            widthPx = bounds.width,
            heightPx = bounds.height,
            reportedSizeBytes = reportedSize,
            mimeType = mimeType,
        )

        val info = AttachmentInfo(
            mimeType = mimeType,
            displayName = displayName,
            reportedSizeBytes = reportedSize,
            widthPx = bounds.width,
            heightPx = bounds.height,
            hasAlpha = hasAlpha,
            exifRotationDegrees = exifRotation,
            isLikelyPreview = isLikelyPreview,
            decodeFailed = decodeFailed,
            decodePath = bounds.decodePath,
        )
        AttachmentDebugLog.logInspection(uri, info)
        return info
    }

    // ---- OpenableColumns: display name + reported size ----

    private fun queryOpenableMetadata(resolver: ContentResolver, uri: Uri): Pair<String?, Long> {
        var name: String? = null
        var size: Long = -1
        try {
            resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIdx >= 0) name = cursor.getString(nameIdx)
                    if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) size = cursor.getLong(sizeIdx)
                }
            }
        } catch (t: Throwable) {
            AttachmentDebugLog.logError("queryOpenableMetadata", uri, t)
        }
        return name to size
    }

    // ---- MIME type: ContentResolver first (authoritative for content:// URIs), filename extension as a fallback ----

    private fun resolveMimeType(resolver: ContentResolver, uri: Uri, displayName: String?): String? {
        resolver.getType(uri)?.let { return it }
        val ext = displayName?.substringAfterLast('.', "")?.lowercase()
        return when (ext) {
            "png" -> "image/png"
            "jpg", "jpeg" -> "image/jpeg"
            "webp" -> "image/webp"
            "heic" -> "image/heic"
            "heif" -> "image/heif"
            "gif" -> "image/gif"
            else -> null
        }
    }

    // ---- Bounds decode: inJustDecodeBounds=true never allocates pixel memory, so this is cheap even for a huge photo (test case #9) ----

    private data class BoundsResult(val width: Int, val height: Int, val decodeFailed: Boolean, val decodePath: String)

    private fun decodeBounds(resolver: ContentResolver, uri: Uri): BoundsResult {
        return try {
            resolver.openInputStream(uri)?.use { stream ->
                val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeStream(stream, null, opts)
                if (opts.outWidth > 0 && opts.outHeight > 0) {
                    BoundsResult(opts.outWidth, opts.outHeight, decodeFailed = false, decodePath = "BitmapFactory.decodeStream(bounds)")
                } else {
                    BoundsResult(-1, -1, decodeFailed = true, decodePath = "BitmapFactory.decodeStream(bounds) -> no dimensions (corrupt/unsupported)")
                }
            } ?: BoundsResult(-1, -1, decodeFailed = true, decodePath = "openInputStream() returned null")
        } catch (t: Throwable) {
            AttachmentDebugLog.logError("decodeBounds", uri, t)
            BoundsResult(-1, -1, decodeFailed = true, decodePath = "exception: ${t.javaClass.simpleName}")
        }
    }

    // ---- Alpha probe: decode at a small, memory-safe sample size purely to check for transparency, never the full image ----

    private fun probeAlpha(resolver: ContentResolver, uri: Uri, fullWidth: Int, fullHeight: Int): Boolean? {
        if (fullWidth <= 0 || fullHeight <= 0) return null
        val sampleSize = computeSampleSize(fullWidth, fullHeight, ALPHA_PROBE_MAX_DIMENSION)
        return try {
            resolver.openInputStream(uri)?.use { stream ->
                val opts = BitmapFactory.Options().apply {
                    inSampleSize = sampleSize
                    inPreferredConfig = Bitmap.Config.ARGB_8888 // must decode with an alpha channel to detect one at all
                }
                val bmp = BitmapFactory.decodeStream(stream, null, opts)
                val alpha = bmp?.hasAlpha()
                bmp?.recycle()
                alpha
            }
        } catch (t: Throwable) {
            AttachmentDebugLog.logError("probeAlpha", uri, t)
            null
        }
    }

    // ---- EXIF orientation (JPEG/HEIF carry this; PNG/WebP generally don't, ExifInterface simply reports "normal" for those) ----

    private fun readExifOrientation(resolver: ContentResolver, uri: Uri, mimeType: String?): Int {
        // Only JPEG and HEIF/HEIC realistically carry EXIF orientation; skip the
        // attempt for other types rather than opening a stream ExifInterface
        // can't do anything useful with.
        if (mimeType != null && mimeType != "image/jpeg" && mimeType != "image/heic" && mimeType != "image/heif") return 0
        return try {
            resolver.openInputStream(uri)?.use { stream ->
                val exif = ExifInterface(stream)
                when (exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270
                    else -> 0
                }
            } ?: 0
        } catch (t: Throwable) {
            AttachmentDebugLog.logError("readExifOrientation", uri, t)
            0
        }
    }

    // ---- "Is this probably only a low-quality preview?" heuristic ----

    /**
     * Best-effort, intentionally conservative signal that Android (or the
     * app that shared this Uri) only exposed a placeholder/preview rather
     * than the real attachment. There is no general Android API to ask
     * "give me the higher-quality version instead" for an arbitrary
     * content:// Uri from another app — the sending app decides what Uri to
     * put in EXTRA_STREAM, and this is the only Uri we're ever given. So
     * this function does not (and cannot) go fetch a better version; it
     * only flags when what we *did* receive looks suspiciously low-res, so
     * the UI can say so honestly instead of presenting it as full quality
     * (spec Part 10).
     */
    private fun looksLikePreview(widthPx: Int, heightPx: Int, reportedSizeBytes: Long, mimeType: String?): Boolean {
        if (widthPx <= 0 || heightPx <= 0) return false
        val tinyDimensions = widthPx <= 64 || heightPx <= 64
        // A JPEG under ~3KB at more than trivial dimensions is almost always a
        // heavily-recompressed thumbnail, not a real photo/sticker.
        val suspiciouslySmallForJpeg = mimeType == "image/jpeg" && reportedSizeBytes in 1..3_000 && (widthPx > 128 || heightPx > 128)
        return tinyDimensions || suspiciouslySmallForJpeg
    }

    private fun computeSampleSize(width: Int, height: Int, maxDimension: Int): Int {
        var sample = 1
        var w = width
        var h = height
        while (w / 2 >= maxDimension || h / 2 >= maxDimension) {
            w /= 2
            h /= 2
            sample *= 2
        }
        return sample
    }
}
