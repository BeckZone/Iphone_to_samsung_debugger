// Minimal service worker whose only real job is handling the Web Share
// Target POST (see manifest.webmanifest's "share_target"). This is what
// lets Android Chrome's native share sheet offer "PigeonBridge" once this
// site is installed as a PWA -- the browser-legitimate equivalent of the
// Android app's ACTION_SEND handling, using a standard web API instead of
// an Android intent filter. Not supported by iOS Safari -- see the app's
// "What this can and can't do" panel, which states that plainly.
const SHARE_CACHE = "pigeonbridge-share-v1";

self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (event) => event.waitUntil(self.clients.claim()));

self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);
  if (event.request.method === "POST" && url.pathname === "/share-target") {
    event.respondWith(handleShareTarget(event.request));
  }
});

async function handleShareTarget(request) {
  try {
    const formData = await request.formData();
    const file = formData.get("file");
    if (file && file instanceof File) {
      const cache = await caches.open(SHARE_CACHE);
      await cache.put(
        "/shared-file",
        new Response(file, { headers: { "Content-Type": file.type || "application/octet-stream", "X-File-Name": file.name || "" } }),
      );
    }
  } catch {
    // fall through to the redirect regardless -- the page will just show "no file received"
  }
  return Response.redirect("/?shared=1", 303);
}
