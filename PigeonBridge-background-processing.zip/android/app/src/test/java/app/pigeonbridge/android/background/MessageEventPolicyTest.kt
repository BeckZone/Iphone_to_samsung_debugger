package app.pigeonbridge.android.background

import org.junit.Assert.assertEquals
import org.junit.Test

/** Which notifications PigeonBridge looks at, and which it ignores entirely. */
class MessageEventPolicyTest {

    private val samsung = "com.samsung.android.messaging"
    private val google = "com.google.android.apps.messaging"

    @Test
    fun samsungMessagesIsProcessed() =
        assertEquals(EventGate.PROCESS, MessageEventPolicy.gate(samsung, true))

    @Test
    fun googleMessagesIsProcessed() =
        assertEquals(EventGate.PROCESS, MessageEventPolicy.gate(google, true))

    @Test
    fun unrelatedAppsAreIgnored() {
        for (pkg in listOf("com.example.bank", "com.whatsapp", "com.android.systemui", "")) {
            assertEquals(pkg, EventGate.IGNORE_UNRELATED_APP, MessageEventPolicy.gate(pkg, true))
        }
    }

    @Test
    fun pigeonBridgeOwnNotificationsAreIgnored() =
        // Our own processed notifications must never be fed back into the pipeline.
        assertEquals(EventGate.IGNORE_UNRELATED_APP, MessageEventPolicy.gate("app.pigeonbridge.android", true))

    @Test
    fun backgroundOffStopsSupportedApps() {
        assertEquals(EventGate.IGNORE_BACKGROUND_OFF, MessageEventPolicy.gate(samsung, false))
        assertEquals(EventGate.IGNORE_BACKGROUND_OFF, MessageEventPolicy.gate(google, false))
    }

    @Test
    fun unrelatedIsCheckedBeforeBackgroundSwitch() =
        // An unrelated app is "unrelated" whatever the switch says, so it is never even recorded.
        assertEquals(EventGate.IGNORE_UNRELATED_APP, MessageEventPolicy.gate("com.example.bank", false))

    @Test
    fun defaultsAreSafe() {
        val d = BackgroundSettingsSnapshot()
        assertEquals(true, d.backgroundProcessing)
        assertEquals(false, d.processedNotifications) // opt-in: no surprise notifications
    }
}
