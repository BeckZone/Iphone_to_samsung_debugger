package app.pigeonbridge.android.ui.screens

import app.pigeonbridge.android.emoji.EmojiText
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.pigeonbridge.android.network.GameConnectionState
import app.pigeonbridge.android.data.NATIVE_COMPOSE_GAMES
import app.pigeonbridge.android.ui.GameViewModel
import app.pigeonbridge.android.ui.PrimaryButton
import app.pigeonbridge.android.ui.SecondaryButton
import app.pigeonbridge.android.ui.theme.PBAccent
import app.pigeonbridge.android.ui.theme.PBSurfaceVariant
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.TopAppBar
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.int
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

@Composable
fun GameScreen(
    gameId: String,
    viewModel: GameViewModel,
    onLeave: () -> Unit,
) {
    // We need the game type BEFORE deciding how to play it: native games
    // (checkers/darts) connect through the shared GameViewModel socket;
    // WebView games (chess/basketball/cup_pong/eight_ball_pool) embed the
    // same /play page the browser uses and own their own connection inside
    // the WebView's JS — so we must not also open a second native socket
    // for those, or two connections would race for the same player slot.
    var resolvedGameType by remember { mutableStateOf<String?>(null) }
    var peekFailed by remember { mutableStateOf(false) }

    LaunchedEffect(gameId) {
        viewModel.peekGame(gameId) { peek ->
            if (peek == null) peekFailed = true else resolvedGameType = peek.gameType
        }
    }

    when {
        peekFailed -> {
            Scaffold { padding ->
                Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                    Text("Couldn't load this game — it may have expired.")
                }
            }
        }
        resolvedGameType == null -> {
            Scaffold { padding ->
                Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                    Text("Loading…")
                }
            }
        }
        NATIVE_COMPOSE_GAMES.any { it.wireValue == resolvedGameType } -> {
            NativeGameScreen(gameId = gameId, viewModel = viewModel, onLeave = onLeave)
        }
        else -> {
            WebViewGameScreen(gameId = gameId, viewModel = viewModel, onLeave = onLeave)
        }
    }
}

@Composable
private fun NativeGameScreen(
    gameId: String,
    viewModel: GameViewModel,
    onLeave: () -> Unit,
) {
    val session by viewModel.session.collectAsState()
    val connection by viewModel.connection.collectAsState()
    var statusText by remember { mutableStateOf("Connecting…") }

    LaunchedEffect(gameId) {
        viewModel.connectAndJoin(gameId, viewModel.nickname)
    }

    DisposableEffect(gameId) {
        onDispose { /* socket lifetime is owned by the ViewModel; nothing to clean up per-screen */ }
    }

    LaunchedEffect(connection) {
        statusText = when (val c = connection) {
            is GameConnectionState.OpponentDisconnected -> "Opponent disconnected — waiting up to ${c.graceMs / 1000}s…"
            GameConnectionState.OpponentReconnected -> "Opponent reconnected."
            GameConnectionState.OpponentLeft -> "Opponent left the game."
            is GameConnectionState.RematchOffered -> if (c.bySlot != viewModel.mySlot()) "Opponent wants a rematch." else statusText
            is GameConnectionState.Error -> "⚠️ ${c.message}"
            else -> statusText
        }
    }

    val mySlot = viewModel.mySlot()
    val currentSession = session

    Scaffold { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(12.dp)) {
            if (currentSession == null) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Connecting…")
                }
                return@Scaffold
            }

            val gameType = currentSession["gameType"]?.jsonPrimitive?.content ?: ""
            val status = currentSession["status"]?.jsonPrimitive?.content ?: ""
            val currentTurn = currentSession["currentTurn"]?.jsonPrimitive?.content ?: ""
            val p1 = currentSession["player1"] as? JsonObject
            val p2 = currentSession["player2"] as? JsonObject

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                PlayerLabel(p1?.get("nickname")?.jsonPrimitive?.content ?: "Waiting…", active = currentTurn == "player1" && status == "in_progress")
                Text("vs", modifier = Modifier.padding(top = 8.dp))
                PlayerLabel(p2?.get("nickname")?.jsonPrimitive?.content ?: "Waiting…", active = currentTurn == "player2" && status == "in_progress")
            }

            val yourTurn = currentTurn == mySlot && status == "in_progress"
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp)
                    .background(
                        if (yourTurn) PBAccent.copy(alpha = 0.25f) else PBSurfaceVariant,
                        RoundedCornerShape(12.dp),
                    )
                    .padding(10.dp),
                contentAlignment = Alignment.Center,
            ) {
                EmojiText(
                    when {
                        status == "waiting_for_opponent" -> "Waiting for opponent to join…"
                        status == "in_progress" -> if (yourTurn) "Your turn" else "Opponent's turn"
                        status == "draw" -> "It's a draw!"
                        status == "player1_won" -> if (mySlot == "player1") "🎉 You won!" else "You lost — good game."
                        status == "player2_won" -> if (mySlot == "player2") "🎉 You won!" else "You lost — good game."
                        else -> "Game ended."
                    },
                    fontWeight = FontWeight.Bold,
                )
            }

            Box(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                when (gameType) {
                    "checkers" -> CheckersBoard(
                        session = currentSession,
                        mySlot = mySlot,
                        canMove = yourTurn,
                        onMove = { fromRow, fromCol, toRow, toCol ->
                            viewModel.makeMove(
                                gameId,
                                buildJsonObject {
                                    put("fromRow", JsonPrimitive(fromRow))
                                    put("fromCol", JsonPrimitive(fromCol))
                                    put("toRow", JsonPrimitive(toRow))
                                    put("toCol", JsonPrimitive(toCol))
                                },
                            )
                        },
                    )
                    "darts" -> DartsBoard(
                        session = currentSession,
                        mySlot = mySlot,
                        canThrow = yourTurn,
                        onSubmitTurn = { throwsJson ->
                            viewModel.makeMove(gameId, buildJsonObject { put("throws", throwsJson) })
                        },
                    )
                    else -> EmojiText(
                        "🚧 ${gameType.replace('_', ' ')} isn't playable yet in this MVP.\nCheckers and Darts are fully working.",
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    )
                }
            }

            if (statusText.isNotBlank()) {
                EmojiText(statusText, fontSize = 13.sp, modifier = Modifier.padding(vertical = 6.dp))
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(modifier = Modifier.weight(1f)) {
                    SecondaryButton("LEAVE") {
                        viewModel.leave(gameId)
                        onLeave()
                    }
                }
                if (status != "in_progress" && status != "waiting_for_opponent") {
                    Box(modifier = Modifier.weight(1f)) {
                        PrimaryButton("REMATCH") { viewModel.requestRematch(gameId) }
                    }
                }
            }
        }
    }
}

@Composable
private fun PlayerLabel(name: String, active: Boolean) {
    EmojiText(name, fontWeight = FontWeight.Bold, color = if (active) PBAccent else Color.White, fontSize = 14.sp)
}

// ---------------- Checkers ----------------

@Composable
private fun CheckersBoard(
    session: JsonObject,
    mySlot: String?,
    canMove: Boolean,
    onMove: (Int, Int, Int, Int) -> Unit,
) {
    val board = session["board"]?.jsonArray ?: return
    var selected by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    val flip = mySlot == "player2"

    LazyVerticalGrid(columns = GridCells.Fixed(8), modifier = Modifier.aspectRatio(1f)) {
        items(64) { index ->
            val displayRow = index / 8
            val displayCol = index % 8
            val row = if (flip) 7 - displayRow else displayRow
            val col = if (flip) 7 - displayCol else displayCol
            val dark = (row + col) % 2 == 1
            val cellValue = ((board[row] as JsonArray)[col]).jsonPrimitive.int
            val isSelected = selected == row to col

            Box(
                modifier = Modifier
                    .aspectRatio(1f)
                    .background(if (dark) Color(0xFF8B5E3C) else Color(0xFFEAE0D5))
                    .then(if (isSelected) Modifier.background(Color(0x3322C55E)) else Modifier)
                    .clickable(enabled = canMove && dark) {
                        val mine = if (mySlot == "player1") cellValue == 1 || cellValue == 2 else cellValue == 3 || cellValue == 4
                        val sel = selected
                        if (sel != null) {
                            onMove(sel.first, sel.second, row, col)
                            selected = null
                        } else if (mine) {
                            selected = row to col
                        }
                    },
                contentAlignment = Alignment.Center,
            ) {
                if (cellValue != 0) {
                    val isRed = cellValue == 1 || cellValue == 2
                    val isKing = cellValue == 2 || cellValue == 4
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(3.dp)
                            .background(if (isRed) Color(0xFFC92A2A) else Color(0xFF111827), CircleShape),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (isKing) Text("♛", color = Color(0xFFFFD700), fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

// ---------------- Darts ----------------

@Composable
private fun DartsBoard(
    session: JsonObject,
    mySlot: String?,
    canThrow: Boolean,
    onSubmitTurn: (JsonArray) -> Unit,
) {
    val board = session["board"]?.jsonObject ?: return
    val scores = board["scores"]?.jsonObject
    val p1Score = scores?.get("player1")?.jsonPrimitive?.int ?: 501
    val p2Score = scores?.get("player2")?.jsonPrimitive?.int ?: 501

    var multiplier by remember { mutableStateOf(1) }
    var throwsThisTurn by remember { mutableStateOf(listOf<Pair<Int, Int>>()) } // segment to multiplier

    Column {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$p1Score", fontSize = 36.sp, fontWeight = FontWeight.ExtraBold)
                Text("P1", fontSize = 12.sp)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$p2Score", fontSize = 36.sp, fontWeight = FontWeight.ExtraBold)
                Text("P2", fontSize = 12.sp)
            }
        }

        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalArrangement = Arrangement.Center) {
            for (i in 0 until 3) {
                val t = throwsThisTurn.getOrNull(i)
                Box(
                    modifier = Modifier
                        .padding(4.dp)
                        .background(PBSurfaceVariant, RoundedCornerShape(8.dp))
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                ) {
                    Text(t?.let { describeThrow(it.first, it.second) } ?: "-", fontWeight = FontWeight.Bold)
                }
            }
        }

        if (canThrow) {
            Row(horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
                listOf(1 to "Single", 2 to "Double", 3 to "Triple").forEach { (m, label) ->
                    Box(modifier = Modifier.padding(4.dp)) {
                        SecondaryButton(label, enabled = multiplier != m) { multiplier = m }
                    }
                }
            }

            LazyVerticalGrid(columns = GridCells.Fixed(5), modifier = Modifier.padding(top = 8.dp)) {
                items(20) { i ->
                    val n = i + 1
                    Box(modifier = Modifier.padding(3.dp)) {
                        SecondaryButton(
                            text = "$n",
                            enabled = throwsThisTurn.size < 3,
                        ) {
                            throwsThisTurn = throwsThisTurn + (n to multiplier)
                        }
                    }
                }
            }
            Row(modifier = Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(modifier = Modifier.weight(1f)) {
                    SecondaryButton("UNDO", enabled = throwsThisTurn.isNotEmpty()) {
                        throwsThisTurn = throwsThisTurn.dropLast(1)
                    }
                }
                Box(modifier = Modifier.weight(1f)) {
                    PrimaryButton("SUBMIT TURN", enabled = throwsThisTurn.isNotEmpty()) {
                        val arr = buildJsonArray {
                            throwsThisTurn.forEach { (segment, mult) ->
                                add(
                                    buildJsonObject {
                                        put("segment", JsonPrimitive(segment))
                                        put("multiplier", JsonPrimitive(mult))
                                    },
                                )
                            }
                        }
                        onSubmitTurn(arr)
                        throwsThisTurn = emptyList()
                    }
                }
            }
        } else {
            Text("Waiting for opponent's throw…", modifier = Modifier.padding(top = 8.dp))
        }
    }
}

private fun describeThrow(segment: Int, multiplier: Int): String {
    val label = if (segment == 25) "Bull" else "$segment"
    val prefix = if (multiplier == 3) "T" else if (multiplier == 2) "D" else ""
    return "$prefix$label"
}

// ---------------- WebView-backed games (chess, basketball, cup pong, 8-ball) ----------------

/**
 * Chess, Basketball, Cup Pong, and 8-Ball Pool render through an embedded
 * WebView pointed at the same /play page the browser client uses, rather
 * than a second from-scratch Compose implementation of the same canvas
 * drag-physics UI. This is a deliberate architecture choice, not a
 * placeholder: the WebView owns its own WebSocket connection into the same
 * multiplayer session (server-authoritative, same protocol either client
 * uses), the touch/canvas physics controls behave identically to Android
 * Chrome (this is Chromium under the hood on real devices), and it avoids
 * maintaining two divergent copies of non-trivial physics/animation code.
 * Checkers and Darts stay native Compose since that UI was built first and
 * is simple enough not to warrant the same tradeoff.
 */
@Composable
private fun WebViewGameScreen(
    gameId: String,
    viewModel: GameViewModel,
    onLeave: () -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(title = { Text("PigeonBridge") })
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { context ->
                    WebView(context).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true // localStorage is used for the nickname + darts throw echo
                        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                        webViewClient = WebViewClient() // keep navigation inside this WebView, don't hand off to Chrome
                        loadUrl(viewModel.playUrl(gameId, viewModel.nickname))
                    }
                },
            )
            Spacer(modifier = Modifier.height(8.dp))
            Box(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
                SecondaryButton("LEAVE") { onLeave() }
            }
        }
    }
}

