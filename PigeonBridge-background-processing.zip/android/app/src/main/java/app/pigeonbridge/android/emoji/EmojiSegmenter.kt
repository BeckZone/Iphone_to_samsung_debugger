package app.pigeonbridge.android.emoji

/**
 * Maps an emoji's code-point key to the name of its bundled image file.
 *
 * Keys are lowercase hex code points joined by '-', exactly like the file names in
 * assets/emoji (e.g. "1f44d-1f3fd", "1f468-200d-1f469-200d-1f467"). U+FE0F (the emoji
 * presentation selector) is ignored on BOTH sides of the comparison, so "2764-fe0f" typed
 * by a keyboard and "2764" stored as a file name both find the same image, and a ZWJ
 * sequence typed without its optional FE0F still finds its FE0F-containing file.
 *
 * Pure Kotlin on purpose (no android.* imports) so it is unit-testable on the JVM.
 */
class EmojiLookup(fileKeys: Collection<String>) {
    private val byStrippedKey: Map<String, String>

    init {
        val map = HashMap<String, String>(fileKeys.size * 2)
        for (raw in fileKeys) {
            val key = raw.trim()
            if (key.isNotEmpty()) map[stripVs16(key)] = key
        }
        byStrippedKey = map
    }

    /** Number of distinct emoji images this lookup knows about. */
    val size: Int get() = byStrippedKey.size

    /** @param strippedKey a key already stripped of FE0F, as built by [EmojiSegmenter]. */
    fun fileKeyFor(strippedKey: String): String? = byStrippedKey[strippedKey]

    companion object {
        private const val VS16_HEX = "fe0f"

        fun stripVs16(key: String): String =
            key.split('-').filter { it != VS16_HEX }.joinToString("-")
    }
}

/** A run of the ORIGINAL text, [start, end), that should be drawn as the image [fileKey]. */
data class EmojiMatch(val start: Int, val end: Int, val fileKey: String)

/**
 * Finds emoji in a string so a UI can draw an image over them.
 *
 * It only ever reports ranges of the original string. It never rewrites, normalizes or
 * removes any character, so the original Unicode stays intact for copying, replying and
 * sharing. Anything it does not report is ordinary text and is left completely alone.
 *
 * Handled: single emoji, text-default symbols with U+FE0F, skin-tone modifiers, ZWJ
 * sequences (families, professions, gendered people, couples, rainbow flag, ...),
 * regional-indicator flags, subdivision tag flags (England/Scotland/Wales), and keycaps.
 *
 * Deliberately NOT treated as emoji (so "normal text is not modified"):
 *  - bare digits, '#' and '*' (only the keycap form  1 + [FE0F] + U+20E3  is an emoji);
 *  - text-default symbols such as the copyright sign or the trade mark sign, unless
 *    followed by U+FE0F (or a skin-tone modifier);
 *  - any character followed by U+FE0E (the explicit "text style" selector);
 *  - anything the bundled artwork has no image for. It stays as the system's own glyph.
 */
object EmojiSegmenter {
    private const val ZWJ = 0x200D
    private const val VS15 = 0xFE0E
    private const val VS16 = 0xFE0F
    private const val KEYCAP = 0x20E3
    private const val BLACK_FLAG = 0x1F3F4
    private const val TAG_FIRST = 0xE0020
    private const val TAG_LAST = 0xE007E
    private const val TAG_CANCEL = 0xE007F
    private const val RI_FIRST = 0x1F1E6
    private const val RI_LAST = 0x1F1FF
    private const val MODIFIER_FIRST = 0x1F3FB
    private const val MODIFIER_LAST = 0x1F3FF

    /**
     * One emoji "unit": a base character with its optional FE0F / skin tone, or a keycap,
     * flag pair, or tag flag. [certain] is true when the unit is an emoji no matter what
     * surrounds it (it has emoji presentation by default, or carries FE0F / a modifier).
     */
    private class Element(
        val start: Int,
        val end: Int,
        val codePoints: List<Int>,
        val certain: Boolean,
    )

    fun findEmoji(text: CharSequence, lookup: EmojiLookup): List<EmojiMatch> {
        val result = ArrayList<EmojiMatch>()
        val n = text.length
        var i = 0
        while (i < n) {
            val c = text[i]
            // Fast path: below U+00A9 only digits, '#' and '*' can begin an emoji (keycaps).
            if (c.code < 0xA9 && c != '#' && c != '*' && c !in '0'..'9') {
                i++
                continue
            }
            val first = readElement(text, i, lookup)
            if (first == null) {
                i += Character.charCount(Character.codePointAt(text, i))
                continue
            }

            val elements = ArrayList<Element>(2)
            elements.add(first)
            var pos = first.end
            while (pos < n && text[pos].code == ZWJ) {
                val next = readElement(text, pos + 1, lookup) ?: break
                elements.add(next)
                pos = next.end
            }

            val match = bestMatch(elements, lookup)
            if (match != null) {
                result.add(match)
                i = match.end
            } else {
                // No image for this unit: leave it as text and move on one character.
                i += Character.charCount(Character.codePointAt(text, i))
            }
        }
        return result
    }

    /**
     * True when [text] is nothing but 1..[maxEmoji] emoji (whitespace allowed between them).
     * Chat views use this to show such messages as large "jumbo" emoji, the way iMessage does.
     */
    fun isEmojiOnly(text: CharSequence, lookup: EmojiLookup, maxEmoji: Int = 3): Boolean =
        emojiOnlyFileKeys(text, lookup, maxEmoji) != null

    /**
     * If [text] is nothing but 1..[maxEmoji] emoji (whitespace allowed), the image file keys of
     * those emoji in order; otherwise null. Used to decide when a message is worth showing as
     * large emoji and which images to draw for it.
     */
    fun emojiOnlyFileKeys(text: CharSequence, lookup: EmojiLookup, maxEmoji: Int = 3): List<String>? {
        val matches = findEmoji(text, lookup)
        if (matches.isEmpty() || matches.size > maxEmoji) return null
        var cursor = 0
        for (m in matches) {
            if (!isBlankRange(text, cursor, m.start)) return null
            cursor = m.end
        }
        if (!isBlankRange(text, cursor, text.length)) return null
        return matches.map { it.fileKey }
    }

    private fun isBlankRange(text: CharSequence, from: Int, to: Int): Boolean {
        for (i in from until to) {
            if (!text[i].isWhitespace()) return false
        }
        return true
    }

    private fun bestMatch(elements: List<Element>, lookup: EmojiLookup): EmojiMatch? {
        // Longest ZWJ chain first, backing off one element at a time. A multi-element chain
        // is accepted even if its first character is text-default (a ZWJ chain is itself
        // the signal that it is an emoji, e.g. a rainbow flag typed without FE0F).
        var count = elements.size
        while (count >= 2) {
            val key = joinedKey(elements, count)
            val fileKey = lookup.fileKeyFor(key)
            if (fileKey != null) {
                return EmojiMatch(elements[0].start, elements[count - 1].end, fileKey)
            }
            count--
        }

        val first = elements[0]
        val fullKey = keyOf(first.codePoints)
        val fullFile = lookup.fileKeyFor(fullKey)
        if (fullFile != null && first.certain) {
            return EmojiMatch(first.start, first.end, fullFile)
        }

        // Skin tone the artwork has no image for: draw the base alone and let the modifier
        // be handled as its own character on the next step.
        val cps = first.codePoints
        val last = cps.last()
        if (cps.size >= 2 && last in MODIFIER_FIRST..MODIFIER_LAST) {
            val baseCps = cps.subList(0, cps.size - 1)
            val baseFile = lookup.fileKeyFor(keyOf(baseCps))
            val baseCertain = EmojiData.isEmojiPresentation(baseCps[0]) || baseCps.contains(VS16)
            if (baseFile != null && baseCertain) {
                return EmojiMatch(first.start, first.end - Character.charCount(last), baseFile)
            }
        }
        return null
    }

    private fun readElement(text: CharSequence, i: Int, lookup: EmojiLookup): Element? {
        val n = text.length
        if (i >= n) return null
        val cp = Character.codePointAt(text, i)
        var j = i + Character.charCount(cp)

        // Keycap: [0-9#*] FE0F? 20E3. A bare digit / # / * is never an emoji.
        if (cp == '#'.code || cp == '*'.code || cp in '0'.code..'9'.code) {
            var k = j
            if (k < n && text[k].code == VS16) k++
            if (k < n && text[k].code == KEYCAP) {
                return Element(i, k + 1, listOf(cp, KEYCAP), true)
            }
            return null
        }

        // Regional-indicator pair = a flag.
        if (cp in RI_FIRST..RI_LAST && j < n) {
            val second = Character.codePointAt(text, j)
            if (second in RI_FIRST..RI_LAST) {
                val end = j + Character.charCount(second)
                val key = keyOf(listOf(cp, second))
                if (lookup.fileKeyFor(key) != null) {
                    return Element(i, end, listOf(cp, second), true)
                }
            }
        }

        // Subdivision flag (England, Scotland, Wales): 1F3F4 + tag characters + cancel tag.
        if (cp == BLACK_FLAG) {
            val cps = arrayListOf(cp)
            var k = j
            while (k < n) {
                val t = Character.codePointAt(text, k)
                if (t in TAG_FIRST..TAG_LAST) {
                    cps.add(t)
                    k += Character.charCount(t)
                } else {
                    break
                }
            }
            if (cps.size > 1 && k < n && Character.codePointAt(text, k) == TAG_CANCEL) {
                cps.add(TAG_CANCEL)
                return Element(i, k + Character.charCount(TAG_CANCEL), cps, true)
            }
        }

        // Ordinary emoji base. It must at least be a character the artwork knows about.
        if (lookup.fileKeyFor(hex(cp)) == null) return null
        // U+FE0E explicitly asks for the plain text look: leave it as text.
        if (j < n && text[j].code == VS15) return null

        val cps = arrayListOf(cp)
        var certain = EmojiData.isEmojiPresentation(cp)
        if (j < n && text[j].code == VS16) {
            cps.add(VS16)
            j++
            certain = true
        }
        if (j < n) {
            val m = Character.codePointAt(text, j)
            if (m in MODIFIER_FIRST..MODIFIER_LAST) {
                cps.add(m)
                j += Character.charCount(m)
                certain = true
            }
        }
        return Element(i, j, cps, certain)
    }

    private fun joinedKey(elements: List<Element>, count: Int): String {
        val cps = ArrayList<Int>()
        for (e in 0 until count) {
            if (e > 0) cps.add(ZWJ)
            cps.addAll(elements[e].codePoints)
        }
        return keyOf(cps)
    }

    /** Hex code points joined by '-', FE0F removed, matching [EmojiLookup]'s key format. */
    internal fun keyOf(codePoints: List<Int>): String =
        codePoints.filter { it != VS16 }.joinToString("-") { hex(it) }

    private fun hex(cp: Int): String = cp.toString(16)
}
