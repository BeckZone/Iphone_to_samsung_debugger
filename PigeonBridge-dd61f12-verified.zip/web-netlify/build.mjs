import * as esbuild from "esbuild";
import { mkdirSync, copyFileSync, cpSync, rmSync, existsSync, writeFileSync } from "fs";

if (existsSync("dist")) rmSync("dist", { recursive: true });
mkdirSync("dist", { recursive: true });
mkdirSync("dist/icons", { recursive: true });

await esbuild.build({
  entryPoints: ["src/app.ts"],
  bundle: true,
  outfile: "dist/app.js",
  format: "esm",
  target: "es2020",
  minify: true,
  sourcemap: true,
});

copyFileSync("src/index.html", "dist/index.html");
copyFileSync("src/manifest.webmanifest", "dist/manifest.webmanifest");
copyFileSync("src/sw.js", "dist/sw.js"); // plain JS, no bundling needed -- kept dependency-free on purpose
cpSync("src/icons", "dist/icons", { recursive: true });

// dist/netlify.toml is intentionally different from the source-root
// netlify.toml: this one lives inside the already-built output (what a
// manual "Deploy manually" drag-and-drop actually uploads), so it must NOT
// contain a [build]/publish section -- dist/ IS the publish root at that
// point. It only needs the header rules.
writeFileSync(
  "dist/netlify.toml",
  `[[headers]]\n  for = "/manifest.webmanifest"\n  [headers.values]\n    Content-Type = "application/manifest+json"\n\n[[headers]]\n  for = "/sw.js"\n  [headers.values]\n    Service-Worker-Allowed = "/"\n    Cache-Control = "no-cache"\n`,
);

console.log("web-netlify build complete -> dist/");
