package app.pigeonbridge.android.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.pigeonbridge.android.emoji.EmojiAssets
import app.pigeonbridge.android.emoji.EmojiSegmenter
import app.pigeonbridge.android.emoji.EmojiText
import app.pigeonbridge.android.messages.FeedMessage
import app.pigeonbridge.android.messages.MessageFeed
import app.pigeonbridge.android.monitoring.MonitoringState
import app.pigeonbridge.android.ui.PigeonCard
import app.pigeonbridge.android.ui.PrimaryButton
import app.pigeonbridge.android.ui.SecondaryButton
import java.text.DateFormat
import java.util.Date

private val MutedText = Color(0xFFA8A3C7)
private val BubbleColor = Color(0xFF3A3A3C)

/**
 * iMessage-style chat view of messages that arrive while PigeonBridge has notification access.
 *
 * What it is: a live view of the text that Samsung Messages / Google Messages put in their
 * notifications, drawn as chat bubbles, with emoji drawn by PigeonBridge's own emoji artwork
 * and emoji-only messages shown large.
 *
 * What it is not: it is not your inbox and not a messaging app. It cannot show messages from
 * before it was running, cannot send replies, and does not change Samsung Messages at all.
 * Messages are kept in memory only (see MessageFeed) and are gone when the app closes or when
 * Clear is tapped.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MessageFeedScreen(onBack: () -> Unit, onOpenMonitoring: () -> Unit) {
    val context = LocalContext.current
    var messages by remember { mutableStateOf(MessageFeed.shared.snapshot()) }

    DisposableEffect(Unit) {
        val remove = MessageFeed.shared.addChangeListener {
            messages = MessageFeed.shared.snapshot()
        }
        messages = MessageFeed.shared.snapshot() // pick up anything that arrived before we subscribed
        onDispose { remove() }
    }

    val listState = rememberLazyListState()
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }

    val accessGranted = MonitoringState.notificationAccessGranted(context)
    val monitoringOn = MonitoringState.monitoringEnabled

    Scaffold(topBar = { TopAppBar(title = { Text("Messages") }) }) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp, vertical = 12.dp)) {
            PigeonCard {
                Column {
                    Text(
                        "Live from Samsung/Google Messages notifications. Kept in memory only; cleared when the app closes or you tap Clear. Not your full inbox.",
                        fontSize = 12.sp,
                        color = MutedText,
                    )
                    Text(
                        "Notification access: ${if (accessGranted) "On" else "Off"}  ·  Monitoring: ${if (monitoringOn) "On" else "Off"}",
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 6.dp),
                    )
                }
            }

            if (messages.isEmpty()) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            if (accessGranted && monitoringOn) {
                                "No messages yet. New texts will appear here while PigeonBridge is running."
                            } else {
                                "Turn on notification access and monitoring to see messages here."
                            },
                            fontSize = 14.sp,
                            color = MutedText,
                            modifier = Modifier.padding(24.dp),
                        )
                        if (!(accessGranted && monitoringOn)) {
                            SecondaryButton("Open Background Monitoring") { onOpenMonitoring() }
                        }
                    }
                }
            } else {
                LazyColumn(state = listState, modifier = Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp)) {
                    itemsIndexed(messages, key = { _, m -> m.key }) { index, message ->
                        val previous = messages.getOrNull(index - 1)
                        MessageBubble(message = message, showSender = previous?.sender != message.sender)
                    }
                }
            }

            Column(modifier = Modifier.padding(top = 8.dp)) {
                SecondaryButton("Clear", enabled = messages.isNotEmpty()) { MessageFeed.shared.clear() }
                Column(modifier = Modifier.padding(top = 8.dp)) {
                    PrimaryButton("Back") { onBack() }
                }
            }
        }
    }
}

@Composable
private fun MessageBubble(message: FeedMessage, showSender: Boolean) {
    val context = LocalContext.current
    // Emoji-only messages (up to three) are drawn large without a bubble, like iMessage.
    val jumbo = remember(message.text) {
        val lookup = EmojiAssets.lookup(context)
        lookup != null && EmojiSegmenter.isEmojiOnly(message.text, lookup)
    }

    Column(
        modifier = Modifier.fillMaxWidth().padding(top = if (showSender) 10.dp else 2.dp),
        horizontalAlignment = Alignment.Start,
    ) {
        if (showSender) {
            Text(
                "${message.sender}  ·  ${formatTime(message.timeMillis)}",
                fontSize = 12.sp,
                color = MutedText,
                modifier = Modifier.padding(start = 12.dp, bottom = 2.dp),
            )
        }
        if (jumbo) {
            EmojiText(message.text, fontSize = 44.sp, modifier = Modifier.padding(horizontal = 8.dp))
        } else {
            Box(
                modifier = Modifier
                    .widthIn(max = 300.dp)
                    .background(
                        BubbleColor,
                        RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomEnd = 18.dp, bottomStart = 4.dp),
                    )
                    .padding(horizontal = 14.dp, vertical = 9.dp),
            ) {
                EmojiText(message.text, color = Color.White, fontSize = 16.sp)
            }
        }
    }
}

private fun formatTime(millis: Long): String =
    DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(millis))
