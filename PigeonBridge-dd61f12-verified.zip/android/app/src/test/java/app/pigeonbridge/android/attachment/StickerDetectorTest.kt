package app.pigeonbridge.android.attachment

import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * Covers the spec's test-case list (Part 11), as far as pure classification
 * logic goes — [AttachmentInspector] itself needs a real ContentResolver/
 * Android runtime and so is exercised manually/via CI build + Android
 * Studio instrumented testing instead (see README). These tests run as
 * plain JVM unit tests, no emulator or Robolectric required.
 */
class StickerDetectorTest {

    private fun info(
        mimeType: String?,
        widthPx: Int,
        heightPx: Int,
        hasAlpha: Boolean?,
        reportedSizeBytes: Long = 50_000,
        displayName: String? = null,
        isLikelyPreview: Boolean = false,
        decodeFailed: Boolean = false,
    ) = AttachmentInfo(
        mimeType = mimeType,
        displayName = displayName,
        reportedSizeBytes = reportedSizeBytes,
        widthPx = widthPx,
        heightPx = heightPx,
        hasAlpha = hasAlpha,
        exifRotationDegrees = 0,
        isLikelyPreview = isLikelyPreview,
        decodeFailed = decodeFailed,
        decodePath = "test",
    )

    // 1. Normal JPEG — opaque, photo-scale dimensions, standard aspect ratio -> NORMAL_IMAGE
    @Test
    fun `normal JPEG classifies as normal image`() {
        val result = StickerDetector.classify(
            info(mimeType = "image/jpeg", widthPx = 3024, heightPx = 4032, hasAlpha = false, reportedSizeBytes = 2_500_000),
        )
        assertEquals(AttachmentClassification.NORMAL_IMAGE, result.classification)
    }

    // 2. Normal PNG (e.g. a screenshot) — opaque, large, standard-ish ratio -> NORMAL_IMAGE, not a sticker just because it's PNG
    @Test
    fun `large opaque PNG screenshot is not classified as a sticker`() {
        val result = StickerDetector.classify(
            info(mimeType = "image/png", widthPx = 1080, heightPx = 2400, hasAlpha = false, reportedSizeBytes = 800_000),
        )
        assertEquals(AttachmentClassification.NORMAL_IMAGE, result.classification)
    }

    // 3. Transparent PNG sticker — small, alpha, PNG -> LIKELY_STICKER
    @Test
    fun `small transparent PNG classifies as sticker`() {
        val result = StickerDetector.classify(
            info(mimeType = "image/png", widthPx = 200, heightPx = 200, hasAlpha = true, reportedSizeBytes = 30_000),
        )
        assertEquals(AttachmentClassification.LIKELY_STICKER, result.classification)
    }

    // 4. Transparent WebP sticker
    @Test
    fun `small transparent WebP classifies as sticker`() {
        val result = StickerDetector.classify(
            info(mimeType = "image/webp", widthPx = 320, heightPx = 320, hasAlpha = true, reportedSizeBytes = 15_000),
        )
        assertEquals(AttachmentClassification.LIKELY_STICKER, result.classification)
    }

    // 5. HEIC/HEIF photo — opaque, no alpha support, photo-scale -> NORMAL_IMAGE
    @Test
    fun `HEIC photo classifies as normal image`() {
        val result = StickerDetector.classify(
            info(mimeType = "image/heic", widthPx = 4032, heightPx = 3024, hasAlpha = false, reportedSizeBytes = 1_800_000),
        )
        assertEquals(AttachmentClassification.NORMAL_IMAGE, result.classification)
    }

    // 6. Low-resolution preview — tiny dimensions -> classified as sticker-scale regardless of photo/sticker intent,
    // but isLikelyPreview must be surfaced separately (this is a classification test, not a quality claim).
    @Test
    fun `tiny preview-scale image still gets a classification, not UNKNOWN`() {
        val result = StickerDetector.classify(
            info(mimeType = "image/jpeg", widthPx = 40, heightPx = 40, hasAlpha = false, isLikelyPreview = true),
        )
        // Tiny + JPEG is a genuine tug-of-war (tiny dims push sticker, JPEG pushes photo) —
        // the important assertion is that classification still runs rather than crashing on edge dimensions.
        assert(result.classification == AttachmentClassification.NORMAL_IMAGE || result.classification == AttachmentClassification.UNKNOWN)
    }

    // 7. High-resolution original attachment (large transparent PNG, e.g. a design asset) —
    // large size must push away from LIKELY_STICKER even with alpha present
    // (spec: "do NOT assume every transparent image is a sticker"). The
    // large-size and has-alpha signals pull in opposite directions here, so
    // the guarantee under test is "never falsely called a sticker", not a
    // specific non-sticker bucket.
    @Test
    fun `large transparent PNG is not automatically a sticker`() {
        val result = StickerDetector.classify(
            info(mimeType = "image/png", widthPx = 2000, heightPx = 3000, hasAlpha = true, reportedSizeBytes = 4_000_000),
        )
        assert(result.classification != AttachmentClassification.LIKELY_STICKER)
    }

    // 8. Corrupt/unsupported attachment -> UNKNOWN, not a crash
    @Test
    fun `decode failure classifies as unknown`() {
        val result = StickerDetector.classify(
            info(mimeType = null, widthPx = -1, heightPx = -1, hasAlpha = null, decodeFailed = true),
        )
        assertEquals(AttachmentClassification.UNKNOWN, result.classification)
    }

    // 9. Very large image (e.g. a 6000x4000 camera photo) -> NORMAL_IMAGE, confidently
    @Test
    fun `very large image classifies as normal image`() {
        val result = StickerDetector.classify(
            info(mimeType = "image/jpeg", widthPx = 6000, heightPx = 4000, hasAlpha = false, reportedSizeBytes = 8_000_000),
        )
        assertEquals(AttachmentClassification.NORMAL_IMAGE, result.classification)
    }

    // 10. Filename hint alone shouldn't override strong contrary photo signals, but should tip a genuinely ambiguous case.
    @Test
    fun `filename hint tips an ambiguous small opaque image toward sticker`() {
        val result = StickerDetector.classify(
            info(
                mimeType = "image/png",
                widthPx = 128,
                heightPx = 128,
                hasAlpha = false,
                displayName = "imessage_sticker_042.png",
            ),
        )
        assertEquals(AttachmentClassification.LIKELY_STICKER, result.classification)
    }

    @Test
    fun `animated GIF sticker classifies as sticker`() {
        val result = StickerDetector.classify(
            info(mimeType = "image/gif", widthPx = 240, heightPx = 240, hasAlpha = true, reportedSizeBytes = 120_000),
        )
        assertEquals(AttachmentClassification.LIKELY_STICKER, result.classification)
    }

    // ---- classifyDetailed(): same classification as classify(), plus the scoring breakdown Diagnostic Mode needs ----

    @Test
    fun `classifyDetailed agrees with classify on the same input`() {
        val i = info(mimeType = "image/png", widthPx = 200, heightPx = 200, hasAlpha = true, reportedSizeBytes = 30_000)
        val simple = StickerDetector.classify(i)
        val detailed = StickerDetector.classifyDetailed(i)
        assertEquals(simple.classification, detailed.classification)
    }

    @Test
    fun `classifyDetailed exposes one signal per scoring category`() {
        val detailed = StickerDetector.classifyDetailed(
            info(mimeType = "image/png", widthPx = 200, heightPx = 200, hasAlpha = true, reportedSizeBytes = 30_000),
        )
        val signalNames = detailed.signals.map { it.name }.toSet()
        assertEquals(setOf("alpha", "mime", "dimension", "aspect_ratio", "filename"), signalNames)
    }

    @Test
    fun `classifyDetailed score totals match the sum of individual signal points`() {
        val detailed = StickerDetector.classifyDetailed(
            info(mimeType = "image/webp", widthPx = 320, heightPx = 320, hasAlpha = true, reportedSizeBytes = 15_000),
        )
        assertEquals(detailed.signals.sumOf { it.stickerPoints }, detailed.stickerScore)
        assertEquals(detailed.signals.sumOf { it.photoPoints }, detailed.photoScore)
    }

    @Test
    fun `classifyDetailed on decode failure returns a single explanatory signal`() {
        val detailed = StickerDetector.classifyDetailed(
            info(mimeType = null, widthPx = -1, heightPx = -1, hasAlpha = null, decodeFailed = true),
        )
        assertEquals(AttachmentClassification.UNKNOWN, detailed.classification)
        assertEquals(1, detailed.signals.size)
    }
}
